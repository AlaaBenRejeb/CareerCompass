-- Add missing foreign key constraint
ALTER TABLE subscriptions
ADD CONSTRAINT fk_pricing_plan
FOREIGN KEY (pricing_plan_id)
REFERENCES pricing_plans(id);

-- Create function to handle checkout completion
CREATE OR REPLACE FUNCTION handle_checkout_completed()
RETURNS TRIGGER AS $$
BEGIN
  -- Update subscription with pricing plan ID from metadata
  UPDATE subscriptions
  SET 
    pricing_plan_id = (NEW.metadata->>'pricing_plan_id')::uuid,
    updated_at = now()
  WHERE stripe_subscription_id = NEW.subscription_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for checkout completion
CREATE TRIGGER on_checkout_completed
  AFTER INSERT ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION handle_checkout_completed();
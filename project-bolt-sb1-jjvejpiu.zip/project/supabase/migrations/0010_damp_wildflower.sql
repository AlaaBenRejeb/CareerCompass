/*
  # Update Stripe pricing configuration

  1. Changes
    - Updates the Pro Plan with the new Stripe price ID
    - Maintains existing product ID and features

  2. Security
    - No changes to RLS policies
    - Maintains existing security model
*/

-- Update the Pro Plan with the new Stripe price ID
UPDATE pricing_plans
SET stripe_price_id = 'price_1QaF31CubSqeMupo9X8Upw7p'
WHERE stripe_product_id = 'prod_RTBPMmiw6DjLG4';
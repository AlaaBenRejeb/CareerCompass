/*
  # Fix subscription and pricing plan relationships

  1. Changes
    - Clean up existing constraints
    - Add proper foreign key relationship
    - Update indexes for performance
    - Fix RLS policies

  2. Security
    - Maintain proper access control
    - Ensure data integrity
*/

-- First clean up any existing constraints
DO $$ 
BEGIN
  -- Drop existing constraints if they exist
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name IN (
      'subscriptions_pricing_plan_id_fkey',
      'fk_pricing_plan',
      'fk_pricing_plan_new',
      'fk_subscription_pricing_plan'
    )
  ) THEN
    ALTER TABLE subscriptions 
    DROP CONSTRAINT IF EXISTS subscriptions_pricing_plan_id_fkey,
    DROP CONSTRAINT IF EXISTS fk_pricing_plan,
    DROP CONSTRAINT IF EXISTS fk_pricing_plan_new,
    DROP CONSTRAINT IF EXISTS fk_subscription_pricing_plan;
  END IF;
END $$;

-- Add clean foreign key constraint
ALTER TABLE subscriptions
ADD CONSTRAINT fk_subscription_plan
FOREIGN KEY (pricing_plan_id)
REFERENCES pricing_plans(id);

-- Ensure proper indexes
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_pricing 
ON subscriptions(user_id, pricing_plan_id);

CREATE INDEX IF NOT EXISTS idx_subscriptions_status 
ON subscriptions(status);

-- Drop existing policies first
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anyone can read active pricing plans" ON pricing_plans;
  DROP POLICY IF EXISTS "Users can read own subscription" ON subscriptions;
  DROP POLICY IF EXISTS "Users can update own subscription" ON subscriptions;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;

-- Enable RLS
DO $$ 
BEGIN
  ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
  ALTER TABLE pricing_plans ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;

-- Create new policies
DO $$ 
BEGIN
  CREATE POLICY "Anyone can read active pricing plans"
    ON pricing_plans
    FOR SELECT
    USING (active = true);

  CREATE POLICY "Users can read own subscription"
    ON subscriptions
    FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

  CREATE POLICY "Users can update own subscription"
    ON subscriptions
    FOR UPDATE
    TO authenticated
    USING (user_id = auth.uid());
EXCEPTION
  WHEN duplicate_object THEN
    NULL;
END $$;
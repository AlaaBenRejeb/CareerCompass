/*
  # Update pricing plan with Stripe product ID

  1. Changes
    - Updates the Pro Plan with the correct Stripe product ID
    - Sets the price to $19.99/month
    - Updates features list

  2. Security
    - No changes to RLS policies
    - Maintains existing security model
*/

UPDATE pricing_plans
SET 
  stripe_product_id = 'prod_RTBPMmiw6DjLG4',
  price = 1999,
  interval = 'month',
  features = ARRAY[
    'Unlimited CVs and cover letters',
    'AI-powered CV optimization',
    'Interview practice with AI feedback',
    'Skills gap analysis',
    'Priority support'
  ]
WHERE name = 'Pro Plan';
-- Fix subscription relationship with pricing plans
DO $$ 
BEGIN
  -- Drop existing foreign key if it exists
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'subscriptions_pricing_plan_id_fkey'
  ) THEN
    ALTER TABLE subscriptions DROP CONSTRAINT subscriptions_pricing_plan_id_fkey;
  END IF;

  -- Add foreign key with correct name
  ALTER TABLE subscriptions
  ADD CONSTRAINT fk_pricing_plan
  FOREIGN KEY (pricing_plan_id)
  REFERENCES pricing_plans(id);

  -- Create index for better join performance
  CREATE INDEX IF NOT EXISTS idx_subscriptions_pricing_plan_id 
  ON subscriptions(pricing_plan_id);
END $$;

-- Update RLS policies to include pricing plan access
CREATE POLICY "Users can read pricing plan details through subscriptions"
  ON pricing_plans
  FOR SELECT
  TO authenticated
  USING (
    id IN (
      SELECT pricing_plan_id 
      FROM subscriptions 
      WHERE user_id = auth.uid()
    ) OR active = true
  );
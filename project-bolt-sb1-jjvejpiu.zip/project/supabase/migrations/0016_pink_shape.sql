/*
  # Fix subscription query and constraints

  1. Changes
    - Drop and recreate foreign key constraint with proper naming
    - Update subscription query structure
    - Add missing indexes
    - Clean up RLS policies

  2. Security
    - Maintain RLS policies
    - Ensure proper access control
*/

-- First clean up any existing constraints
DO $$ 
BEGIN
  -- Drop existing constraints if they exist
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name IN (
      'subscriptions_pricing_plan_id_fkey',
      'fk_pricing_plan',
      'fk_pricing_plan_new',
      'fk_subscription_pricing_plan'
    )
  ) THEN
    ALTER TABLE subscriptions 
    DROP CONSTRAINT IF EXISTS subscriptions_pricing_plan_id_fkey,
    DROP CONSTRAINT IF EXISTS fk_pricing_plan,
    DROP CONSTRAINT IF EXISTS fk_pricing_plan_new,
    DROP CONSTRAINT IF EXISTS fk_subscription_pricing_plan;
  END IF;
END $$;

-- Add clean foreign key constraint
ALTER TABLE subscriptions
ADD CONSTRAINT fk_subscription_plan
FOREIGN KEY (pricing_plan_id)
REFERENCES pricing_plans(id);

-- Ensure proper indexes
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_pricing 
ON subscriptions(user_id, pricing_plan_id);

CREATE INDEX IF NOT EXISTS idx_subscriptions_status 
ON subscriptions(status);

-- Update RLS policies
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_plans ENABLE ROW LEVEL SECURITY;

-- Clean up existing policies
DROP POLICY IF EXISTS "Users can read pricing plans" ON pricing_plans;
DROP POLICY IF EXISTS "Users can read own subscriptions" ON subscriptions;
DROP POLICY IF EXISTS "Users can update own subscriptions" ON subscriptions;

-- Create clean policies
CREATE POLICY "Anyone can read active pricing plans"
  ON pricing_plans
  FOR SELECT
  USING (active = true);

CREATE POLICY "Users can read own subscription"
  ON subscriptions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own subscription"
  ON subscriptions
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());
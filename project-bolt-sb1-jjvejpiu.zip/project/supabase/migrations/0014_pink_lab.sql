/*
  # Fix subscription relationships and policies

  1. Changes
    - Safely handle existing foreign key constraint
    - Update RLS policies for proper access
    - Add index for better performance

  2. Security
    - Maintain RLS policies
    - Ensure proper access control
*/

-- Drop and recreate foreign key constraint safely
DO $$ 
BEGIN
  -- Drop existing constraint if it exists
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'subscriptions_pricing_plan_id_fkey'
  ) THEN
    ALTER TABLE subscriptions DROP CONSTRAINT subscriptions_pricing_plan_id_fkey;
  END IF;

  -- Drop existing fk_pricing_plan if it exists
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_pricing_plan'
  ) THEN
    ALTER TABLE subscriptions DROP CONSTRAINT fk_pricing_plan;
  END IF;

  -- Add new constraint
  ALTER TABLE subscriptions
  ADD CONSTRAINT fk_pricing_plan_new
  FOREIGN KEY (pricing_plan_id)
  REFERENCES pricing_plans(id);
END $$;

-- Create index for better join performance if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_subscriptions_pricing_plan_id 
ON subscriptions(pricing_plan_id);

-- Drop and recreate policy
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can read pricing plans through subscriptions" ON pricing_plans;

  CREATE POLICY "Users can read pricing plans through subscriptions"
    ON pricing_plans
    FOR SELECT
    TO authenticated
    USING (
      id IN (
        SELECT pricing_plan_id 
        FROM subscriptions 
        WHERE user_id = auth.uid()
      ) OR active = true
    );
END $$;
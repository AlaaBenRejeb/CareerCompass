/*
  # Fix subscription table relationships

  1. Changes
    - Add pricing_plan_id to subscriptions table
    - Create foreign key relationship between subscriptions and pricing_plans
    - Update RLS policies

  2. Security
    - Maintain existing RLS policies
    - Add new policy for pricing plan relationship
*/

-- Add pricing_plan_id to subscriptions
ALTER TABLE subscriptions
ADD COLUMN pricing_plan_id uuid REFERENCES pricing_plans(id);

-- Create index for better query performance
CREATE INDEX idx_subscriptions_pricing_plan ON subscriptions(pricing_plan_id);

-- Update existing subscriptions to link to default pricing plan
UPDATE subscriptions s
SET pricing_plan_id = (
  SELECT id FROM pricing_plans 
  WHERE stripe_product_id = 'prod_RTBPMmiw6DjLG4' 
  LIMIT 1
)
WHERE pricing_plan_id IS NULL;

-- Make pricing_plan_id required for future records
ALTER TABLE subscriptions
ALTER COLUMN pricing_plan_id SET NOT NULL;
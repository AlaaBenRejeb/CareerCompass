/*
  # Add Stripe Integration

  1. New Functions
    - handle_subscription_updated: Updates subscription status when Stripe webhook is received
    - handle_subscription_deleted: Handles subscription cancellation
    
  2. Security
    - RLS policies for subscription management
    - Secure function execution
*/

-- Function to handle subscription updates from Stripe
CREATE OR REPLACE FUNCTION handle_subscription_updated()
RETURNS TRIGGER AS $$
BEGIN
  -- Update subscription status
  UPDATE subscriptions
  SET 
    status = NEW.status,
    current_period_start = NEW.current_period_start,
    current_period_end = NEW.current_period_end,
    cancel_at_period_end = NEW.cancel_at_period_end,
    updated_at = now()
  WHERE stripe_subscription_id = NEW.stripe_subscription_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to handle subscription deletion
CREATE OR REPLACE FUNCTION handle_subscription_deleted()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE subscriptions
  SET 
    status = 'canceled',
    updated_at = now()
  WHERE stripe_subscription_id = OLD.stripe_subscription_id;
  
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers for subscription management
CREATE TRIGGER on_subscription_updated
  AFTER UPDATE ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION handle_subscription_updated();

CREATE TRIGGER on_subscription_deleted
  AFTER DELETE ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION handle_subscription_deleted();

-- Add RLS policies for subscription management
CREATE POLICY "Users can update own subscription"
  ON subscriptions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own subscription"
  ON subscriptions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
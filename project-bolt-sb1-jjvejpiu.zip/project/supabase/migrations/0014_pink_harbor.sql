/*
  # Fix subscription relationships and pricing plans

  1. Changes
    - Drop duplicate foreign key constraints
    - Add correct foreign key relationship
    - Update RLS policies for proper access
    - Fix subscription queries

  2. Security
    - Maintain RLS policies
    - Ensure proper access control
*/

-- First drop any duplicate constraints
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'subscriptions_pricing_plan_id_fkey'
  ) THEN
    ALTER TABLE subscriptions DROP CONSTRAINT subscriptions_pricing_plan_id_fkey;
  END IF;
END $$;

-- Ensure single, correct foreign key constraint
ALTER TABLE subscriptions
ADD CONSTRAINT fk_pricing_plan
FOREIGN KEY (pricing_plan_id)
REFERENCES pricing_plans(id);

-- Update RLS policies for cleaner joins
CREATE OR REPLACE POLICY "Users can read pricing plans through subscriptions"
  ON pricing_plans
  FOR SELECT
  TO authenticated
  USING (
    id IN (
      SELECT pricing_plan_id 
      FROM subscriptions 
      WHERE user_id = auth.uid()
    ) OR active = true
  );

-- Create function to handle subscription updates
CREATE OR REPLACE FUNCTION handle_subscription_update()
RETURNS TRIGGER AS $$
BEGIN
  -- Update subscription with pricing plan details
  UPDATE subscriptions
  SET 
    pricing_plan_id = NEW.pricing_plan_id,
    updated_at = now()
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
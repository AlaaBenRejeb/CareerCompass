/*
  # Fix subscription relationships and policies

  1. Changes
    - Drop and recreate foreign key constraint if needed
    - Add index for better join performance
    - Update RLS policies for pricing plan access

  2. Security
    - Enable RLS for pricing plans table
    - Add policy for authenticated users to read pricing plans
*/

-- Safely handle foreign key constraint
DO $$ 
BEGIN
  -- Only try to drop if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_pricing_plan'
  ) THEN
    -- Add foreign key with correct name
    ALTER TABLE subscriptions
    ADD CONSTRAINT fk_pricing_plan
    FOREIGN KEY (pricing_plan_id)
    REFERENCES pricing_plans(id);
  END IF;
END $$;

-- Create index for better join performance if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_subscriptions_pricing_plan_id 
ON subscriptions(pricing_plan_id);

-- Update RLS policies to include pricing plan access
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'pricing_plans' 
    AND policyname = 'Users can read pricing plan details through subscriptions'
  ) THEN
    CREATE POLICY "Users can read pricing plan details through subscriptions"
      ON pricing_plans
      FOR SELECT
      TO authenticated
      USING (
        id IN (
          SELECT pricing_plan_id 
          FROM subscriptions 
          WHERE user_id = auth.uid()
        ) OR active = true
      );
  END IF;
END $$;
/*
  # API Keys and Policies Update

  1. New Tables
    - `api_keys` table for storing encrypted API keys
  
  2. Changes
    - Add policies for API keys table
    - Add initial GPT API key
  
  3. Security
    - Enable RLS on api_keys table
    - Add read-only policy for authenticated users
*/

-- Create API keys table
CREATE TABLE IF NOT EXISTS api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name text NOT NULL UNIQUE,
  encrypted_key text NOT NULL,
  created_at timestamptz DEFAULT now(),
  last_used timestamptz
);

-- Enable Row Level Security
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anyone can read API keys" ON api_keys;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;

-- Create policy for API keys
CREATE POLICY "Anyone can read API keys"
  ON api_keys
  FOR SELECT
  TO authenticated
  USING (true);

-- Insert initial API key if it doesn't exist
INSERT INTO api_keys (key_name, encrypted_key)
VALUES (
  'gpt',
  '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'
)
ON CONFLICT (key_name) DO UPDATE
SET encrypted_key = EXCLUDED.encrypted_key;
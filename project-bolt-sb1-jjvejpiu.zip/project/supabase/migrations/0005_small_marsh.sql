/*
  # Payment System Tables

  1. New Tables
    - `pricing_plans`
      - Single plan for $19.99/month
    - `subscriptions`
      - Tracks user subscriptions
  
  2. Security
    - Enable RLS on all tables
    - Add policies for secure access
*/

-- Create pricing plans table
CREATE TABLE pricing_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price integer NOT NULL,
  interval text NOT NULL CHECK (interval IN ('month', 'year')),
  features text[] NOT NULL DEFAULT '{}',
  stripe_product_id text NOT NULL,
  stripe_price_id text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create subscriptions table
CREATE TABLE subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  status text NOT NULL CHECK (status IN ('trialing', 'active', 'canceled', 'incomplete', 'past_due')),
  stripe_subscription_id text,
  stripe_customer_id text,
  current_period_start timestamptz,
  current_period_end timestamptz,
  cancel_at_period_end boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE pricing_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read active pricing plans"
  ON pricing_plans
  FOR SELECT
  USING (active = true);

CREATE POLICY "Users can read own subscription"
  ON subscriptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes
CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);

-- Insert single pricing plan
INSERT INTO pricing_plans (
  name,
  description,
  price,
  interval,
  features,
  stripe_product_id,
  stripe_price_id
) VALUES (
  'Pro Plan',
  'Full access to all features',
  1999,
  'month',
  ARRAY[
    'Unlimited CVs and cover letters',
    'AI-powered CV optimization',
    'Interview practice with AI feedback',
    'Skills gap analysis',
    'Priority support'
  ],
  'prod_default',
  'price_default_monthly'
);
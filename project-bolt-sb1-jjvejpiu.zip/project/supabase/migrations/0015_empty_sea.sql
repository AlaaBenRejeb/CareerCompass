/*
  # Fix subscription constraints and relationships

  1. Changes
    - Drop existing foreign key constraints
    - Create new clean foreign key constraint
    - Update RLS policies for proper access
    - Add missing indexes

  2. Security
    - Enable RLS
    - Add proper policies for subscription access
*/

-- First clean up any existing constraints
DO $$ 
BEGIN
  -- Drop existing constraints if they exist
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name IN ('subscriptions_pricing_plan_id_fkey', 'fk_pricing_plan', 'fk_pricing_plan_new')
  ) THEN
    ALTER TABLE subscriptions 
    DROP CONSTRAINT IF EXISTS subscriptions_pricing_plan_id_fkey,
    DROP CONSTRAINT IF EXISTS fk_pricing_plan,
    DROP CONSTRAINT IF EXISTS fk_pricing_plan_new;
  END IF;
END $$;

-- Add single, clean foreign key constraint
ALTER TABLE subscriptions
ADD CONSTRAINT fk_subscription_pricing_plan
FOREIGN KEY (pricing_plan_id)
REFERENCES pricing_plans(id);

-- Ensure proper indexes exist
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id_pricing_plan 
ON subscriptions(user_id, pricing_plan_id);

CREATE INDEX IF NOT EXISTS idx_subscriptions_stripe_customer 
ON subscriptions(stripe_customer_id);

-- Update RLS policies
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_plans ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can read pricing plans through subscriptions" ON pricing_plans;
DROP POLICY IF EXISTS "Users can read own subscription" ON subscriptions;

-- Create clean policies
CREATE POLICY "Users can read pricing plans"
  ON pricing_plans
  FOR SELECT
  TO authenticated
  USING (
    active = true OR
    id IN (
      SELECT pricing_plan_id 
      FROM subscriptions 
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can read own subscriptions"
  ON subscriptions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own subscriptions"
  ON subscriptions
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());
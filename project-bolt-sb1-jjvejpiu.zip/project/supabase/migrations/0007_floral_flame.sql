/*
  # Add Stripe Integration

  1. New Tables
    - subscription_items: Track subscription line items
    - subscription_usage: Track feature usage
    
  2. Security
    - RLS policies for subscription management
    - Secure function execution
*/

-- Add Stripe-specific fields to subscriptions table
ALTER TABLE subscriptions
ADD COLUMN IF NOT EXISTS stripe_price_id text,
ADD COLUMN IF NOT EXISTS trial_end timestamptz,
ADD COLUMN IF NOT EXISTS trial_start timestamptz;

-- Create subscription items table
CREATE TABLE subscription_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id uuid REFERENCES subscriptions(id) ON DELETE CASCADE,
  stripe_price_id text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create subscription usage table
CREATE TABLE subscription_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id uuid REFERENCES subscriptions(id) ON DELETE CASCADE,
  feature_name text NOT NULL,
  usage_count integer NOT NULL DEFAULT 0,
  last_used timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE subscription_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_usage ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view own subscription items"
  ON subscription_items
  FOR SELECT
  TO authenticated
  USING (
    subscription_id IN (
      SELECT id FROM subscriptions WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view own subscription usage"
  ON subscription_usage
  FOR SELECT
  TO authenticated
  USING (
    subscription_id IN (
      SELECT id FROM subscriptions WHERE user_id = auth.uid()
    )
  );

-- Function to increment feature usage
CREATE OR REPLACE FUNCTION increment_feature_usage(
  p_subscription_id uuid,
  p_feature_name text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO subscription_usage (subscription_id, feature_name, usage_count)
  VALUES (p_subscription_id, p_feature_name, 1)
  ON CONFLICT (subscription_id, feature_name)
  DO UPDATE SET 
    usage_count = subscription_usage.usage_count + 1,
    last_used = now();
END;
$$;

-- Update pricing plan
UPDATE pricing_plans
SET 
  stripe_product_id = 'prod_default',
  stripe_price_id = 'price_default_monthly',
  price = 1999,
  interval = 'month',
  features = ARRAY[
    'Unlimited CVs and cover letters',
    'AI-powered CV optimization',
    'Interview practice with AI feedback',
    'Skills gap analysis',
    'Priority support'
  ]
WHERE name = 'Pro Plan';
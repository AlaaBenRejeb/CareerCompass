import { supabase } from '../../utils/supabase';
import { GPT_CONFIG } from './config';
import type { GPTMessage, GPTResponse, GPTError } from './types';

async function getGPTApiKey(): Promise<string> {
  try {
    const { data, error } = await supabase
      .from('api_keys')
      .select('encrypted_key')
      .eq('key_name', 'gpt')
      .single();

    if (error) throw error;
    if (!data?.encrypted_key) throw new Error('API key not found');

    return data.encrypted_key;
  } catch (error) {
    console.error('Error fetching GPT API key:', error);
    throw new Error('Failed to get API key');
  }
}

export async function callGPTAPI(systemPrompt: string, userPrompt: string): Promise<string> {
  try {
    const apiKey = await getGPTApiKey();

    const messages: GPTMessage[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ];

    const response = await fetch(GPT_CONFIG.apiEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: GPT_CONFIG.model,
        messages,
        temperature: GPT_CONFIG.temperature
      })
    });

    if (!response.ok) {
      const error = await response.json() as GPTError;
      throw new Error(error.error?.message || 'Failed to get response from GPT API');
    }

    const data = await response.json() as GPTResponse;
    return data.choices[0].message.content;
  } catch (error) {
    console.error('GPT API Error:', error);
    throw new Error('Failed to process request. Please try again.');
  }
}
// Common types used across GPT services
export interface GPTMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface GPTResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export interface GPTError {
  error?: {
    message: string;
  };
}
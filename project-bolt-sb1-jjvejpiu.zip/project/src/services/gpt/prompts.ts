// Centralized prompt management
export const PROMPTS = {
  cvAnalysis: {
    system: 'You are an expert CV analyzer. Compare the CV against the job requirements and provide detailed analysis.',
    generateUser: (cvText: string, title: string, description: string, requirements: string[]) => 
      `CV: ${cvText}\n\nJob Title: ${title}\n\nJob Description: ${description}\n\nRequirements: ${requirements.join(', ')}`
  },
  coverLetter: {
    system: 'You are a professional cover letter writer.',
    generateUser: (data: {
      jobTitle: string;
      company: string;
      keySkills: string;
      relevantExperience: string;
      whyInterested: string;
      additionalNotes: string;
    }) => 
      `Job Title: ${data.jobTitle}\nCompany: ${data.company}\nKey Skills: ${data.keySkills}\nRelevant Experience: ${data.relevantExperience}\nWhy Interested: ${data.whyInterested}\nAdditional Notes: ${data.additionalNotes}`
  },
  skillGap: {
    system: 'You are a career development and skills analysis expert. Analyze the user\'s current skills, experience, and CV against their target role.',
    generateUser: (cvText: string, formData: {
      targetRole: string;
      currentSkills: string[];
      experience: string;
      industry: string;
      careerGoals: string;
    }) =>
      `CV Content: ${cvText}\n\nTarget Role: ${formData.targetRole}\nCurrent Skills: ${formData.currentSkills.join(', ')}\nExperience Level: ${formData.experience}\nIndustry: ${formData.industry}\nCareer Goals: ${formData.careerGoals}`
  }
} as const;
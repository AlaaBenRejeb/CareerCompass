import { callGPTAPI } from './client';
import { PROMPTS } from './prompts';
import { parseGPTResponse } from '../../utils/gptResponseParser';
import type { AnalysisResult, JobDescription } from '../../types/analysis';

export class CVAnalysisError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CVAnalysisError';
  }
}

function validateAnalysisInput(cvText: string, jobDescription: JobDescription) {
  if (!cvText?.trim()) {
    throw new CVAnalysisError('CV text is required for analysis');
  }

  if (!jobDescription?.title?.trim()) {
    throw new CVAnalysisError('Job title is required');
  }

  if (!jobDescription?.description?.trim()) {
    throw new CVAnalysisError('Job description is required');
  }
}

export async function analyzeCV(cvText: string, jobDescription: JobDescription): Promise<AnalysisResult> {
  try {
    // Validate inputs
    validateAnalysisInput(cvText, jobDescription);

    // Clean and normalize CV text
    const normalizedCVText = cvText
      .replace(/\s+/g, ' ')
      .trim();

    // Build analysis prompt
    const userPrompt = `
CV Content:
${normalizedCVText}

Job Details:
Title: ${jobDescription.title}
Description: ${jobDescription.description}

Please analyze the CV against these job requirements and provide:
1. Overall match score (0-100)
2. Job fit score (0-100)
3. Found keywords that match job requirements
4. Missing important keywords from requirements
5. Relevant experience matches
6. Missing qualifications
7. Specific improvement suggestions`;

    const response = await callGPTAPI(
      PROMPTS.cvAnalysis.system,
      userPrompt
    );

    if (!response?.trim()) {
      throw new CVAnalysisError('Failed to get analysis response');
    }

    const result = parseGPTResponse(response, true);

    // Validate result
    if (!result || typeof result.score !== 'number' || !Array.isArray(result.keywords?.found)) {
      throw new CVAnalysisError('Invalid analysis result format');
    }

    return result;
  } catch (error) {
    console.error('CV analysis error:', error);
    
    if (error instanceof CVAnalysisError) {
      throw error;
    }

    throw new CVAnalysisError(
      error instanceof Error 
        ? error.message 
        : 'Failed to analyze CV. Please try again.'
    );
  }
}
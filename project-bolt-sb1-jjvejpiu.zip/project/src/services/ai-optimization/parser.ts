import type { CV } from '../../types/cv';

export function parseOptimizationResponse(response: string): CV {
  try {
    // Find JSON object in response
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No valid JSON found in response');
    }

    let parsed: any;
    try {
      parsed = JSON.parse(jsonMatch[0]);
    } catch (e) {
      throw new Error('Invalid JSON format in response');
    }

    // Ensure basic CV structure
    if (!parsed || typeof parsed !== 'object') {
      throw new Error('Invalid CV structure');
    }

    // Ensure personal info exists and has required fields
    if (!parsed.personalInfo || typeof parsed.personalInfo !== 'object') {
      throw new Error('Missing or invalid personal information');
    }

    const requiredPersonalFields = ['fullName', 'email', 'phone', 'location', 'title'];
    for (const field of requiredPersonalFields) {
      if (!parsed.personalInfo[field]) {
        parsed.personalInfo[field] = ''; // Provide default empty string
      }
    }

    // Ensure arrays exist
    parsed.experience = Array.isArray(parsed.experience) ? parsed.experience : [];
    parsed.education = Array.isArray(parsed.education) ? parsed.education : [];
    parsed.skills = Array.isArray(parsed.skills) ? parsed.skills : [];

    return parsed as CV;
  } catch (error) {
    console.error('Failed to parse optimization response:', error);
    throw new Error('Failed to process optimization result');
  }
}
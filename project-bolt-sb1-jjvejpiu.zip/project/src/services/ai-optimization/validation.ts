import type { CV } from '../../types/cv';

export function validateCV(cv: CV): void {
  try {
    // Validate personal info
    if (!cv.personalInfo || typeof cv.personalInfo !== 'object') {
      throw new Error('Invalid personal information structure');
    }

    // Ensure required personal info fields exist
    const requiredPersonalFields = ['fullName', 'email', 'phone', 'location', 'title'];
    for (const field of requiredPersonalFields) {
      if (typeof cv.personalInfo[field] !== 'string') {
        throw new Error(`Invalid personal info field: ${field}`);
      }
    }

    // Validate arrays exist
    if (!Array.isArray(cv.experience)) {
      throw new Error('Experience must be an array');
    }

    if (!Array.isArray(cv.education)) {
      throw new Error('Education must be an array');
    }

    if (!Array.isArray(cv.skills)) {
      throw new Error('Skills must be an array');
    }

    // Validate experience entries
    cv.experience.forEach((exp, index) => {
      if (!exp.company || !exp.position || !exp.description) {
        throw new Error(`Invalid experience entry at position ${index + 1}`);
      }
    });

    // Validate education entries
    cv.education.forEach((edu, index) => {
      if (!edu.institution || !edu.degree) {
        throw new Error(`Invalid education entry at position ${index + 1}`);
      }
    });

    // Validate skills
    if (cv.skills.some(skill => typeof skill !== 'string')) {
      throw new Error('All skills must be strings');
    }
  } catch (error) {
    console.error('CV validation error:', error);
    throw error;
  }
}
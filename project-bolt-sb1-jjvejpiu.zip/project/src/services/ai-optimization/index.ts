import { callGPTAPI } from '../gpt';
import { CV_PROMPTS } from './prompts';
import type { CV } from '../../types/cv';

export async function optimizeCVWithAI(cv: CV): Promise<CV> {
  try {
    const response = await callGPTAPI(
      CV_PROMPTS.optimization.system,
      CV_PROMPTS.optimization.generateUser(cv)
    );

    const optimizedCV = JSON.parse(response);

    // Preserve IDs from original CV
    optimizedCV.experience = optimizedCV.experience.map((exp: any, i: number) => ({
      ...exp,
      id: cv.experience[i]?.id || String(Date.now() + i)
    }));

    optimizedCV.education = optimizedCV.education.map((edu: any, i: number) => ({
      ...edu,
      id: cv.education[i]?.id || String(Date.now() + i)
    }));

    return optimizedCV;
  } catch (error) {
    console.error('CV optimization error:', error);
    throw new Error('Failed to optimize CV');
  }
}
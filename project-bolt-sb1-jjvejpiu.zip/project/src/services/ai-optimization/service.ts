import { callGPTAPI } from '../gpt/client';
import { CV_PROMPTS } from './prompts';
import { validateCV } from './validation';
import { parseOptimizationResponse } from './parser';
import type { CV } from '../../types/cv';

export async function optimizeCVWithAI(cv: CV): Promise<CV> {
  try {
    // Initial validation
    validateCV(cv);

    // Get optimized content from GPT
    const response = await callGPTAPI(
      CV_PROMPTS.optimization.system,
      CV_PROMPTS.optimization.generateUser(cv)
    );

    // Parse and validate response
    const optimizedCV = parseOptimizationResponse(response);

    // Preserve IDs and handle empty arrays
    optimizedCV.experience = (optimizedCV.experience || []).map((exp, i) => ({
      ...exp,
      id: cv.experience[i]?.id || `exp-${Date.now()}-${i}`
    }));

    optimizedCV.education = (optimizedCV.education || []).map((edu, i) => ({
      ...edu,
      id: cv.education[i]?.id || `edu-${Date.now()}-${i}`
    }));

    optimizedCV.skills = optimizedCV.skills || [];

    // Final validation
    validateCV(optimizedCV);

    return optimizedCV;
  } catch (error) {
    console.error('CV optimization error:', error);
    // Return original CV with error message
    return {
      ...cv,
      optimizationError: error instanceof Error ? error.message : 'Failed to optimize CV'
    };
  }
}
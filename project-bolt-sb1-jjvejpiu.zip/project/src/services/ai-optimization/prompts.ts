import { CV_BEST_PRACTICES, ACTION_VERBS } from '../../utils/cvBestPractices';
import type { CV } from '../../types/cv';

export const CV_PROMPTS = {
  optimization: {
    system: `You are an expert CV optimizer. Enhance this CV while maintaining its core information and structure. Follow these best practices:
${Object.entries(CV_BEST_PRACTICES)
  .map(([category, practices]) => `${category.toUpperCase()}:\n${practices.join('\n')}`)
  .join('\n\n')}

Use these action verbs for experience descriptions:
${ACTION_VERBS.join(', ')}

CRITICAL REQUIREMENTS:
1. Return ONLY a valid JSON object with the exact same structure as the input
2. Preserve all required fields and data types
3. Do not add or remove sections
4. Focus on enhancing content while maintaining accuracy
5. Ensure all text fields are non-empty strings
6. Keep arrays intact with the same structure`,

    generateUser: (cv: CV) => `Original CV:
${JSON.stringify(cv, null, 2)}

Optimize this CV by:
1. Using strong action verbs in experience descriptions
2. Quantifying achievements where possible
3. Enhancing skill descriptions
4. Improving job titles and formatting
5. Maintaining ATS compatibility

Return ONLY the optimized CV as a valid JSON object.`
  }
} as const;
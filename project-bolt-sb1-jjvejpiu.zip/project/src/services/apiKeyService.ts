import { supabase } from '../utils/supabase';
import { encryptApiKey, decryptApiKey } from '../utils/encryption';

export async function storeApiKey(keyName: string, apiKey: string) {
  const { encrypted, iv } = await encryptApiKey(apiKey);
  
  const { data, error } = await supabase
    .from('api_keys')
    .insert([
      { 
        key_name: keyName,
        encrypted_key: `${encrypted}:${iv}`
      }
    ]);

  if (error) throw error;
  return data;
}

export async function getApiKey(keyName: string): Promise<string> {
  const { data, error } = await supabase
    .from('api_keys')
    .select('encrypted_key')
    .eq('key_name', keyName)
    .single();

  if (error) throw error;
  if (!data) throw new Error('API key not found');

  const [encrypted, iv] = data.encrypted_key.split(':');
  return decryptApiKey(encrypted, iv);
}

export async function updateLastUsed(keyName: string) {
  const { error } = await supabase
    .from('api_keys')
    .update({ last_used: new Date().toISOString() })
    .eq('key_name', keyName);

  if (error) throw error;
}
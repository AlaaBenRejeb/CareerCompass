import type { CoverLetterFormData } from '../../types/coverLetter';

export class CoverLetterError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CoverLetterError';
  }
}

export interface CoverLetterPrompts {
  system: string;
  generateUser: (data: CoverLetterFormData) => string;
}
import { callGPTAPI } from '../gpt/client';
import { COVER_LETTER_PROMPTS } from './prompts';
import { CoverLetterError } from './types';
import type { CoverLetterFormData } from '../../types/coverLetter';

function validateInput(data: CoverLetterFormData) {
  if (!data.jobTitle?.trim()) {
    throw new CoverLetterError('Job title is required');
  }
  if (!data.company?.trim()) {
    throw new CoverLetterError('Company name is required');
  }
  if (!data.keySkills?.trim()) {
    throw new CoverLetterError('Key skills are required');
  }
  if (!data.relevantExperience?.trim()) {
    throw new CoverLetterError('Relevant experience is required');
  }
}

export async function generateCoverLetter(data: CoverLetterFormData): Promise<string> {
  try {
    validateInput(data);

    const response = await callGPTAPI(
      COVER_LETTER_PROMPTS.system,
      COVER_LETTER_PROMPTS.generateUser(data)
    );

    if (!response?.trim()) {
      throw new CoverLetterError('Failed to generate cover letter');
    }

    return response.trim();
  } catch (error) {
    console.error('Cover letter generation error:', error);
    
    if (error instanceof CoverLetterError) {
      throw error;
    }

    throw new CoverLetterError(
      error instanceof Error 
        ? error.message 
        : 'Failed to generate cover letter. Please try again.'
    );
  }
}
import type { CoverLetterPrompts } from './types';

export const COVER_LETTER_PROMPTS: CoverLetterPrompts = {
  system: `You are a professional cover letter writer. Create compelling, tailored cover letters that:
1. Are personalized to the specific role and company
2. Highlight relevant skills and experience
3. Show enthusiasm and cultural fit
4. Maintain a professional yet engaging tone
5. Follow standard cover letter format`,

  generateUser: (data) => `
Job Title: ${data.jobTitle}
Company: ${data.company}
Key Skills: ${data.keySkills}
Relevant Experience: ${data.relevantExperience}
Why Interested: ${data.whyInterested}
Additional Notes: ${data.additionalNotes || 'N/A'}

Please generate a professional cover letter that:
1. Is tailored to the specific role and company
2. Highlights relevant skills and experience
3. Shows enthusiasm and cultural fit
4. Maintains a professional yet engaging tone
5. Follows standard cover letter format`
};
export const ANALYSIS_PROMPTS = {
  analyzeInterview: {
    system: `You are an expert interview coach analyzing a technical interview. 
Provide detailed feedback on:
1. Overall performance (score out of 100)
2. Key strengths demonstrated
3. Areas needing improvement
4. Communication metrics
5. Specific recommendations for improvement

Base your analysis ONLY on the actual interview responses provided.`,
    generateUser: (transcript: string) => `Interview Transcript:
${transcript}

Analyze the interview responses and provide structured feedback covering all aspects mentioned above.
Be specific and reference actual examples from the transcript.`
  }
} as const;
import { callGPTAPI } from '../gpt/client';
import { ANALYSIS_PROMPTS } from './prompts';
import { parseAnalysisResponse } from './parser';
import type { InterviewFeedbackType } from '../../types/interview';

async function convertVideoToText(blob: Blob): Promise<string> {
  // In a real implementation, this would use a speech-to-text service
  // For now, we'll use the transcript from our speech recognition
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.readAsText(blob);
  });
}

export async function analyzeInterview(recordingBlob: Blob): Promise<InterviewFeedbackType> {
  try {
    const transcript = await convertVideoToText(recordingBlob);
    
    if (!transcript || transcript === "Mock interview transcript") {
      throw new Error("No valid interview transcript found");
    }

    const response = await callGPTAPI(
      ANALYSIS_PROMPTS.analyzeInterview.system,
      ANALYSIS_PROMPTS.analyzeInterview.generateUser(transcript)
    );

    return parseAnalysisResponse(response);
  } catch (error) {
    console.error('Interview analysis error:', error);
    throw new Error('Failed to analyze interview responses');
  }
}
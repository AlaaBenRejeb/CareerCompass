import type { InterviewFeedbackType } from '../../types/interview';

export interface TranscriptAnalysis {
  overallScore: number;
  strengths: string[];
  improvements: string[];
  communication: {
    clarity: number;
    confidence: number;
    engagement: number;
    pacing: number;
    pronunciation: number;
  };
  recommendations: string[];
}

export interface AnalysisPrompt {
  system: string;
  user: string;
}
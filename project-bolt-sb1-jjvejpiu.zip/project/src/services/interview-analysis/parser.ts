import type { InterviewFeedbackType } from '../../types/interview';

function extractScore(text: string): number {
  const scoreMatch = text.match(/(\d+)(?:\s*\/\s*100|\s*%)/);
  return scoreMatch ? parseInt(scoreMatch[1]) : 75;
}

function extractListSection(text: string, sectionName: string): string[] {
  const regex = new RegExp(`${sectionName}:?([^#]*?)(?=#|$)`, 'i');
  const match = text.match(regex);
  if (!match) return [];

  return match[1]
    .split(/\n|•|-/)
    .map(item => item.trim())
    .filter(item => item.length > 0);
}

function extractMetric(text: string, metricName: string): number {
  const regex = new RegExp(`${metricName}:?\\s*(\\d+)`, 'i');
  const match = text.match(regex);
  return match ? parseInt(match[1]) : 75;
}

export function parseAnalysisResponse(response: string): InterviewFeedbackType {
  try {
    const overallScore = extractScore(response);
    const strengths = extractListSection(response, 'Strengths');
    const improvements = extractListSection(response, 'Improvements');
    const recommendations = extractListSection(response, 'Recommendations');

    const communication = {
      clarity: extractMetric(response, 'Clarity'),
      confidence: extractMetric(response, 'Confidence'),
      engagement: extractMetric(response, 'Engagement'),
      pacing: extractMetric(response, 'Pacing'),
      pronunciation: extractMetric(response, 'Pronunciation')
    };

    return {
      overallScore,
      strengths,
      improvements,
      communication,
      recommendations
    };
  } catch (error) {
    console.error('Error parsing analysis response:', error);
    throw new Error('Failed to parse interview analysis');
  }
}
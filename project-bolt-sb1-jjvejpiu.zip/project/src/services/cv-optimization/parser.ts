import type { OptimizationResult } from './types';
import { isValidOptimizationResult } from './validation';

export function parseOptimizationResult(response: string): OptimizationResult {
  try {
    // Extract JSON object from response
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No valid JSON found in response');
    }

    let parsed;
    try {
      parsed = JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('JSON parse error:', error);
      throw new Error('Invalid JSON format in response');
    }

    // Validate result structure
    if (!isValidOptimizationResult(parsed)) {
      console.error('Invalid result structure:', parsed);
      throw new Error('Invalid optimization result structure');
    }

    // Format bullet points in experience descriptions
    if (parsed.cv) {
      parsed.cv.experience = parsed.cv.experience.map(exp => ({
        ...exp,
        description: formatBulletPoints(exp.description)
      }));
    }

    return {
      cv: parsed.cv,
      matchScore: parsed.matchScore,
      keywordMatches: {
        found: parsed.keywordMatches.found || [],
        missing: parsed.keywordMatches.missing || []
      },
      suggestions: parsed.suggestions || []
    };
  } catch (error) {
    console.error('Failed to parse optimization result:', error);
    throw error;
  }
}

function formatBulletPoints(description: string): string {
  if (!description) return '';

  // Split on common bullet point markers
  const bullets = description
    .split(/(?:\r?\n|\r)(?:•|-|\*|\d+\.)/)
    .map(bullet => bullet.trim())
    .filter(Boolean);

  // If no bullets found, treat as single bullet
  if (bullets.length === 0) {
    return description.trim();
  }

  // Format with consistent bullet points
  return bullets
    .map(bullet => bullet.replace(/^[•\-\*]\s*/, '').trim()) // Remove existing bullets
    .filter(Boolean) // Remove empty lines
    .join('\n• '); // Join with consistent bullet format
}
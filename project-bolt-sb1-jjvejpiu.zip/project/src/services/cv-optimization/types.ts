import type { CV } from '../../types/cv';

export interface OptimizationResult {
  cv: CV | null;
  matchScore: number;
  keywordMatches: {
    found: string[];
    missing: string[];
  };
  suggestions: string[];
}

export interface OptimizationError {
  message: string;
  code: string;
}
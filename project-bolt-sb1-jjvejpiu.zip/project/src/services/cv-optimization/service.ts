import { callGPTAPI } from '../gpt/client';
import { OPTIMIZATION_PROMPTS } from './prompts';
import { validateOptimizationInput } from './validation';
import { parseOptimizationResult } from './parser';
import type { CV } from '../../types/cv';
import type { OptimizationResult } from './types';

export class OptimizationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'OptimizationError';
  }
}

export async function optimizeCVForJob(cv: CV): Promise<OptimizationResult> {
  try {
    // Validate input CV
    validateOptimizationInput(cv);

    // Get optimization from GPT
    const response = await callGPTAPI(
      OPTIMIZATION_PROMPTS.optimization.system,
      OPTIMIZATION_PROMPTS.optimization.generateUser(cv)
    );

    // Parse and validate response
    const result = parseOptimizationResult(response);

    // If parsing failed or no CV returned, throw error
    if (!result.cv) {
      throw new OptimizationError('Failed to optimize CV');
    }

    // Preserve IDs from original CV
    result.cv.experience = result.cv.experience.map((exp, i) => ({
      ...exp,
      id: cv.experience[i]?.id || `exp-${Date.now()}-${i}`
    }));

    result.cv.education = result.cv.education.map((edu, i) => ({
      ...edu,
      id: cv.education[i]?.id || `edu-${Date.now()}-${i}`
    }));

    // Preserve languages
    result.cv.languages = cv.languages;

    return result;
  } catch (error) {
    console.error('CV optimization error:', error);
    throw error instanceof OptimizationError ? error : new OptimizationError('Failed to optimize CV');
  }
}
import type { CV } from '../../types/cv';
import type { OptimizationResult } from './types';

export function validateOptimizationInput(cv: CV): void {
  if (!cv || typeof cv !== 'object') {
    throw new Error('Invalid CV format');
  }

  // Validate personal info
  if (!cv.personalInfo || typeof cv.personalInfo !== 'object') {
    throw new Error('Missing or invalid personal information');
  }

  const requiredPersonalFields = ['fullName', 'email', 'phone', 'location', 'title'];
  for (const field of requiredPersonalFields) {
    if (!cv.personalInfo[field]) {
      throw new Error(`Missing required field: ${field}`);
    }
  }

  // Validate arrays
  if (!Array.isArray(cv.experience)) {
    throw new Error('Experience must be an array');
  }

  if (!Array.isArray(cv.education)) {
    throw new Error('Education must be an array');
  }

  if (!Array.isArray(cv.skills)) {
    throw new Error('Skills must be an array');
  }
}

export function isValidOptimizationResult(result: any): result is OptimizationResult {
  return (
    result &&
    typeof result === 'object' &&
    typeof result.matchScore === 'number' &&
    result.keywordMatches &&
    Array.isArray(result.keywordMatches.found) &&
    Array.isArray(result.keywordMatches.missing) &&
    Array.isArray(result.suggestions) &&
    (!result.cv || (
      typeof result.cv === 'object' &&
      result.cv.personalInfo &&
      Array.isArray(result.cv.experience) &&
      Array.isArray(result.cv.education) &&
      Array.isArray(result.cv.skills)
    ))
  );
}
import { callGPTAPI } from '../gpt/client';
import { INTERVIEW_PROMPTS } from './prompts';
import { InterviewError } from './errors';
import { validateInterviewState, validateResponse } from './validation';
import type { InterviewState } from './types';

// Keep track of conversation state
let conversationState = {
  questionCount: 0,
  lastResponse: '',
  lastFeedback: '',
  coveredTopics: new Set<string>()
};

export async function getNextQuestion(state: InterviewState): Promise<string> {
  try {
    // Validate state
    validateInterviewState(state);

    // Reset state for first question
    if (state.questionNumber === 1) {
      conversationState = {
        questionCount: 0,
        lastResponse: '',
        lastFeedback: '',
        coveredTopics: new Set()
      };
    }

    // Get next question from GPT
    const response = await callGPTAPI(
      INTERVIEW_PROMPTS.nextQuestion.system,
      INTERVIEW_PROMPTS.nextQuestion.generateUser(state)
    );

    if (!response?.trim()) {
      throw new InterviewError('Failed to generate interview question');
    }

    // Update conversation state
    conversationState.questionCount++;
    const question = response.split('\n')[0].trim();

    return question;
  } catch (error) {
    console.error('Interview service error:', error);
    throw error instanceof InterviewError 
      ? error 
      : new InterviewError('Failed to generate question. Please try again.');
  }
}

export async function evaluateResponse(
  response: string,
  question: string,
  jobContext: InterviewState['jobDetails']
): Promise<string> {
  try {
    // Validate inputs
    validateResponse(response, question);

    // Store last response
    conversationState.lastResponse = response;

    const feedback = await callGPTAPI(
      INTERVIEW_PROMPTS.evaluateResponse.system,
      INTERVIEW_PROMPTS.evaluateResponse.generateUser(question, response, jobContext)
    );

    if (!feedback?.trim()) {
      throw new InterviewError('Failed to generate feedback');
    }

    // Store feedback
    conversationState.lastFeedback = feedback;

    return feedback;
  } catch (error) {
    console.error('Response evaluation error:', error);
    throw error instanceof InterviewError 
      ? error 
      : new InterviewError('Failed to evaluate response. Please try again.');
  }
}
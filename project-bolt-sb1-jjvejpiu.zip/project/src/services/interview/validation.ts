import { InterviewError } from './errors';
import type { InterviewState } from './types';

export function validateInterviewState(state: InterviewState): void {
  if (!state?.jobDetails?.title?.trim()) {
    throw new InterviewError('Job title is required');
  }

  if (!state?.jobDetails?.description?.trim()) {
    throw new InterviewError('Job description is required');
  }

  if (!state?.cvText?.trim()) {
    throw new InterviewError('CV content is required');
  }

  if (!state?.context || !Array.isArray(state.context)) {
    throw new InterviewError('Invalid conversation context');
  }
}

export function validateResponse(response: string, question: string): void {
  if (!response?.trim()) {
    throw new InterviewError('Please provide a response to evaluate');
  }

  if (!question?.trim()) {
    throw new InterviewError('Question is required for evaluation');
  }
}
export class InterviewError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InterviewError';
  }
}
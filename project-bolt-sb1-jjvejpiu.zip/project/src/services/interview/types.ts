export interface InterviewContext {
  coveredTopics: string[];
  probeCount: number;
  lastTopicArea: string;
  jobContext: {
    title: string;
    description: string;
  };
}

export interface InterviewState {
  currentQuestion: string;
  questionNumber: number;
  context: string[];
  cvText: string;
  jobDetails: {
    title: string;
    description: string;
  };
}
import { callGPTAPI } from '../gpt';
import { AI_PROMPTS } from './prompts';

export async function enhanceText(text: string, context: string): Promise<string> {
  return callGPTAPI(AI_PROMPTS.textEnhancement.system, AI_PROMPTS.textEnhancement.generateUser(text, context));
}

export async function enhanceJobTitle(title: string): Promise<string> {
  return callGPTAPI(AI_PROMPTS.jobTitleEnhancement.system, AI_PROMPTS.jobTitleEnhancement.generateUser(title));
}

export async function enhanceSkill(skill: string): Promise<string> {
  return callGPTAPI(AI_PROMPTS.skillEnhancement.system, AI_PROMPTS.skillEnhancement.generateUser(skill));
}
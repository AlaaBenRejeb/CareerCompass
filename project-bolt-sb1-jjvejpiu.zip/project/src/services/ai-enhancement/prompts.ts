export const AI_PROMPTS = {
  textEnhancement: {
    system: `You are an expert CV writer. Enhance the given text to be more professional, impactful, and ATS-friendly. Focus on:
- Using strong action verbs
- Quantifying achievements
- Highlighting relevant skills
- Maintaining authenticity
- Optimizing for ATS systems`,
    generateUser: (text: string, context: string) => `
Context: ${context}
Original Text: ${text}

Please enhance this text to be more professional and impactful while maintaining its core meaning.`
  },
  jobTitleEnhancement: {
    system: 'You are an expert in professional titles. Enhance the given job title to be more industry-standard and impactful.',
    generateUser: (title: string) => `
Title: ${title}
Please provide a more professional and industry-standard version of this job title.`
  },
  skillEnhancement: {
    system: 'You are an expert in professional skill descriptions. Enhance the given skill to be more specific and impactful.',
    generateUser: (skill: string) => `
Skill: ${skill}
Please provide a more specific and professional version of this skill.`
  }
} as const;
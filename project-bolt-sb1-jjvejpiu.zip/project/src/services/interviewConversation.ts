import { callGPTAPI } from './gptService';

interface InterviewState {
  currentQuestion: string;
  questionNumber: number;
  context: string[];
}

interface QuestionContext {
  coveredTopics: string[];
  probeCount: number;
  lastTopicArea: string;
}

// Track interview context
const interviewContext: QuestionContext = {
  coveredTopics: [],
  probeCount: 0,
  lastTopicArea: ''
};

export async function getNextQuestion(state: InterviewState): Promise<string> {
  const systemPrompt = `You are an expert technical interviewer. Generate a single, focused question based on the context.
Rules:
1. If the previous response was weak/incomplete AND probeCount < 2, generate a follow-up question
2. Otherwise, move to a completely different technical topic
3. Keep questions specific and focused
4. Avoid topics already covered
5. Questions should be relevant to the position`;

  // Reset probe count when moving to new topic
  if (state.questionNumber === 1) {
    interviewContext.probeCount = 0;
    interviewContext.coveredTopics = [];
    interviewContext.lastTopicArea = '';
  }

  // Analyze previous response if available
  const previousResponse = state.context[state.context.length - 2]?.startsWith('A:') 
    ? state.context[state.context.length - 2].substring(3)
    : '';

  const previousFeedback = state.context[state.context.length - 1]?.startsWith('Feedback:')
    ? state.context[state.context.length - 1].substring(10)
    : '';

  const shouldProbe = previousResponse && (
    previousFeedback.toLowerCase().includes('could be more detailed') ||
    previousFeedback.toLowerCase().includes('needs improvement') ||
    previousFeedback.toLowerCase().includes('incomplete')
  );

  const userPrompt = `
Position and CV Context:
${state.context.slice(0, 2).join('\n')}

Previous Conversation:
${state.context.slice(2).join('\n')}

Current Question Number: ${state.questionNumber}
Probe Count: ${interviewContext.probeCount}
Covered Topics: ${interviewContext.coveredTopics.join(', ')}
Last Topic Area: ${interviewContext.lastTopicArea}

${shouldProbe && interviewContext.probeCount < 2 
  ? 'Generate a follow-up question to probe deeper into the previous topic.'
  : 'Generate a question on a new technical topic not yet covered.'}

Response should be a single, focused interview question.`;

  try {
    const response = await callGPTAPI(systemPrompt, userPrompt);
    const question = response.split('\n')[0].trim();

    // Update context
    if (shouldProbe && interviewContext.probeCount < 2) {
      interviewContext.probeCount++;
    } else {
      interviewContext.probeCount = 0;
      interviewContext.lastTopicArea = extractTopicArea(question);
      interviewContext.coveredTopics.push(interviewContext.lastTopicArea);
    }

    return question;
  } catch (error) {
    console.error('Failed to get next question:', error);
    throw new Error('Failed to generate next question');
  }
}

function extractTopicArea(question: string): string {
  // Extract main topic from question (simplified version)
  const topics = [
    'algorithms', 'data structures', 'system design', 'databases',
    'networking', 'security', 'frontend', 'backend', 'testing',
    'architecture', 'devops', 'cloud', 'performance'
  ];

  const questionLower = question.toLowerCase();
  return topics.find(topic => questionLower.includes(topic)) || 'general';
}

export async function evaluateResponse(response: string, question: string): Promise<string> {
  const systemPrompt = `You are an expert at evaluating technical interview responses from speech-to-text transcriptions. 
Consider that the response is transcribed speech, so:
- Ignore minor verbal fillers (um, uh, etc.)
- Focus on the core content and technical accuracy
- Be lenient with sentence structure and verbal patterns
- Look for key concepts and understanding rather than perfect articulation`;

  const userPrompt = `
Question: ${question}
Transcribed Response: ${response}

Evaluate the response considering it's a transcription of spoken words. Focus on:
1. Technical understanding and accuracy
2. Key points covered
3. Overall clarity of explanation

Provide brief, constructive feedback that acknowledges this is a transcribed verbal response.`;

  try {
    const feedback = await callGPTAPI(systemPrompt, userPrompt);
    return feedback;
  } catch (error) {
    console.error('Failed to evaluate response:', error);
    throw new Error('Failed to evaluate response');
  }
}
import { callGPTAPI } from './gptService';
import type { InterviewFeedbackType } from '../types/interview';

export async function analyzeInterview(recordingBlob: Blob): Promise<InterviewFeedbackType> {
  // For now, we'll focus on the transcript since we're using speech recognition
  const transcript = await convertVideoToText(recordingBlob);
  return analyzeTranscript(transcript);
}

async function convertVideoToText(blob: Blob): Promise<string> {
  // In a real implementation, this would use a speech-to-text service
  // For now, we'll use the transcript from our speech recognition
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.readAsText(blob);
  });
}

async function analyzeTranscript(transcript: string): Promise<InterviewFeedbackType> {
  if (!transcript || transcript === "Mock interview transcript") {
    throw new Error("No valid interview transcript found");
  }

  const systemPrompt = `You are an expert interview coach analyzing a technical interview. 
Provide detailed feedback on:
1. Overall performance (score out of 100)
2. Key strengths demonstrated
3. Areas needing improvement
4. Communication metrics
5. Specific recommendations for improvement

Base your analysis ONLY on the actual interview responses provided.`;

  const userPrompt = `Interview Transcript:
${transcript}

Analyze the interview responses and provide structured feedback covering all aspects mentioned above.
Be specific and reference actual examples from the transcript.`;

  try {
    const response = await callGPTAPI(systemPrompt, userPrompt);
    
    // Parse GPT response into structured feedback
    const analysis = parseGPTResponse(response);
    
    return analysis;
  } catch (error) {
    console.error('Interview analysis error:', error);
    throw new Error('Failed to analyze interview responses');
  }
}

function parseGPTResponse(response: string): InterviewFeedbackType {
  try {
    // Extract sections from GPT response
    const scoreMatch = response.match(/(\d+)(?:\s*\/\s*100|\s*%)/);
    const overallScore = scoreMatch ? parseInt(scoreMatch[1]) : 75;

    const strengths = extractListSection(response, 'Strengths');
    const improvements = extractListSection(response, 'Improvements');
    const recommendations = extractListSection(response, 'Recommendations');

    // Extract communication metrics
    const communication = {
      clarity: extractMetric(response, 'Clarity'),
      confidence: extractMetric(response, 'Confidence'),
      engagement: extractMetric(response, 'Engagement'),
      pacing: extractMetric(response, 'Pacing'),
      pronunciation: extractMetric(response, 'Pronunciation')
    };

    return {
      overallScore,
      strengths,
      improvements,
      communication,
      recommendations
    };
  } catch (error) {
    console.error('Error parsing GPT response:', error);
    throw new Error('Failed to parse interview analysis');
  }
}

function extractListSection(text: string, sectionName: string): string[] {
  const regex = new RegExp(`${sectionName}:?([^#]*?)(?=#|$)`, 'i');
  const match = text.match(regex);
  if (!match) return [];

  return match[1]
    .split(/\n|•|-/)
    .map(item => item.trim())
    .filter(item => item.length > 0);
}

function extractMetric(text: string, metricName: string): number {
  const regex = new RegExp(`${metricName}:?\\s*(\\d+)`, 'i');
  const match = text.match(regex);
  return match ? parseInt(match[1]) : 75;
}
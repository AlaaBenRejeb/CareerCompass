import { supabase } from '../utils/supabase';
import type { PaymentSession } from '../types/payment';

export async function createCheckoutSession(priceId: string): Promise<PaymentSession> {
  try {
    const { data: { session_url }, error } = await supabase.functions.invoke('create-checkout', {
      body: { priceId }
    });

    if (error) throw error;
    
    return {
      id: session_url.id,
      url: session_url.url
    };
  } catch (error) {
    console.error('Failed to create checkout session:', error);
    throw new Error('Failed to start payment process');
  }
}

export async function createPortalSession(): Promise<string> {
  try {
    const { data: { url }, error } = await supabase.functions.invoke('create-portal', {
      body: {}
    });

    if (error) throw error;
    return url;
  } catch (error) {
    console.error('Failed to create portal session:', error);
    throw new Error('Failed to access billing portal');
  }
}
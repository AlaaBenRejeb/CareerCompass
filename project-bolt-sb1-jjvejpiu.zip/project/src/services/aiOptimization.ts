import { CV } from '../types/cv';
import { callGPTAPI } from './gptService';
import { CV_BEST_PRACTICES } from '../utils/cvBestPractices';

export async function optimizeCVWithAI(cv: CV): Promise<CV> {
  const systemPrompt = `You are an expert CV optimizer. Enhance this CV while maintaining its core information and structure. Follow these best practices:
${Object.entries(CV_BEST_PRACTICES)
  .map(([category, practices]) => `${category.toUpperCase()}:\n${practices.join('\n')}`)
  .join('\n\n')}

IMPORTANT: Return the optimized CV as a valid JSON object with the exact same structure as the input.`;

  const userPrompt = `Original CV:
${JSON.stringify(cv, null, 2)}

Please optimize this CV by:
1. Using strong action verbs in experience descriptions
2. Quantifying achievements where possible
3. Enhancing skill descriptions
4. Improving job titles and formatting
5. Maintaining ATS compatibility

Return ONLY the optimized CV as a JSON object.`;

  try {
    const response = await callGPTAPI(systemPrompt, userPrompt);
    let optimizedCV: CV;

    try {
      // Find the JSON object in the response
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No valid JSON found in response');
      }

      optimizedCV = JSON.parse(jsonMatch[0]);

      // Validate the CV structure
      if (!validateCVStructure(optimizedCV)) {
        throw new Error('Invalid CV structure in response');
      }

      // Preserve IDs from original CV
      optimizedCV.experience = optimizedCV.experience.map((exp, i) => ({
        ...exp,
        id: cv.experience[i]?.id || String(Date.now() + i)
      }));

      optimizedCV.education = optimizedCV.education.map((edu, i) => ({
        ...edu,
        id: cv.education[i]?.id || String(Date.now() + i)
      }));

      return optimizedCV;
    } catch (parseError) {
      console.error('Parse error:', parseError);
      throw new Error('Failed to parse AI response');
    }
  } catch (error) {
    console.error('Optimization error:', error);
    throw new Error(error instanceof Error ? error.message : 'Failed to optimize CV');
  }
}

function validateCVStructure(cv: any): cv is CV {
  return (
    cv &&
    typeof cv === 'object' &&
    cv.personalInfo &&
    typeof cv.personalInfo === 'object' &&
    typeof cv.personalInfo.fullName === 'string' &&
    typeof cv.personalInfo.email === 'string' &&
    typeof cv.personalInfo.phone === 'string' &&
    typeof cv.personalInfo.location === 'string' &&
    typeof cv.personalInfo.title === 'string' &&
    Array.isArray(cv.experience) &&
    Array.isArray(cv.education) &&
    Array.isArray(cv.skills)
  );
}
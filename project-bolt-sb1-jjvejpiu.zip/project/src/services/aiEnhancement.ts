import { callGPTAPI } from './gpt';

export async function enhanceText(text: string, context: string): Promise<string> {
  const systemPrompt = `You are an expert CV writer. Enhance the given text to be more professional, impactful, and ATS-friendly. Focus on:
- Using strong action verbs
- Quantifying achievements
- Highlighting relevant skills
- Maintaining authenticity
- Optimizing for ATS systems`;

  const userPrompt = `Context: ${context}
Original Text: ${text}

Please enhance this text to be more professional and impactful while maintaining its core meaning.`;

  return callGPTAPI(systemPrompt, userPrompt);
}

export async function enhanceJobTitle(title: string): Promise<string> {
  const systemPrompt = `You are an expert in professional titles. Enhance the given job title to be more industry-standard and impactful.`;
  
  const userPrompt = `Title: ${title}
Please provide a more professional and industry-standard version of this job title.`;

  return callGPTAPI(systemPrompt, userPrompt);
}

export async function enhanceSkill(skill: string): Promise<string> {
  const systemPrompt = `You are an expert in professional skill descriptions. Enhance the given skill to be more specific and impactful.`;
  
  const userPrompt = `Skill: ${skill}
Please provide a more specific and professional version of this skill.`;

  return callGPTAPI(systemPrompt, userPrompt);
}
import { CV } from '../../types/cv';
import { optimizePersonalInfo } from './personalInfoOptimizer';
import { optimizeExperience } from './experienceOptimizer';
import { optimizeEducation } from './educationOptimizer';
import { optimizeSkills } from './skillsOptimizer';
import { validateCV } from '../../utils/validation';

export async function optimizeCV(cv: CV): Promise<CV> {
  try {
    const optimizedCV: CV = {
      personalInfo: await optimizePersonalInfo(cv.personalInfo),
      experience: await optimizeExperience(cv.experience),
      education: await optimizeEducation(cv.education),
      skills: await optimizeSkills(cv.skills)
    };

    validateCV(optimizedCV);
    return optimizedCV;
  } catch (error) {
    console.error('CV optimization error:', error);
    throw new Error('Failed to optimize CV');
  }
}
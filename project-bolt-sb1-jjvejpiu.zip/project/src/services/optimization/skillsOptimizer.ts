import { callGPTAPI } from '../gptService';
import { SKILLS_LIST } from '../../data/skillsList';

export async function optimizeSkills(skills: string[]): Promise<string[]> {
  const systemPrompt = `You are a CV optimization expert. Enhance these skills while maintaining ATS compatibility and industry standards. Available skill categories:
${Object.keys(SKILLS_LIST).join(', ')}`;

  const userPrompt = `Original skills:
${JSON.stringify(skills, null, 2)}

Optimize by:
1. Using standard industry terminology
2. Organizing by relevance
3. Removing duplicates or overlapping skills
4. Ensuring ATS compatibility

Return ONLY the optimized skills array as a JSON array of strings.`;

  try {
    const response = await callGPTAPI(systemPrompt, userPrompt);
    const optimized = JSON.parse(response);
    return optimized;
  } catch (error) {
    console.error('Skills optimization error:', error);
    return skills;
  }
}
import { Experience } from '../../types/cv';
import { callGPTAPI } from '../gptService';
import { ACTION_VERBS } from '../../utils/cvBestPractices';

export async function optimizeExperience(experience: Experience[]): Promise<Experience[]> {
  const systemPrompt = `You are a CV optimization expert. Enhance these experience entries using strong action verbs and quantifiable achievements. Available action verbs:
${ACTION_VERBS.join(', ')}`;

  const userPrompt = `Original experience:
${JSON.stringify(experience, null, 2)}

Optimize by:
1. Starting bullet points with strong action verbs
2. Quantifying achievements where possible
3. Focusing on impact and results
4. Maintaining ATS compatibility

Return ONLY the optimized experience array as a JSON object.`;

  try {
    const response = await callGPTAPI(systemPrompt, userPrompt);
    const optimized = JSON.parse(response);
    return optimized.map((exp: Experience, i: number) => ({
      ...exp,
      id: experience[i]?.id || String(Date.now() + i)
    }));
  } catch (error) {
    console.error('Experience optimization error:', error);
    return experience;
  }
}
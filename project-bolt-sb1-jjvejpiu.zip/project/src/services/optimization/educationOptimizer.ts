import { Education } from '../../types/cv';
import { callGPTAPI } from '../gptService';

export async function optimizeEducation(education: Education[]): Promise<Education[]> {
  const systemPrompt = `You are a CV optimization expert. Enhance these education entries while maintaining clarity and ATS compatibility.`;

  const userPrompt = `Original education:
${JSON.stringify(education, null, 2)}

Optimize by:
1. Using standard degree terminology
2. Ensuring proper date formatting
3. Highlighting relevant coursework or achievements
4. Maintaining consistency

Return ONLY the optimized education array as a JSON object.`;

  try {
    const response = await callGPTAPI(systemPrompt, userPrompt);
    const optimized = JSON.parse(response);
    return optimized.map((edu: Education, i: number) => ({
      ...edu,
      id: education[i]?.id || String(Date.now() + i)
    }));
  } catch (error) {
    console.error('Education optimization error:', error);
    return education;
  }
}
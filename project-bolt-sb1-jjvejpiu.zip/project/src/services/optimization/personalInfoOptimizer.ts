import { PersonalInfo } from '../../types/cv';
import { callGPTAPI } from '../gptService';
import { CV_BEST_PRACTICES } from '../../utils/cvBestPractices';

export async function optimizePersonalInfo(info: PersonalInfo): Promise<PersonalInfo> {
  const systemPrompt = `You are a CV optimization expert. Enhance this personal information section while maintaining professionalism and ATS compatibility. Follow these best practices:
${CV_BEST_PRACTICES.general.join('\n')}`;

  const userPrompt = `Original personal info:
${JSON.stringify(info, null, 2)}

Please optimize by:
1. Improving job title clarity and impact
2. Ensuring proper formatting
3. Maintaining professionalism

Return ONLY the optimized personal info as a JSON object.`;

  try {
    const response = await callGPTAPI(systemPrompt, userPrompt);
    const optimized = JSON.parse(response);
    return optimized;
  } catch (error) {
    console.error('Personal info optimization error:', error);
    return info;
  }
}
import { supabase } from '../../utils/supabase';
import type { PricingPlan, PaymentSession, SubscriptionStatus } from '../../types/payment';

export class PaymentError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PaymentError';
  }
}

export async function getPricingPlans(): Promise<PricingPlan[]> {
  try {
    const { data: plans, error } = await supabase
      .from('pricing_plans')
      .select('*')
      .eq('active', true)
      .order('price');

    if (error) throw error;
    if (!plans?.length) throw new PaymentError('No pricing plans available');

    return plans;
  } catch (error) {
    console.error('Failed to get pricing plans:', error);
    throw new PaymentError('Failed to load pricing plans');
  }
}

export async function getSubscriptionStatus(): Promise<SubscriptionStatus> {
  try {
    const { data: subscription, error } = await supabase
      .from('subscriptions')
      .select(`
        *,
        pricing_plans (
          id,
          name,
          price,
          interval,
          features
        )
      `)
      .single();

    if (error && error.code !== 'PGRST116') throw error;

    if (!subscription) {
      return {
        isActive: false,
        plan: null,
        currentPeriodEnd: null,
        cancelAtPeriodEnd: false
      };
    }

    return {
      isActive: subscription.status === 'active' || subscription.status === 'trialing',
      plan: subscription.pricing_plans,
      currentPeriodEnd: subscription.current_period_end,
      cancelAtPeriodEnd: subscription.cancel_at_period_end
    };
  } catch (error) {
    console.error('Failed to get subscription status:', error);
    throw new PaymentError('Failed to load subscription status');
  }
}

export async function createCheckoutSession(priceId: string): Promise<PaymentSession> {
  try {
    if (!priceId) {
      throw new PaymentError('Price ID is required');
    }

    const { data, error } = await supabase.functions.invoke('create-checkout-session', {
      body: { priceId }
    });

    if (error) throw error;
    if (!data?.url) throw new PaymentError('Invalid checkout session response');

    return {
      id: data.sessionId,
      url: data.url
    };
  } catch (error) {
    console.error('Failed to create checkout session:', error);
    throw new PaymentError('Failed to initiate payment process');
  }
}

export async function createPortalSession(): Promise<string> {
  try {
    const { data, error } = await supabase.functions.invoke('create-portal-session');

    if (error) throw error;
    if (!data?.url) throw new PaymentError('Invalid portal session response');

    return data.url;
  } catch (error) {
    console.error('Failed to create portal session:', error);
    throw new PaymentError('Failed to access billing portal');
  }
}
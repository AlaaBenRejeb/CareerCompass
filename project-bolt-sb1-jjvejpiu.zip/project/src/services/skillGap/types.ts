export interface SkillGapFormData {
  targetRole: string;
  currentSkills: string[];
  experience: string;
  industry: string;
  careerGoals: string;
}

export interface LearningResource {
  title: string;
  type: 'course' | 'certification' | 'tutorial';
  provider: string;
  url?: string;
  duration?: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  description: string;
}

export interface SkillGapAnalysis {
  skillGapScore: number;
  missingSkills: string[];
  recommendedSkills: {
    skill: string;
    priority: 'high' | 'medium' | 'low';
    reason: string;
  }[];
  learningPath: {
    immediate: LearningResource[];
    shortTerm: LearningResource[];
    longTerm: LearningResource[];
  };
  industryInsights: string[];
}
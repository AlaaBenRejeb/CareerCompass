import type { SkillGapFormData } from '../../types/skillGap';

export function validateSkillGapInput(formData: SkillGapFormData, cvText: string): void {
  if (!formData.targetRole) {
    throw new Error('Target role is required');
  }

  if (!formData.currentSkills.length) {
    throw new Error('At least one current skill is required');
  }

  if (!cvText.trim()) {
    throw new Error('CV content is required for analysis');
  }

  if (!formData.experience) {
    throw new Error('Experience level is required');
  }

  if (!formData.industry) {
    throw new Error('Industry is required');
  }

  if (!formData.careerGoals) {
    throw new Error('Career goals are required');
  }

  // Validate URLs in learning resources
  const urlPattern = /^https:\/\/(www\.)?(coursera|edx|udacity|linkedin|aws|google|microsoft|pluralsight)\.[a-z]+/;
  
  return {
    validateResourceUrl: (url: string): boolean => {
      if (!url) return false;
      return urlPattern.test(url);
    }
  };
}
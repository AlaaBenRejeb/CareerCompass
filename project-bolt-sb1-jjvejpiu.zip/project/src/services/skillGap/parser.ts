import type { SkillGapAnalysis, LearningResource } from './types';

function extractSkillScore(text: string): number {
  try {
    const match = text.match(/(?:Gap Score|Skill Match|Score):\s*(\d+)/i);
    return match ? Math.min(100, Math.max(0, parseInt(match[1], 10))) : 50;
  } catch {
    return 50; // Default score if parsing fails
  }
}

function extractMissingSkills(text: string): string[] {
  try {
    const section = text.match(/Missing Skills:([^]*?)(?=\n\n|Recommended Skills:|$)/i);
    if (!section) return [];

    return section[1]
      .split('\n')
      .map(line => {
        const parts = line.replace(/^[-•*]\s*/, '').split('|');
        return parts[0]?.trim() || '';
      })
      .filter(Boolean);
  } catch {
    return [];
  }
}

function extractRecommendedSkills(text: string): SkillGapAnalysis['recommendedSkills'] {
  try {
    const section = text.match(/Recommended Skills:([^]*?)(?=\n\n|Learning Path:|$)/i);
    if (!section) return [];

    return section[1]
      .split('\n')
      .map(line => {
        const [skill, priority = 'medium', ...reasonParts] = line
          .replace(/^[-•*]\s*/, '')
          .split('|')
          .map(s => s.trim());

        if (!skill) return null;

        return {
          skill,
          priority: (priority?.toLowerCase() || 'medium') as 'high' | 'medium' | 'low',
          reason: reasonParts.join(' - ').trim() || 'Important for target role'
        };
      })
      .filter((item): item is NonNullable<typeof item> => Boolean(item));
  } catch {
    return [];
  }
}

function extractLearningPath(text: string): SkillGapAnalysis['learningPath'] {
  try {
    const sections = {
      immediate: extractPathSection(text, 'Immediate Actions'),
      shortTerm: extractPathSection(text, 'Short-term Goals'),
      longTerm: extractPathSection(text, 'Long-term Goals')
    };

    // Ensure at least one item in each section
    if (!sections.immediate.length && !sections.shortTerm.length && !sections.longTerm.length) {
      sections.immediate = generateDefaultResources('immediate');
    }

    return sections;
  } catch {
    return {
      immediate: generateDefaultResources('immediate'),
      shortTerm: [],
      longTerm: []
    };
  }
}

function extractPathSection(text: string, section: string): LearningResource[] {
  try {
    const sectionRegex = new RegExp(`${section}:([^]*?)(?=\\n\\n|Short-term Goals:|Long-term Goals:|Industry Insights:|$)`, 'i');
    const sectionMatch = text.match(sectionRegex);
    if (!sectionMatch) return [];

    return sectionMatch[1]
      .split('\n')
      .map(line => {
        const parts = line.replace(/^[-•*]\s*/, '').split('|').map(s => s.trim());
        if (parts.length < 2) return null;

        const [title, type = 'course', provider = 'Various', duration, level = 'beginner', ...descParts] = parts;
        const description = descParts.join(' - ').trim();
        const url = extractUrl(line);

        if (!title) return null;

        return {
          title,
          type: (type?.toLowerCase() || 'course') as 'course' | 'certification' | 'tutorial',
          provider,
          duration: duration || undefined,
          level: (level?.toLowerCase() || 'beginner') as 'beginner' | 'intermediate' | 'advanced',
          description: description || title,
          url
        };
      })
      .filter((item): item is LearningResource => Boolean(item));
  } catch {
    return [];
  }
}

function extractUrl(text: string): string | undefined {
  try {
    const urlMatch = text.match(/https?:\/\/[^\s|)]+/);
    return urlMatch ? urlMatch[0] : undefined;
  } catch {
    return undefined;
  }
}

function extractInsights(text: string): string[] {
  try {
    const section = text.match(/Industry Insights:([^]*?)(?=\n\n|$)/i);
    if (!section) return generateDefaultInsights();

    const insights = section[1]
      .split('\n')
      .map(line => line.replace(/^[-•*]\s*/, '').trim())
      .filter(Boolean);

    return insights.length ? insights : generateDefaultInsights();
  } catch {
    return generateDefaultInsights();
  }
}

function generateDefaultResources(type: 'immediate' | 'shortTerm' | 'longTerm'): LearningResource[] {
  return [{
    title: 'Online Learning Platform Subscription',
    type: 'course',
    provider: 'Coursera/Udemy',
    duration: '3 months',
    level: 'beginner',
    description: 'Access to comprehensive learning resources and practical projects',
    url: 'https://www.coursera.org'
  }];
}

function generateDefaultInsights(): string[] {
  return [
    'Focus on continuous learning and skill development',
    'Stay updated with industry trends and emerging technologies',
    'Build a portfolio of practical projects to demonstrate skills'
  ];
}

export function parseSkillGapResponse(response: string): SkillGapAnalysis {
  if (!response) {
    throw new Error('No response received from analysis service');
  }

  try {
    return {
      skillGapScore: extractSkillScore(response),
      missingSkills: extractMissingSkills(response),
      recommendedSkills: extractRecommendedSkills(response),
      learningPath: extractLearningPath(response),
      industryInsights: extractInsights(response)
    };
  } catch (error) {
    console.error('Failed to parse skill gap response:', error);
    throw new Error('Failed to process analysis results');
  }
}
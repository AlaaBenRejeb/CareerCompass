import { callGPTAPI } from '../gpt/client';
import { SKILL_GAP_PROMPTS } from './prompts';
import type { SkillGapAnalysis, SkillGapFormData } from './types';
import { parseSkillGapResponse } from './parser';
import { validateSkillGapInput } from './validation';

export async function analyzeSkillGap(formData: SkillGapFormData, cvText: string): Promise<SkillGapAnalysis> {
  try {
    // Validate input
    validateSkillGapInput(formData, cvText);

    // Get analysis from GPT
    const response = await callGPTAPI(
      SKILL_GAP_PROMPTS.analysis.system,
      SKILL_GAP_PROMPTS.analysis.generateUser(formData, cvText)
    );

    // Parse and validate response
    const analysis = parseSkillGapResponse(response);

    // Ensure we have valid data
    if (!analysis.missingSkills.length && !analysis.recommendedSkills.length) {
      throw new Error('Failed to generate meaningful skill analysis');
    }

    return analysis;
  } catch (error) {
    console.error('Skill gap analysis error:', error);
    
    // Return a user-friendly error
    throw new Error(
      error instanceof Error 
        ? error.message 
        : 'Failed to analyze skills. Please try again.'
    );
  }
}
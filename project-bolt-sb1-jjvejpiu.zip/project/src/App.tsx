import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Navbar } from './components/Navigation/Navbar';
import { Footer } from './components/Footer/Footer';
import { LandingPage } from './components/Landing/LandingPage';
import { DashboardPage } from './components/Dashboard';
import { AuthPage } from './components/Auth/AuthPage';
import { CVBuilder } from './components/CVBuilder';
import { CVAnalyzer } from './components/CVAnalyzer';
import { SkillGapAnalyzer } from './components/SkillGap';
import { CoverLetterForm } from './components/CoverLetter';
import { VideoInterview } from './components/Interview';
import { SettingsPage } from './components/Settings/SettingsPage';
import { PricingPage } from './components/Pricing/PricingPage';
import { PrivacyPolicy, TermsOfUse } from './components/Legal';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="min-h-screen flex flex-col">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/auth" element={<AuthPage />} />
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <DashboardPage />
                </ProtectedRoute>
              } />
              <Route path="/cv-builder" element={
                <ProtectedRoute>
                  <CVBuilder />
                </ProtectedRoute>
              } />
              <Route path="/analyze" element={
                <ProtectedRoute>
                  <CVAnalyzer />
                </ProtectedRoute>
              } />
              <Route path="/skills" element={
                <ProtectedRoute>
                  <SkillGapAnalyzer />
                </ProtectedRoute>
              } />
              <Route path="/cover-letter" element={
                <ProtectedRoute>
                  <CoverLetterForm />
                </ProtectedRoute>
              } />
              <Route path="/interview" element={
                <ProtectedRoute>
                  <VideoInterview />
                </ProtectedRoute>
              } />
              <Route path="/settings" element={
                <ProtectedRoute>
                  <SettingsPage />
                </ProtectedRoute>
              } />
              <Route path="/pricing" element={<PricingPage />} />
              <Route path="/privacy" element={<PrivacyPolicy />} />
              <Route path="/terms" element={<TermsOfUse />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}
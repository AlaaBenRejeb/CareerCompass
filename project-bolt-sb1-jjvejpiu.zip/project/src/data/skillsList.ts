export const SKILLS_LIST = {
  technical: {
    "Programming Languages": [
      "JavaScript", "TypeScript", "Python", "Java", "C++", "C#", "Ruby", "PHP", "Swift", "Kotlin", "Go",
      "Rust", "SQL", "HTML", "CSS", "Scala", "R", "MATLAB", "Shell Scripting", "Perl"
    ],
    "Web Development": [
      "React", "Angular", "Vue.js", "Node.js", "Express.js", "Django", "Flask", "Ruby on Rails", 
      "Spring Boot", "ASP.NET", "Laravel", "GraphQL", "REST APIs", "WebSockets", "Microservices"
    ],
    "Database": [
      "MySQL", "PostgreSQL", "MongoDB", "Redis", "Oracle", "SQL Server", "Firebase", "Elasticsearch",
      "DynamoDB", "Cassandra", "Neo4j", "MariaDB", "SQLite"
    ],
    "Cloud & DevOps": [
      "AWS", "Azure", "Google Cloud", "Docker", "Kubernetes", "Jenkins", "GitLab CI/CD", "Terraform",
      "Ansible", "Prometheus", "ELK Stack", "Nginx", "Apache", "Linux Administration"
    ],
    "Mobile Development": [
      "iOS Development", "Android Development", "React Native", "Flutter", "Xamarin", "SwiftUI",
      "Kotlin Android", "Mobile App Testing", "App Store Optimization", "Mobile UI/UX"
    ]
  },
  business: {
    "Project Management": [
      "Agile Methodologies", "Scrum", "Kanban", "JIRA", "Confluence", "Risk Management",
      "Stakeholder Management", "Budget Planning", "Resource Allocation", "Project Planning"
    ],
    "Analysis": [
      "Business Analysis", "Data Analysis", "Requirements Gathering", "Process Mapping",
      "Market Research", "Competitive Analysis", "Financial Analysis", "Statistical Analysis"
    ],
    "Marketing": [
      "Digital Marketing", "SEO", "Content Marketing", "Social Media Marketing", "Email Marketing",
      "Google Analytics", "Marketing Automation", "Brand Management", "Growth Hacking"
    ]
  },
  soft: {
    "Leadership": [
      "Team Leadership", "Strategic Planning", "Decision Making", "Mentoring", "Coaching",
      "Change Management", "Conflict Resolution", "Performance Management"
    ],
    "Communication": [
      "Written Communication", "Verbal Communication", "Presentation Skills", "Public Speaking",
      "Technical Writing", "Client Communication", "Cross-functional Collaboration"
    ],
    "Personal": [
      "Problem Solving", "Critical Thinking", "Time Management", "Adaptability", "Creativity",
      "Emotional Intelligence", "Work Ethic", "Attention to Detail", "Organization"
    ]
  }
};
export const featureDescriptions = {
  cvBuilder: {
    title: "CV Builder",
    description: "Create professional, ATS-friendly CVs with our intuitive builder. Our AI-powered platform helps you highlight your achievements and stand out to employers.",
  },
  cvAnalyzer: {
    title: "CV Analyzer",
    description: "Get instant feedback on your CV. Our AI analyzes your resume against job descriptions, providing actionable insights to improve your chances of landing interviews.",
  },
  skillGap: {
    title: "Skills Analysis",
    description: "Identify skill gaps between your current profile and dream job. Get personalized learning recommendations and track your professional development.",
  },
  coverLetter: {
    title: "Cover Letter Generator",
    description: "Create compelling, customized cover letters in minutes. Our AI helps you highlight relevant experience and showcase your enthusiasm for each role.",
  },
  interview: {
    title: "AI Interview Practice",
    description: "Practice interviews with our AI interviewer. Get real-time feedback on your responses and improve your interview performance with industry-specific questions.",
  }
};
import { jsPDF } from 'jspdf';
import type { CV, Language } from '../types/cv';

interface PDFGeneratorOptions {
  filename?: string;
  margin?: number;
  fontSize?: {
    title: number;
    heading: number;
    normal: number;
  };
}

const defaultOptions: PDFGeneratorOptions = {
  margin: 20,
  fontSize: {
    title: 20,
    heading: 16,
    normal: 12
  }
};

function addLanguagesSection(doc: jsPDF, languages: Language[], yPos: number, margin: number, fontSize: PDFGeneratorOptions['fontSize']): number {
  if (languages.length === 0) return yPos;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(fontSize.heading);
  doc.text('Languages', margin, yPos);
  yPos += 8;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(fontSize.normal);

  languages.forEach(lang => {
    doc.text(`${lang.name} - ${lang.proficiency}`, margin, yPos);
    yPos += 6;
  });

  return yPos + 4;
}

export function generatePDF(cv: CV, options: PDFGeneratorOptions = {}) {
  const { margin, fontSize } = { ...defaultOptions, ...options };
  const doc = new jsPDF();
  let yPos = margin;

  // Generate filename from user's name or use default
  const filename = options.filename || 
    `${cv.personalInfo.fullName.toLowerCase().replace(/\s+/g, '')}.pdf`;

  // Personal Info Section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(fontSize.title);
  doc.text(cv.personalInfo.fullName, margin, yPos);
  yPos += 10;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(fontSize.normal);
  doc.text(cv.personalInfo.title, margin, yPos);
  yPos += 6;
  doc.text(cv.personalInfo.email, margin, yPos);
  yPos += 6;
  doc.text(cv.personalInfo.phone, margin, yPos);
  yPos += 6;
  doc.text(cv.personalInfo.location, margin, yPos);
  yPos += 15;

  // Experience Section
  yPos = addSection(doc, 'Professional Experience', cv.experience.map(exp => ({
    title: exp.position,
    subtitle: `${exp.company} | ${exp.startDate} - ${exp.endDate}`,
    description: exp.description
  })), yPos, margin, fontSize);

  // Education Section
  yPos = addSection(doc, 'Education', cv.education.map(edu => ({
    title: edu.degree,
    subtitle: `${edu.institution} | ${edu.startDate} - ${edu.endDate}`,
    description: edu.field
  })), yPos, margin, fontSize);

  // Skills Section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(fontSize.heading);
  doc.text('Skills', margin, yPos);
  yPos += 10;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(fontSize.normal);
  const skillsText = cv.skills.join(', ');
  const skillsLines = doc.splitTextToSize(skillsText, 170);
  skillsLines.forEach(line => {
    doc.text(line, margin, yPos);
    yPos += 6;
  });

  // Languages Section
  yPos = addLanguagesSection(doc, cv.languages || [], yPos + 10, margin, fontSize);

  // Save the PDF with the custom filename
  doc.save(filename);
}

interface SectionItem {
  title: string;
  subtitle: string;
  description: string;
}

function addSection(
  doc: jsPDF,
  title: string,
  items: SectionItem[],
  startY: number,
  margin: number,
  fontSize: PDFGeneratorOptions['fontSize']
): number {
  let yPos = startY;

  // Section Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(fontSize.heading);
  doc.text(title, margin, yPos);
  yPos += 10;

  // Section Items
  items.forEach(item => {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(fontSize.normal);
    doc.text(item.title, margin, yPos);
    yPos += 6;

    doc.setFont('helvetica', 'normal');
    doc.text(item.subtitle, margin, yPos);
    yPos += 6;

    const descriptionLines = doc.splitTextToSize(item.description, 170);
    descriptionLines.forEach(line => {
      doc.text(line, margin, yPos);
      yPos += 6;
    });
    yPos += 4;
  });

  return yPos;
}
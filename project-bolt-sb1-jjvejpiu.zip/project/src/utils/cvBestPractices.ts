export const CV_BEST_PRACTICES = {
  general: [
    'Use consistent formatting throughout the document',
    'Keep to 1-2 pages maximum',
    'Use reverse chronological order for experience',
    'Include measurable achievements and metrics',
    'Avoid personal pronouns (I, me, my)',
  ],
  
  atsOptimization: [
    'Use standard section headings (Experience, Education, Skills)',
    'Avoid tables, images, and complex formatting',
    'Include keywords from the job description',
    'Use standard job titles',
    'Spell out acronyms at least once',
  ],
  
  content: [
    'Start bullet points with strong action verbs',
    'Focus on achievements rather than duties',
    'Quantify results where possible',
    'Tailor content to the specific job',
    'Remove outdated or irrelevant information',
  ],
  
  formatting: [
    'Use standard fonts (Arial, Calibri, Times New Roman)',
    'Keep font size between 10-12 points',
    'Use clear section headings',
    'Maintain consistent spacing',
    'Use bullet points for better readability',
  ]
};

export const ACTION_VERBS = [
  'Achieved', 'Developed', 'Implemented', 'Increased', 'Launched',
  'Managed', 'Optimized', 'Reduced', 'Streamlined', 'Transformed'
];

export const SKILLS_BY_CATEGORY = {
  technical: [
    'Programming Languages',
    'Software Development',
    'Database Management',
    'Cloud Computing',
    'DevOps',
  ],
  soft: [
    'Leadership',
    'Communication',
    'Problem Solving',
    'Team Collaboration',
    'Project Management',
  ],
  business: [
    'Strategic Planning',
    'Data Analysis',
    'Process Improvement',
    'Client Relations',
    'Budget Management',
  ]
};
import { AnalysisResult } from '../types/analysis';

export class ParserError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ParserError';
  }
}

export function parseGPTResponse(response: string, includeJobMatch: boolean): AnalysisResult {
  try {
    if (!response?.trim()) {
      throw new ParserError('Empty response received');
    }

    // Extract scores using more robust regex patterns
    const overallScore = extractScore(response, 'Overall Match|Overall Score|Match Score');
    const jobMatchScore = includeJobMatch ? extractScore(response, 'Job Fit|Job Match|Position Match') : 0;

    // Extract keywords with improved patterns
    const foundKeywords = extractKeywords(response, 'Found Keywords|Matching Keywords|Present Keywords');
    const missingKeywords = extractKeywords(response, 'Missing Keywords|Absent Keywords|Required Keywords');

    // Extract experience and qualifications
    const relevantExperience = extractBulletPoints(response, 'Relevant Experience|Matching Experience|Experience Matches');
    const missingQualifications = extractBulletPoints(response, 'Missing Qualifications|Required Qualifications|Qualification Gaps');

    // Extract suggestions
    const suggestions = extractBulletPoints(response, 'Suggestions|Improvements|Recommendations');

    // Validate extracted data
    if (!Array.isArray(foundKeywords) || !Array.isArray(missingKeywords) || !Array.isArray(suggestions)) {
      throw new ParserError('Invalid data structure in response');
    }

    return {
      score: overallScore,
      keywords: {
        found: foundKeywords,
        missing: missingKeywords
      },
      suggestions,
      jobMatch: includeJobMatch ? {
        score: jobMatchScore,
        relevantExperience,
        missingQualifications
      } : undefined
    };
  } catch (error) {
    console.error('Error parsing analysis response:', error);
    throw new ParserError('Failed to process analysis results');
  }
}

function extractScore(text: string, patterns: string): number {
  try {
    const regex = new RegExp(`(${patterns})(?:[^\\d]*)(\\d+)(?:\\s*%|\\s*\\/\\s*100)?`, 'i');
    const match = text.match(regex);
    return match ? Math.min(100, Math.max(0, parseInt(match[2], 10))) : 50;
  } catch {
    return 50; // Default score if extraction fails
  }
}

function extractKeywords(text: string, patterns: string): string[] {
  try {
    const regex = new RegExp(`(${patterns})[^:]*:([^\\n]+)`, 'i');
    const match = text.match(regex);
    if (!match) return [];
    
    return match[2]
      .split(/[,;]/)
      .map(k => k.trim())
      .filter(k => k.length > 0);
  } catch {
    return [];
  }
}

function extractBulletPoints(text: string, patterns: string): string[] {
  try {
    const regex = new RegExp(`(${patterns})[^:]*:([^]*?)(?=\\n\\s*[A-Z]|$)`, 'i');
    const match = text.match(regex);
    if (!match) return [];

    return match[2]
      .split(/\n/)
      .map(line => line.replace(/^[-•*]\s*/, '').trim())
      .filter(line => line.length > 0);
  } catch {
    return [];
  }
}
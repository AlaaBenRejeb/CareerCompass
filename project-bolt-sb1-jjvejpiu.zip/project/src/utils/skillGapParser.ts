import { SkillGapAnalysis, LearningResource } from '../types/skillGap';

function extractSkills(text: string, sectionName: string): string[] {
  const regex = new RegExp(`${sectionName}:\\s*([^\\n]+)`, 'i');
  const match = text.match(regex);
  return match ? match[1].split(',').map(s => s.trim()).filter(Boolean) : [];
}

function extractScore(text: string): number {
  const match = text.match(/Skill Gap Score:\s*(\d+)/i);
  return match ? parseInt(match[1], 10) : 0;
}

function extractRecommendedSkills(text: string): SkillGapAnalysis['recommendedSkills'] {
  const skills: SkillGapAnalysis['recommendedSkills'] = [];
  const lines = text.split('\n');
  let inSection = false;

  for (const line of lines) {
    if (line.includes('Recommended Skills:')) {
      inSection = true;
      continue;
    }
    if (inSection && line.includes('Learning Path:')) {
      break;
    }
    if (inSection && line.trim()) {
      const parts = line.split('|').map(s => s.trim());
      if (parts.length >= 3) {
        skills.push({
          skill: parts[0],
          priority: parts[1].toLowerCase() as 'high' | 'medium' | 'low',
          reason: parts[2]
        });
      }
    }
  }

  return skills;
}

function extractLearningResources(text: string, section: string): LearningResource[] {
  const resources: LearningResource[] = [];
  const lines = text.split('\n');
  let inSection = false;
  let currentResource: Partial<LearningResource> | null = null;

  for (const line of lines) {
    if (line.includes(`${section}:`)) {
      inSection = true;
      continue;
    }
    
    if (inSection && (
      line.includes('Short-term (3-6 months):') ||
      line.includes('Long-term (6+ months):') ||
      line.includes('Industry Insights:')
    )) {
      if (currentResource) {
        resources.push(currentResource as LearningResource);
      }
      break;
    }

    if (inSection && line.trim()) {
      // Check if this line starts a new resource
      if (line.includes('|')) {
        if (currentResource) {
          resources.push(currentResource as LearningResource);
        }
        
        // Extract URL if present
        let url: string | undefined;
        const urlMatch = line.match(/https?:\/\/[^\s|]+/);
        if (urlMatch) {
          url = urlMatch[0];
        }

        // Remove URL from the line for further processing
        const cleanLine = line.replace(/https?:\/\/[^\s|]+/, '').trim();
        const parts = cleanLine.split('|').map(s => s.trim());

        currentResource = {
          title: parts[0],
          type: (parts[1]?.toLowerCase() || 'course') as 'course' | 'certification' | 'tutorial',
          provider: parts[2] || '',
          duration: parts[3],
          level: (parts[4]?.toLowerCase() || 'beginner') as 'beginner' | 'intermediate' | 'advanced',
          description: parts[5] || '',
          url
        };
      } else if (currentResource) {
        // Append to current resource description
        currentResource.description = `${currentResource.description} ${line.trim()}`;
      }
    }
  }

  if (currentResource) {
    resources.push(currentResource as LearningResource);
  }

  return resources;
}

function extractInsights(text: string): string[] {
  const insights: string[] = [];
  const lines = text.split('\n');
  let inSection = false;

  for (const line of lines) {
    if (line.includes('Industry Insights:')) {
      inSection = true;
      continue;
    }
    if (inSection && line.trim()) {
      insights.push(line.trim());
    }
  }

  return insights;
}

export function parseSkillGapResponse(response: string): SkillGapAnalysis {
  return {
    missingSkills: extractSkills(response, 'Missing Skills'),
    skillGapScore: extractScore(response),
    recommendedSkills: extractRecommendedSkills(response),
    learningPath: {
      immediate: extractLearningResources(response, 'Immediate'),
      shortTerm: extractLearningResources(response, 'Short-term'),
      longTerm: extractLearningResources(response, 'Long-term')
    },
    industryInsights: extractInsights(response)
  };
}
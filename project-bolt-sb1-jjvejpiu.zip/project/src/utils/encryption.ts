// Use Web Crypto API instead of Node's crypto module
async function getKey(password: string): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    'PBKDF2',
    false,
    ['deriveBits', 'deriveKey']
  );

  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: enc.encode('salt'),
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function encryptApiKey(apiKey: string): Promise<{ encrypted: string; iv: string }> {
  const key = await getKey(import.meta.env.VITE_ENCRYPTION_KEY || 'default-key');
  const enc = new TextEncoder();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  
  const encrypted = await crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv
    },
    key,
    enc.encode(apiKey)
  );

  return {
    encrypted: Buffer.from(encrypted).toString('base64'),
    iv: Buffer.from(iv).toString('base64')
  };
}

export async function decryptApiKey(encrypted: string, iv: string): Promise<string> {
  const key = await getKey(import.meta.env.VITE_ENCRYPTION_KEY || 'default-key');
  const dec = new TextDecoder();
  
  const decrypted = await crypto.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv: Buffer.from(iv, 'base64')
    },
    key,
    Buffer.from(encrypted, 'base64')
  );

  return dec.decode(decrypted);
}
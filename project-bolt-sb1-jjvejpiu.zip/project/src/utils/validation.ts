import { CV } from '../types/cv';

export function validateCV(cv: CV): void {
  if (!cv.personalInfo || !cv.personalInfo.fullName || !cv.personalInfo.email) {
    throw new Error('Invalid personal information');
  }

  if (!Array.isArray(cv.experience)) {
    throw new Error('Invalid experience format');
  }

  if (!Array.isArray(cv.education)) {
    throw new Error('Invalid education format');
  }

  if (!Array.isArray(cv.skills)) {
    throw new Error('Invalid skills format');
  }
}

export function validateJobDescription(
  title: string, 
  description: string
): boolean {
  return Boolean(title.trim() && description.trim());
}

export function getJobDescriptionValidationMessage(
  title: string,
  description: string
): string | null {
  if (!title.trim()) {
    return 'Please enter the job title';
  }
  if (!description.trim()) {
    return 'Please enter the job description';
  }
  return null;
}
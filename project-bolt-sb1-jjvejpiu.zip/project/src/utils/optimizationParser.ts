import type { OptimizationTips } from '../types/cv';

export function parseOptimizationResponse(response: string): OptimizationTips {
  const matchScoreMatch = response.match(/Match Score:\s*(\d+)/i);
  const matchScore = matchScoreMatch ? parseInt(matchScoreMatch[1], 10) : 0;

  const foundKeywords = extractList(response, 'Found Keywords');
  const missingKeywords = extractList(response, 'Missing Keywords');
  const suggestions = extractSuggestions(response);

  return {
    matchScore,
    foundKeywords,
    missingKeywords,
    suggestions
  };
}

function extractList(text: string, section: string): string[] {
  const regex = new RegExp(`${section}:\\s*([^\\n]+)`, 'i');
  const match = text.match(regex);
  return match 
    ? match[1].split(',').map(item => item.trim()).filter(Boolean)
    : [];
}

function extractSuggestions(text: string): string[] {
  const suggestions: string[] = [];
  const lines = text.split('\n');
  let inSuggestionsSection = false;

  for (const line of lines) {
    if (line.toLowerCase().includes('suggestions:')) {
      inSuggestionsSection = true;
      continue;
    }

    if (inSuggestionsSection && line.trim()) {
      const suggestion = line.replace(/^[-•]/, '').trim();
      if (suggestion) {
        suggestions.push(suggestion);
      }
    }

    if (inSuggestionsSection && line.includes(':') && !line.toLowerCase().includes('suggestions:')) {
      break;
    }
  }

  return suggestions;
}
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist';

// Set worker path to a specific version
const PDFJS_VERSION = '3.11.174';
const WORKER_URL = `https://unpkg.com/pdfjs-dist@${PDFJS_VERSION}/build/pdf.worker.min.js`;

// Configure worker
GlobalWorkerOptions.workerSrc = WORKER_URL;

export async function extractTextFromPDF(file: File): Promise<string> {
  try {
    // Validate file type
    if (!file || !file.type || !file.type.includes('pdf')) {
      throw new Error('Please upload a valid PDF file');
    }

    // Validate file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      throw new Error('PDF file size must be less than 10MB');
    }

    // Load and parse PDF
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await getDocument({ data: arrayBuffer }).promise;
    
    if (!pdf || pdf.numPages === 0) {
      throw new Error('The PDF file appears to be empty');
    }

    // Extract text from all pages
    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items
        .map((item: any) => item.str)
        .join(' ');
      fullText += pageText + '\n';
    }

    const trimmedText = fullText.trim();
    if (!trimmedText) {
      throw new Error('No readable text found in the PDF');
    }

    return trimmedText;
  } catch (error) {
    console.error('Error parsing PDF:', error);
    
    // Provide user-friendly error messages
    if (error instanceof Error) {
      if (error.message.includes('worker')) {
        throw new Error('PDF processing service is temporarily unavailable. Please try again.');
      }
      throw error;
    }
    
    throw new Error('Failed to process PDF file. Please try again.');
  }
}
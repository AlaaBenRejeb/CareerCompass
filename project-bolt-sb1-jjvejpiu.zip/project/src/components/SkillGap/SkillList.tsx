import React from 'react';
import type { SkillGapAnalysis } from '../../types/skillGap';

interface SkillListProps {
  title: string;
  skills: string[] | SkillGapAnalysis['recommendedSkills'];
  type: 'missing' | 'recommended';
}

export function SkillList({ title, skills, type }: SkillListProps) {
  return (
    <div>
      <h4 className="text-sm font-medium text-gray-700 mb-2">{title}</h4>
      <div className="space-y-2">
        {type === 'missing' ? (
          (skills as string[]).map((skill, index) => (
            <div
              key={index}
              className="bg-red-50 text-red-700 px-3 py-2 rounded-md text-sm"
            >
              {skill}
            </div>
          ))
        ) : (
          (skills as SkillGapAnalysis['recommendedSkills']).map((skill, index) => (
            <div
              key={index}
              className={`px-3 py-2 rounded-md text-sm ${
                skill.priority === 'high' ? 'bg-blue-50 text-blue-700' :
                skill.priority === 'medium' ? 'bg-yellow-50 text-yellow-700' :
                'bg-gray-50 text-gray-700'
              }`}
            >
              <div className="font-medium">{skill.skill}</div>
              <div className="text-xs mt-1">{skill.reason}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
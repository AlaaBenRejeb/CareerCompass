import React from 'react';
import { ExternalLink, Clock } from 'lucide-react';
import type { LearningResource } from '../../types/skillGap';

interface LearningResourceCardProps {
  resource: LearningResource;
}

export function LearningResourceCard({ resource }: LearningResourceCardProps) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <h5 className="font-medium text-gray-900">{resource.title}</h5>
        {resource.url && (
          <a
            href={resource.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 group"
          >
            <ExternalLink className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </a>
        )}
      </div>
      
      <div className="mt-2 text-sm text-gray-600">
        <p className="mb-3">{resource.description}</p>
        <div className="flex flex-wrap gap-2">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            {resource.provider}
          </span>
          {resource.duration && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
              <Clock className="h-3 w-3 mr-1" />
              {resource.duration}
            </span>
          )}
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
            resource.level === 'beginner' ? 'bg-green-100 text-green-800' :
            resource.level === 'intermediate' ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }`}>
            {resource.level}
          </span>
        </div>
      </div>
      
      {resource.url && (
        <div className="mt-3 pt-3 border-t">
          <a
            href={resource.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800 hover:underline group"
          >
            <span>View Course Details</span>
            <ExternalLink className="h-4 w-4 ml-1 transition-transform group-hover:translate-x-0.5" />
          </a>
        </div>
      )}
    </div>
  );
}
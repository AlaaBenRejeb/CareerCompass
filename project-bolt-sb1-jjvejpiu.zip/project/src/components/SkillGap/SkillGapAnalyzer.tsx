import React, { useState } from 'react';
import { TrendingUp } from 'lucide-react';
import { FeatureDescription } from '../Common/FeatureDescription';
import { featureDescriptions } from '../../data/featureDescriptions';
import { SkillGapForm } from './SkillGapForm';
import { SkillGapResult } from './SkillGapResult';
import { analyzeSkillGap } from '../../services/skillGap/analyzer';
import type { SkillGapAnalysis, SkillGapFormData } from '../../types/skillGap';

export function SkillGapAnalyzer() {
  const [analysis, setAnalysis] = useState<SkillGapAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async (formData: SkillGapFormData, cvText: string) => {
    setIsAnalyzing(true);
    setError(null);
    try {
      const result = await analyzeSkillGap(formData, cvText);
      setAnalysis(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to analyze skill gap');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <FeatureDescription
        title={featureDescriptions.skillGap.title}
        description={featureDescriptions.skillGap.description}
        icon={TrendingUp}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          <SkillGapForm onSubmit={handleAnalyze} isAnalyzing={isAnalyzing} />
          
          {error && (
            <div className="bg-red-50 border-l-4 border-red-400 p-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </div>
          )}

          {isAnalyzing && (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" />
              <p className="mt-4 text-gray-600">Analyzing your skills and CV...</p>
            </div>
          )}

          {analysis && !isAnalyzing && (
            <SkillGapResult analysis={analysis} />
          )}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import type { LearningResource } from '../../types/skillGap';
import { LearningResourceCard } from './LearningResourceCard';

interface LearningPathProps {
  title: string;
  resources: LearningResource[];
  icon: React.ElementType;
}

export function LearningPath({ title, resources, icon: Icon }: LearningPathProps) {
  if (resources.length === 0) return null;

  return (
    <section className="border-t pt-6 first:border-t-0 first:pt-0">
      <h4 className="text-lg font-medium text-gray-800 mb-4 flex items-center gap-2">
        <Icon className="h-5 w-5 text-blue-600" />
        {title}
      </h4>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {resources.map((resource, index) => (
          <LearningResourceCard key={index} resource={resource} />
        ))}
      </div>
    </section>
  );
}
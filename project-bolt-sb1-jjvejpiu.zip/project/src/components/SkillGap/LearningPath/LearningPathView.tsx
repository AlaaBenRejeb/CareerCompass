import React from 'react';
import { BookOpen, Rocket, Target, Clock } from 'lucide-react';
import { PathSection } from './PathSection';
import type { SkillGapAnalysis } from '../../../types/skillGap';

interface LearningPathViewProps {
  learningPath: SkillGapAnalysis['learningPath'];
}

export function LearningPathView({ learningPath }: LearningPathViewProps) {
  const sections = [
    {
      title: 'Immediate Actions',
      description: 'Start with these resources to build your foundation and address critical skill gaps.',
      timeframe: '0-3 months',
      icon: Clock,
      resources: learningPath.immediate
    },
    {
      title: 'Short-term Goals',
      description: 'Focus on these areas to strengthen your expertise and expand your skill set.',
      timeframe: '3-6 months',
      icon: Rocket,
      resources: learningPath.shortTerm
    },
    {
      title: 'Long-term Goals',
      description: 'Master these advanced topics to become an expert in your field.',
      timeframe: '6+ months',
      icon: Target,
      resources: learningPath.longTerm
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center gap-2 mb-6">
        <BookOpen className="h-6 w-6 text-blue-600" />
        <h2 className="text-xl font-semibold text-gray-900">Learning Path</h2>
      </div>

      <div className="space-y-8">
        {sections.map((section, index) => (
          <React.Fragment key={section.title}>
            {index > 0 && <hr className="border-gray-200" />}
            <PathSection {...section} />
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}
import React from 'react';
import { LucideIcon } from 'lucide-react';
import { ResourceCard } from './ResourceCard';
import type { LearningResource } from '../../../types/skillGap';

interface PathSectionProps {
  title: string;
  description: string;
  resources: LearningResource[];
  icon: LucideIcon;
  timeframe: string;
}

export function PathSection({ title, description, resources, icon: Icon, timeframe }: PathSectionProps) {
  if (resources.length === 0) return null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-blue-50 rounded-lg">
            <Icon className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-medium text-gray-900">{title}</h3>
            <p className="text-sm text-gray-500">{timeframe}</p>
          </div>
        </div>
      </div>
      
      <p className="text-gray-600">{description}</p>

      <div className="grid gap-4 sm:grid-cols-2">
        {resources.map((resource, index) => (
          <ResourceCard key={index} resource={resource} />
        ))}
      </div>
    </div>
  );
}
import React from 'react';
import { ExternalLink, Clock, Award, BookOpen } from 'lucide-react';
import type { LearningResource } from '../../../types/skillGap';

interface ResourceCardProps {
  resource: LearningResource;
}

export function ResourceCard({ resource }: ResourceCardProps) {
  const levelColors = {
    beginner: 'bg-green-100 text-green-800',
    intermediate: 'bg-yellow-100 text-yellow-800',
    advanced: 'bg-red-100 text-red-800'
  };

  const typeIcons = {
    course: BookOpen,
    certification: Award,
    tutorial: Clock
  };

  const TypeIcon = typeIcons[resource.type];

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-blue-50 rounded-lg">
            <TypeIcon className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <h4 className="font-medium text-gray-900">{resource.title}</h4>
            <p className="text-sm text-gray-600 mt-1">{resource.provider}</p>
          </div>
        </div>
        {resource.url && (
          <a
            href={resource.url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 hover:text-blue-800"
          >
            <ExternalLink className="h-5 w-5" />
          </a>
        )}
      </div>

      <p className="mt-3 text-sm text-gray-600">{resource.description}</p>

      <div className="mt-4 flex flex-wrap gap-2">
        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${levelColors[resource.level]}`}>
          {resource.level.charAt(0).toUpperCase() + resource.level.slice(1)}
        </span>
        {resource.duration && (
          <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800 flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {resource.duration}
          </span>
        )}
        <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
          {resource.type.charAt(0).toUpperCase() + resource.type.slice(1)}
        </span>
      </div>
    </div>
  );
}
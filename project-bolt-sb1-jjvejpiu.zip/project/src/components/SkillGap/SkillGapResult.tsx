import React from 'react';
import { TrendingUp, Lightbulb } from 'lucide-react';
import type { SkillGapAnalysis } from '../../types/skillGap';
import { SkillList } from './SkillList';
import { LearningPathView } from './LearningPath/LearningPathView';
import { InsightsList } from './InsightsList';

interface SkillGapResultProps {
  analysis: SkillGapAnalysis;
}

export function SkillGapResult({ analysis }: SkillGapResultProps) {
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Skill Gap Analysis</h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">Gap Score:</span>
            <span className={`text-lg font-bold ${
              analysis.skillGapScore >= 80 ? 'text-green-600' :
              analysis.skillGapScore >= 60 ? 'text-yellow-600' :
              'text-red-600'
            }`}>
              {analysis.skillGapScore}%
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <SkillList
            title="Missing Skills"
            skills={analysis.missingSkills}
            type="missing"
          />
          <SkillList
            title="Recommended Skills"
            skills={analysis.recommendedSkills}
            type="recommended"
          />
        </div>
      </div>

      <LearningPathView learningPath={analysis.learningPath} />

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-2 mb-6">
          <Lightbulb className="h-6 w-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">Industry Insights</h2>
        </div>
        <InsightsList insights={analysis.industryInsights} />
      </div>
    </div>
  );
}
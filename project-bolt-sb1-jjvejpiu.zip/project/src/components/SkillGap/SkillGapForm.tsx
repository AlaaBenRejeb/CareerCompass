import React, { useState } from 'react';
import { Send, Upload } from 'lucide-react';
import { FileUpload } from '../CVUpload/FileUpload';
import { extractTextFromPDF } from '../../utils/pdfParser';
import { SkillInput } from './SkillInput';
import type { SkillGapFormData } from '../../types/skillGap';

interface SkillGapFormProps {
  onSubmit: (data: SkillGapFormData, cvText: string) => void;
  isAnalyzing: boolean;
}

const EXPERIENCE_LEVELS = [
  'Entry Level (0-2 years)',
  'Mid Level (3-5 years)',
  'Senior Level (6-10 years)',
  'Lead/Principal (10+ years)'
];

export function SkillGapForm({ onSubmit, isAnalyzing }: SkillGapFormProps) {
  const [formData, setFormData] = useState<SkillGapFormData>({
    targetRole: '',
    currentSkills: [],
    experience: '',
    industry: '',
    careerGoals: ''
  });
  const [cvText, setCvText] = useState<string>('');
  const [cvUploaded, setCvUploaded] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validate required fields
    if (!cvUploaded) {
      setError('Please upload your CV first');
      return;
    }
    if (!formData.targetRole) {
      setError('Please enter your target role');
      return;
    }
    if (formData.currentSkills.length === 0) {
      setError('Please add at least one current skill');
      return;
    }
    if (!formData.experience) {
      setError('Please select your experience level');
      return;
    }
    if (!formData.industry) {
      setError('Please enter your industry');
      return;
    }
    if (!formData.careerGoals) {
      setError('Please describe your career goals');
      return;
    }

    onSubmit(formData, cvText);
  };

  const handleFileUpload = async (file: File) => {
    try {
      setError(null);
      const text = await extractTextFromPDF(file);
      setCvText(text);
      setCvUploaded(true);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to process PDF');
      setCvUploaded(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
          <Upload className="h-5 w-5 text-blue-600" />
          Upload Your CV
        </h3>
        <FileUpload 
          onFileSelect={handleFileUpload}
          disabled={isAnalyzing}
        />
        {cvUploaded && (
          <div className="mt-2 text-sm text-green-600 flex items-center gap-2">
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            CV uploaded successfully
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md space-y-6">
        {/* Target Role */}
        <div>
          <label htmlFor="targetRole" className="block text-sm font-medium text-gray-700">
            Target Role*
          </label>
          <input
            type="text"
            id="targetRole"
            value={formData.targetRole}
            onChange={e => setFormData(prev => ({ ...prev, targetRole: e.target.value }))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            placeholder="e.g. Senior Software Engineer"
            required
          />
        </div>

        {/* Current Skills */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Current Skills*
          </label>
          <SkillInput
            skills={formData.currentSkills}
            onAddSkill={skill => setFormData(prev => ({
              ...prev,
              currentSkills: [...prev.currentSkills, skill]
            }))}
            onRemoveSkill={skill => setFormData(prev => ({
              ...prev,
              currentSkills: prev.currentSkills.filter(s => s !== skill)
            }))}
          />
        </div>

        {/* Experience Level */}
        <div>
          <label htmlFor="experience" className="block text-sm font-medium text-gray-700">
            Experience Level*
          </label>
          <select
            id="experience"
            value={formData.experience}
            onChange={e => setFormData(prev => ({ ...prev, experience: e.target.value }))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          >
            <option value="">Select experience level</option>
            {EXPERIENCE_LEVELS.map(level => (
              <option key={level} value={level}>{level}</option>
            ))}
          </select>
        </div>

        {/* Industry */}
        <div>
          <label htmlFor="industry" className="block text-sm font-medium text-gray-700">
            Industry*
          </label>
          <input
            type="text"
            id="industry"
            value={formData.industry}
            onChange={e => setFormData(prev => ({ ...prev, industry: e.target.value }))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            placeholder="e.g. Software Development, Data Science, Cloud Computing"
            required
          />
        </div>

        {/* Career Goals */}
        <div>
          <label htmlFor="careerGoals" className="block text-sm font-medium text-gray-700">
            Career Goals*
          </label>
          <textarea
            id="careerGoals"
            value={formData.careerGoals}
            onChange={e => setFormData(prev => ({ ...prev, careerGoals: e.target.value }))}
            rows={4}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            placeholder="Describe your career goals and aspirations..."
            required
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md">
            {error}
          </div>
        )}

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isAnalyzing || !cvUploaded}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isAnalyzing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                Analyzing...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Analyze Skills
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';

interface SkillInputProps {
  skills: string[];
  onAddSkill: (skill: string) => void;
  onRemoveSkill: (skill: string) => void;
}

export function SkillInput({ skills, onAddSkill, onRemoveSkill }: SkillInputProps) {
  const [newSkill, setNewSkill] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);

  // Common tech skills for suggestions
  const commonSkills = [
    'JavaScript', 'Python', 'React', 'Node.js', 'TypeScript',
    'AWS', 'Docker', 'Git', 'SQL', 'Java', 'C++', 'HTML/CSS',
    'Machine Learning', 'Data Analysis', 'Project Management'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setNewSkill(value);
    
    if (value.length > 0) {
      const filtered = commonSkills.filter(skill => 
        skill.toLowerCase().includes(value.toLowerCase()) &&
        !skills.includes(skill)
      );
      setSuggestions(filtered);
    } else {
      setSuggestions([]);
    }
  };

  const handleAddSkill = (skill: string = newSkill.trim()) => {
    if (skill && !skills.includes(skill)) {
      onAddSkill(skill);
      setNewSkill('');
      setSuggestions([]);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddSkill();
    }
  };

  return (
    <div className="space-y-2">
      <div className="relative">
        <div className="flex rounded-md shadow-sm">
          <input
            type="text"
            value={newSkill}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
            className="flex-1 rounded-l-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
            placeholder="Type a skill (e.g. JavaScript, Python)"
          />
          <button
            type="button"
            onClick={() => handleAddSkill()}
            className="inline-flex items-center px-3 rounded-r-md border border-l-0 border-gray-300 bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>
        
        {suggestions.length > 0 && (
          <div className="absolute z-10 mt-1 w-full bg-white rounded-md shadow-lg border border-gray-200">
            <ul className="py-1">
              {suggestions.map(skill => (
                <li
                  key={skill}
                  className="px-3 py-2 hover:bg-blue-50 cursor-pointer text-sm text-gray-700"
                  onClick={() => handleAddSkill(skill)}
                >
                  {skill}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        {skills.map(skill => (
          <span
            key={skill}
            className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800 group hover:bg-blue-200 transition-colors"
          >
            {skill}
            <button
              type="button"
              onClick={() => onRemoveSkill(skill)}
              className="ml-1.5 inline-flex items-center p-0.5 rounded-full text-blue-400 hover:text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </span>
        ))}
      </div>
    </div>
  );
}
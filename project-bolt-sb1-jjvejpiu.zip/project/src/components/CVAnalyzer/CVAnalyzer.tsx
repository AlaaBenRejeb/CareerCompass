import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { FeatureDescription } from '../Common/FeatureDescription';
import { featureDescriptions } from '../../data/featureDescriptions';
import { FileUpload } from '../CVUpload/FileUpload';
import { JobDescriptionInput } from '../CVUpload/JobDescriptionInput';
import { AnalysisResult as AnalysisResultComponent } from '../CVAnalysis/AnalysisResult';
import { analyzeCV } from '../../services/gpt';
import { ErrorMessage } from '../Common/ErrorMessage';
import { validateJobDescription, getJobDescriptionValidationMessage } from '../../utils/validation';
import { extractTextFromPDF } from '../../utils/pdfParser';
import type { AnalysisResult, JobDescription } from '../../types/analysis';

export function CVAnalyzer() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [cvText, setCvText] = useState<string>('');
  const [hasUploadedFile, setHasUploadedFile] = useState(false);
  const [jobDescription, setJobDescription] = useState<JobDescription>({
    title: '',
    description: ''
  });

  const isJobDescriptionValid = validateJobDescription(
    jobDescription.title,
    jobDescription.description
  );

  const validationMessage = getJobDescriptionValidationMessage(
    jobDescription.title,
    jobDescription.description
  );

  const handleAnalysis = async (text: string, jd: JobDescription) => {
    setIsAnalyzing(true);
    setError(null);
    try {
      const result = await analyzeCV(text, jd);
      setAnalysis(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to analyze CV');
      setAnalysis(null);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileUpload = async (file: File) => {
    setError(null);
    try {
      const text = await extractTextFromPDF(file);
      setCvText(text);
      setHasUploadedFile(true);

      if (isJobDescriptionValid) {
        await handleAnalysis(text, jobDescription);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process CV');
      setCvText('');
      setHasUploadedFile(false);
    }
  };

  const handleJobDescriptionChange = async (field: keyof JobDescription, value: string) => {
    const updatedJobDescription = { ...jobDescription, [field]: value };
    setJobDescription(updatedJobDescription);

    if (hasUploadedFile && cvText && validateJobDescription(
      updatedJobDescription.title,
      updatedJobDescription.description
    )) {
      await handleAnalysis(cvText, updatedJobDescription);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <FeatureDescription
        title={featureDescriptions.cvAnalyzer.title}
        description={featureDescriptions.cvAnalyzer.description}
        icon={Search}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          <JobDescriptionInput 
            jobDescription={jobDescription}
            onChange={handleJobDescriptionChange}
          />

          <div className="bg-white p-6 rounded-lg shadow-md">
            <FileUpload 
              onFileSelect={handleFileUpload}
              disabled={isAnalyzing}
              disabledMessage={isAnalyzing ? "Analysis in progress..." : undefined}
            />
            {hasUploadedFile && !isJobDescriptionValid && (
              <div className="mt-2 text-sm text-blue-600">
                <p>CV uploaded successfully!</p>
                {validationMessage && (
                  <p className="mt-1">To start analysis: {validationMessage.toLowerCase()}</p>
                )}
              </div>
            )}
          </div>

          {error && <ErrorMessage message={error} />}

          {isAnalyzing && (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" />
              <p className="mt-4 text-gray-600">Analyzing your CV...</p>
            </div>
          )}

          {analysis && !isAnalyzing && (
            <AnalysisResultComponent analysis={analysis} />
          )}
        </div>
      </div>
    </div>
  );
}
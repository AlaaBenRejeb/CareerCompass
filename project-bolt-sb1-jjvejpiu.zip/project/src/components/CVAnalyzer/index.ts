// Export the CVAnalyzer component
export { CVAnalyzer } from './CVAnalyzer';
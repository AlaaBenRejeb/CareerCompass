import React from 'react';
import { Settings as SettingsIcon } from 'lucide-react';
import { SubscriptionSettings } from './SubscriptionSettings';

export function SettingsPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 mb-8">
          <SettingsIcon className="h-8 w-8 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        </div>

        <div className="space-y-6">
          <SubscriptionSettings />
        </div>
      </div>
    </div>
  );
}
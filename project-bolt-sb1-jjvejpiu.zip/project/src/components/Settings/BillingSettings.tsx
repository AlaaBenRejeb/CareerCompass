import React, { useState, useEffect } from 'react';
import { CreditCard, Calendar, CheckCircle } from 'lucide-react';
import { SettingsSection } from './SettingsSection';
import { PricingPlan, Subscription } from '../../types/subscription';
import { supabase } from '../../utils/supabase';
import { useAuth } from '../../contexts/AuthContext';

export function BillingSettings() {
  const [plans, setPlans] = useState<PricingPlan[]>([]);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    const loadBillingData = async () => {
      try {
        // Load pricing plans
        const { data: pricingData, error: pricingError } = await supabase
          .from('pricing')
          .select('*')
          .order('price');
        
        if (pricingError) throw pricingError;
        setPlans(pricingData);

        // Load user's subscription
        if (user) {
          const { data: subData, error: subError } = await supabase
            .from('subscriptions')
            .select('*')
            .eq('user_id', user.id)
            .single();
          
          if (subError && subError.code !== 'PGRST116') throw subError;
          setSubscription(subData);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load billing data');
      } finally {
        setIsLoading(false);
      }
    };

    loadBillingData();
  }, [user]);

  const handleSubscribe = async (priceId: string) => {
    try {
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          priceId,
          userId: user?.id,
        }),
      });

      const { url } = await response.json();
      window.location.href = url;
    } catch (err) {
      setError('Failed to initiate checkout');
    }
  };

  const handleCancelSubscription = async () => {
    if (!subscription?.stripe_subscription_id) return;

    try {
      await fetch('/api/cancel-subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          subscriptionId: subscription.stripe_subscription_id,
        }),
      });

      // Refresh subscription data
      const { data } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', user?.id)
        .single();
      
      setSubscription(data);
    } catch (err) {
      setError('Failed to cancel subscription');
    }
  };

  if (isLoading) {
    return (
      <SettingsSection title="Billing Settings" description="Manage your subscription">
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
        </div>
      </SettingsSection>
    );
  }

  return (
    <SettingsSection title="Billing Settings" description="Manage your subscription and payment methods">
      {error && (
        <div className="mb-6 bg-red-50 text-red-700 p-4 rounded-md">
          {error}
        </div>
      )}

      {/* Current Subscription */}
      {subscription && (
        <div className="mb-8 p-4 bg-blue-50 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-medium text-blue-900">
                Current Plan: {plans.find(p => p.id === subscription.plan_id)?.name}
              </h4>
              <p className="text-sm text-blue-700">
                Status: {subscription.status}
                {subscription.cancel_at_period_end && ' (Cancels at period end)'}
              </p>
              {subscription.current_period_end && (
                <p className="text-sm text-blue-700">
                  Next billing date: {new Date(subscription.current_period_end).toLocaleDateString()}
                </p>
              )}
            </div>
            {subscription.status === 'active' && !subscription.cancel_at_period_end && (
              <button
                onClick={handleCancelSubscription}
                className="text-sm text-blue-600 hover:text-blue-500"
              >
                Cancel Subscription
              </button>
            )}
          </div>
        </div>
      )}

      {/* Pricing Plans */}
      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`relative p-6 rounded-lg border ${
              subscription?.plan_id === plan.id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200'
            }`}
          >
            {subscription?.plan_id === plan.id && (
              <div className="absolute -top-3 -right-3">
                <CheckCircle className="h-6 w-6 text-blue-500" />
              </div>
            )}
            <h3 className="text-lg font-medium text-gray-900">{plan.name}</h3>
            <p className="mt-2 text-sm text-gray-500">{plan.description}</p>
            <p className="mt-4 text-2xl font-bold text-gray-900">
              ${(plan.price / 100).toFixed(2)}
              <span className="text-sm font-normal text-gray-500">/month</span>
            </p>
            <ul className="mt-6 space-y-4">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                  <span className="ml-3 text-sm text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={() => handleSubscribe(plan.stripe_price_id)}
              disabled={subscription?.plan_id === plan.id}
              className={`mt-8 w-full px-4 py-2 rounded-md text-sm font-medium ${
                subscription?.plan_id === plan.id
                  ? 'bg-gray-100 text-gray-400 cursor-default'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {subscription?.plan_id === plan.id ? 'Current Plan' : 'Subscribe'}
            </button>
          </div>
        ))}
      </div>
    </SettingsSection>
  );
}
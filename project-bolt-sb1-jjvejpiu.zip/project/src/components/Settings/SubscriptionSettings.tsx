import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { CreditCard, Loader } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getSubscriptionStatus } from '../../services/payment';
import { ManageSubscriptionButton } from './ManageSubscriptionButton';
import type { SubscriptionStatus } from '../../types/payment';

export function SubscriptionSettings() {
  const [subscription, setSubscription] = useState<SubscriptionStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;
    loadSubscription();
  }, [user]);

  async function loadSubscription() {
    try {
      const status = await getSubscriptionStatus();
      setSubscription(status);
    } catch (err) {
      setError('Failed to load subscription information');
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-6 flex justify-center">
          <Loader className="h-6 w-6 text-blue-600 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <CreditCard className="h-6 w-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">Subscription</h2>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 text-red-700 p-4 rounded-md">
            {error}
          </div>
        )}

        {subscription ? (
          <div className="space-y-6">
            {/* Current Plan */}
            <div className="bg-gray-50 rounded-lg p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    {subscription.plan?.name || 'Pro Plan'}
                  </h3>
                  {subscription.plan && (
                    <p className="text-sm text-gray-600 mt-1">
                      ${(subscription.plan.price / 100).toFixed(2)}/{subscription.plan.interval}
                    </p>
                  )}
                </div>
                <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                  subscription.isActive 
                    ? 'bg-green-100 text-green-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {subscription.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>

              {subscription.currentPeriodEnd && (
                <div className="mt-4 text-sm text-gray-600">
                  Next billing date: {new Date(subscription.currentPeriodEnd).toLocaleDateString()}
                </div>
              )}

              {subscription.isActive && (
                <div className="mt-6 flex justify-end">
                  <ManageSubscriptionButton />
                </div>
              )}
            </div>

            {/* Features */}
            {subscription.plan?.features && (
              <div>
                <h4 className="text-sm font-medium text-gray-900 mb-4">Included Features</h4>
                <ul className="space-y-3">
                  {subscription.plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-600">
                      <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-600 mb-4">No active subscription</p>
            <Link
              to="/pricing"
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              View Plans
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { createPortalSession } from '../../services/payment';
import { Loader } from 'lucide-react';

interface ManageSubscriptionButtonProps {
  className?: string;
}

export function ManageSubscriptionButton({ className }: ManageSubscriptionButtonProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    try {
      setIsLoading(true);
      const url = await createPortalSession();
      window.location.href = url;
    } catch (error) {
      console.error('Failed to access billing portal:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      onClick={handleClick}
      disabled={isLoading}
      className={`inline-flex items-center text-sm text-blue-600 hover:text-blue-500 disabled:opacity-50 ${className}`}
    >
      {isLoading ? (
        <>
          <Loader className="h-4 w-4 mr-2 animate-spin" />
          Loading...
        </>
      ) : (
        'Manage Subscription'
      )}
    </button>
  );
}
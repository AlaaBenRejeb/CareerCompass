import React from 'react';

interface RequirementsInputProps {
  requirements: string[];
  onChange: (requirements: string[]) => void;
  placeholder?: string;
}

export function RequirementsInput({ requirements, onChange, placeholder }: RequirementsInputProps) {
  const handleInputChange = (value: string) => {
    // Split by newlines only and preserve spaces
    const newRequirements = value
      .split('\n')
      .map(req => req.trim())
      .filter(Boolean);
    
    onChange(newRequirements);
  };

  // Join with newlines to preserve formatting
  const textValue = requirements.join('\n');

  return (
    <textarea
      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
      value={textValue}
      onChange={(e) => handleInputChange(e.target.value)}
      placeholder={placeholder}
      rows={4}
      style={{ whiteSpace: 'pre-wrap' }}
    />
  );
}
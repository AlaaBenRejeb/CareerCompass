import React from 'react';
import { AlertCircle, CheckCircle } from 'lucide-react';

interface ErrorMessageProps {
  message: string;
  type?: 'error' | 'success';
}

export function ErrorMessage({ message, type = 'error' }: ErrorMessageProps) {
  const styles = {
    error: {
      bg: 'bg-red-50',
      border: 'border-red-400',
      text: 'text-red-700',
      icon: AlertCircle
    },
    success: {
      bg: 'bg-green-50',
      border: 'border-green-400',
      text: 'text-green-700',
      icon: CheckCircle
    }
  };

  const { bg, border, text, icon: Icon } = styles[type];

  return (
    <div className={`${bg} border-l-4 ${border} p-4 rounded`}>
      <div className="flex items-start">
        <Icon className={`h-5 w-5 ${text} mt-0.5`} />
        <div className="ml-3">
          <p className={`text-sm ${text}`}>{message}</p>
        </div>
      </div>
    </div>
  );
}
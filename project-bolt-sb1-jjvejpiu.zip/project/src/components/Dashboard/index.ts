// Export the DashboardPage component
export { DashboardPage } from './DashboardPage';
import React from 'react';
import { FileText, Search, TrendingUp, PenLine, Video } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useProfile } from '../../hooks/useProfile';

export function DashboardPage() {
  const { profile, loading } = useProfile();

  const tools = [
    {
      name: 'CV Builder',
      description: 'Create and manage your professional CV',
      icon: FileText,
      to: '/cv-builder',
    },
    {
      name: 'CV Analyzer',
      description: 'Get feedback on your CV',
      icon: Search,
      to: '/analyze',
    },
    {
      name: 'Skills Analysis',
      description: 'Analyze and track your skill development',
      icon: TrendingUp,
      to: '/skills',
    },
    {
      name: 'Cover Letters',
      description: 'Generate customized cover letters',
      icon: PenLine,
      to: '/cover-letter',
    },
    {
      name: 'Interview Practice',
      description: 'Practice interviews with AI feedback',
      icon: Video,
      to: '/interview',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">
          {loading ? (
            "Loading..."
          ) : (
            `Welcome back, ${profile?.full_name || 'User'}!`
          )}
        </h1>
        
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {tools.map((tool) => (
            <Link
              key={tool.name}
              to={tool.to}
              className="bg-white overflow-hidden rounded-lg shadow hover:shadow-md transition-shadow"
            >
              <div className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <tool.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-medium text-gray-900">{tool.name}</h3>
                    <p className="mt-1 text-sm text-gray-500">{tool.description}</p>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
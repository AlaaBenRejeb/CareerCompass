import React from 'react';
import { Shield } from 'lucide-react';
import { LegalLayout } from './LegalLayout';

export function PrivacyPolicy() {
  return (
    <LegalLayout
      title="Privacy Policy"
      icon={Shield}
      lastUpdated="March 14, 2024"
    >
      <div className="space-y-6">
        <section>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">1. Information We Collect</h2>
          <div className="space-y-4 text-gray-600">
            <p>We collect information that you provide directly to us, including:</p>
            <ul className="list-disc pl-5 space-y-2">
              <li>Name and contact information</li>
              <li>Resume/CV content and professional history</li>
              <li>Account credentials</li>
              <li>Payment information (processed securely through our payment provider)</li>
            </ul>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">2. How We Use Your Information</h2>
          <div className="space-y-4 text-gray-600">
            <p>We use the information we collect to:</p>
            <ul className="list-disc pl-5 space-y-2">
              <li>Provide and improve our services</li>
              <li>Process your payments</li>
              <li>Send you updates and marketing communications</li>
              <li>Analyze and enhance our platform's performance</li>
            </ul>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">3. Data Security</h2>
          <p className="text-gray-600">
            We implement appropriate technical and organizational security measures to protect your personal information.
            However, no method of transmission over the Internet is 100% secure.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">4. Contact Us</h2>
          <p className="text-gray-600">
            If you have any questions about this Privacy Policy, please contact us at privacy@careercompass.dev
          </p>
        </section>
      </div>
    </LegalLayout>
  );
}
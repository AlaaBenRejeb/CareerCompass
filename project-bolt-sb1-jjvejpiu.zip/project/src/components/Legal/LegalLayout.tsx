import React from 'react';
import { LucideIcon } from 'lucide-react';

interface LegalLayoutProps {
  title: string;
  icon: LucideIcon;
  lastUpdated: string;
  children: React.ReactNode;
}

export function LegalLayout({ title, icon: Icon, lastUpdated, children }: LegalLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-8">
            <div className="flex items-center gap-3 mb-6">
              <Icon className="h-8 w-8 text-blue-600" />
              <h1 className="text-3xl font-bold text-gray-900">{title}</h1>
            </div>
            
            <p className="text-sm text-gray-500 mb-8">
              Last updated: {lastUpdated}
            </p>

            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
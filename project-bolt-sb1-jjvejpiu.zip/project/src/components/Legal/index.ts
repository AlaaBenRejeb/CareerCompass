// Export legal components
export { PrivacyPolicy } from './PrivacyPolicy';
export { TermsOfUse } from './TermsOfUse';
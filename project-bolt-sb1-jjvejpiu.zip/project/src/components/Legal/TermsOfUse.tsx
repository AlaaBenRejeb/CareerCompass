import React from 'react';
import { Scale } from 'lucide-react';
import { LegalLayout } from './LegalLayout';

export function TermsOfUse() {
  return (
    <LegalLayout
      title="Terms of Use"
      icon={Scale}
      lastUpdated="March 14, 2024"
    >
      <div className="space-y-6">
        <section>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">1. Acceptance of Terms</h2>
          <p className="text-gray-600">
            By accessing or using Career Compass, you agree to be bound by these Terms of Use and all applicable laws and regulations.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">2. User Accounts</h2>
          <div className="space-y-4 text-gray-600">
            <p>You are responsible for:</p>
            <ul className="list-disc pl-5 space-y-2">
              <li>Maintaining the confidentiality of your account</li>
              <li>All activities that occur under your account</li>
              <li>Notifying us of any unauthorized use</li>
            </ul>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">3. Intellectual Property</h2>
          <p className="text-gray-600">
            All content and materials available on Career Compass are protected by intellectual property rights.
            You may not copy, modify, or distribute our content without permission.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">4. Limitation of Liability</h2>
          <p className="text-gray-600">
            Career Compass is provided "as is" without warranties of any kind. We are not liable for any damages
            arising from your use of our service.
          </p>
        </section>
      </div>
    </LegalLayout>
  );
}
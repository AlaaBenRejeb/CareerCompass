import React from 'react';

interface QuestionDisplayProps {
  questionNumber: number;
  question: string;
}

export function QuestionDisplay({ questionNumber, question }: QuestionDisplayProps) {
  return (
    <div className="bg-blue-50 p-4 rounded-lg">
      <h3 className="text-sm font-medium text-blue-800 mb-2">Question {questionNumber}</h3>
      <p className="text-blue-900">{question}</p>
    </div>
  );
}
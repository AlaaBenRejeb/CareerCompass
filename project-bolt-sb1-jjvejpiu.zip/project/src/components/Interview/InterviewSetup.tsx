import React, { useState } from 'react';
import { Upload } from 'lucide-react';
import { JobDescriptionInput } from '../CVUpload/JobDescriptionInput';
import { extractTextFromPDF } from '../../utils/pdfParser';
import type { JobDescription } from '../../types/analysis';

interface InterviewSetupProps {
  onComplete: (position: string, cvText: string, jobDescription: string) => void;
}

export function InterviewSetup({ onComplete }: InterviewSetupProps) {
  const [cvText, setCvText] = useState('');
  const [fileName, setFileName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [jobDescription, setJobDescription] = useState<JobDescription>({
    title: '',
    description: ''
  });

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      setError('Please upload a PDF file');
      return;
    }

    try {
      const text = await extractTextFromPDF(file);
      setCvText(text);
      setFileName(file.name);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process PDF');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!jobDescription.title.trim()) {
      setError('Please enter the position you are applying for');
      return;
    }
    if (!cvText) {
      setError('Please upload your CV');
      return;
    }
    if (!jobDescription.description.trim()) {
      setError('Please enter the job description');
      return;
    }

    onComplete(
      jobDescription.title.trim(),
      cvText,
      jobDescription.description.trim()
    );
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Interview Setup</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <JobDescriptionInput
          jobDescription={jobDescription}
          onChange={(field, value) => setJobDescription(prev => ({ ...prev, [field]: value }))}
        />

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Upload Your CV
          </label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md hover:border-blue-500 transition-colors">
            <div className="space-y-1 text-center">
              {fileName ? (
                <div className="flex items-center justify-center gap-2 text-green-600">
                  <Upload className="h-5 w-5" />
                  <span className="text-sm">{fileName}</span>
                </div>
              ) : (
                <>
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="flex text-sm text-gray-600">
                    <label htmlFor="cv-upload" className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500">
                      <span>Upload a file</span>
                      <input
                        id="cv-upload"
                        type="file"
                        accept=".pdf"
                        onChange={handleFileUpload}
                        className="sr-only"
                      />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-gray-500">PDF up to 10MB</p>
                </>
              )}
            </div>
          </div>
        </div>

        {error && (
          <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md">
            {error}
          </div>
        )}

        <button
          type="submit"
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Start Interview
        </button>
      </form>
    </div>
  );
}
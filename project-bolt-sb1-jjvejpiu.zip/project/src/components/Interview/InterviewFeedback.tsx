import React from 'react';
import { ThumbsUp, ThumbsDown, BarChart, MessageSquare } from 'lucide-react';
import type { InterviewFeedbackType } from '../../types/interview';

interface InterviewFeedbackProps {
  feedback: InterviewFeedbackType;
}

export function InterviewFeedback({ feedback }: InterviewFeedbackProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-gray-900">Interview Analysis</h3>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-600">Overall Score:</span>
          <span className={`text-lg font-bold ${
            feedback.overallScore >= 80 ? 'text-green-600' : 
            feedback.overallScore >= 60 ? 'text-yellow-600' : 
            'text-red-600'
          }`}>
            {feedback.overallScore}%
          </span>
        </div>
      </div>

      {/* Strengths */}
      <div>
        <h4 className="flex items-center gap-2 text-green-600 font-medium mb-3">
          <ThumbsUp className="h-5 w-5" />
          Strengths
        </h4>
        <div className="space-y-2">
          {feedback.strengths.map((strength, index) => (
            <div key={index} className="bg-green-50 text-green-700 px-4 py-3 rounded-md">
              {strength}
            </div>
          ))}
        </div>
      </div>

      {/* Areas for Improvement */}
      <div>
        <h4 className="flex items-center gap-2 text-red-600 font-medium mb-3">
          <ThumbsDown className="h-5 w-5" />
          Areas for Improvement
        </h4>
        <div className="space-y-2">
          {feedback.improvements.map((improvement, index) => (
            <div key={index} className="bg-red-50 text-red-700 px-4 py-3 rounded-md">
              {improvement}
            </div>
          ))}
        </div>
      </div>

      {/* Communication Analysis */}
      <div>
        <h4 className="flex items-center gap-2 text-blue-600 font-medium mb-3">
          <MessageSquare className="h-5 w-5" />
          Communication Analysis
        </h4>
        <div className="grid grid-cols-2 gap-4">
          {Object.entries(feedback.communication).map(([metric, score]) => (
            <div key={metric} className="bg-blue-50 p-4 rounded-lg">
              <div className="text-sm text-blue-700 mb-2 capitalize">
                {metric.replace(/([A-Z])/g, ' $1').trim()}
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 bg-blue-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-blue-600 transition-all duration-300"
                    style={{ width: `${score}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-blue-700">{score}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recommendations */}
      <div>
        <h4 className="flex items-center gap-2 text-purple-600 font-medium mb-3">
          <BarChart className="h-5 w-5" />
          Recommendations
        </h4>
        <div className="space-y-2">
          {feedback.recommendations.map((recommendation, index) => (
            <div key={index} className="bg-purple-50 text-purple-700 px-4 py-3 rounded-md">
              {recommendation}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
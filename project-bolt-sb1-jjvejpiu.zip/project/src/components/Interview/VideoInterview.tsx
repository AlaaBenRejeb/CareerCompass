import React, { useState, useRef } from 'react';
import { Video } from 'lucide-react';
import { FeatureDescription } from '../Common/FeatureDescription';
import { featureDescriptions } from '../../data/featureDescriptions';
import { InterviewSetup } from './InterviewSetup';
import { InterviewConversation } from './InterviewConversation';
import { InterviewFeedback } from './InterviewFeedback';
import { useVideoRecording } from '../../hooks/useVideoRecording';
import { analyzeInterview } from '../../services/interview-analysis';
import type { InterviewFeedbackType } from '../../types/interview';

interface InterviewContext {
  position: string;
  cvText: string;
  jobDescription: string;
  requirements: string[];
}

export function VideoInterview() {
  const [isRecording, setIsRecording] = useState(false);
  const [feedback, setFeedback] = useState<InterviewFeedbackType | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [interviewContext, setInterviewContext] = useState<InterviewContext | null>(null);
  
  const {
    startRecording,
    stopRecording,
    videoStream,
    audioLevel,
    hasPermissions,
    requestPermissions
  } = useVideoRecording();

  const videoRef = useRef<HTMLVideoElement>(null);

  React.useEffect(() => {
    if (videoRef.current && videoStream) {
      videoRef.current.srcObject = videoStream;
    }
  }, [videoStream]);

  const handleStartInterview = async () => {
    if (!hasPermissions) {
      const granted = await requestPermissions();
      if (!granted) {
        setError('Camera and microphone permissions are required');
        return;
      }
    }
    
    setIsRecording(true);
    setError(null);
    await startRecording();
  };

  const handleStopInterview = async () => {
    setIsRecording(false);
    const recordingBlob = await stopRecording();
    
    if (recordingBlob) {
      setIsAnalyzing(true);
      try {
        const result = await analyzeInterview(recordingBlob);
        setFeedback(result);
      } catch (error) {
        setError(error instanceof Error ? error.message : 'Failed to analyze interview');
      } finally {
        setIsAnalyzing(false);
      }
    }
  };

  const handleSetupComplete = (position: string, cvText: string, jobDescription: string, requirements: string[]) => {
    setInterviewContext({
      position,
      cvText,
      jobDescription,
      requirements
    });
  };

  if (!interviewContext) {
    return <InterviewSetup onComplete={handleSetupComplete} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <FeatureDescription
        title={featureDescriptions.interview.title}
        description={featureDescriptions.interview.description}
        icon={Video}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold text-gray-900">Interview Practice</h2>
            <div className="text-sm text-gray-600">
              Position: <span className="font-medium">{interviewContext.position}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden relative">
                <video
                  ref={videoRef}
                  autoPlay
                  muted
                  playsInline
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="mt-6 flex justify-center">
                <button
                  onClick={isRecording ? handleStopInterview : handleStartInterview}
                  className={`inline-flex items-center px-4 py-2 rounded-md shadow-sm text-sm font-medium text-white ${
                    isRecording 
                      ? 'bg-red-600 hover:bg-red-700'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {isRecording ? 'Stop Recording' : 'Start Interview'}
                </button>
              </div>
            </div>

            <div>
              {isRecording && (
                <InterviewConversation
                  position={interviewContext.position}
                  cvText={interviewContext.cvText}
                  jobDescription={interviewContext.jobDescription}
                  requirements={interviewContext.requirements}
                />
              )}
            </div>
          </div>

          {error && (
            <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-md">
              {error}
            </div>
          )}
        </div>

        {isAnalyzing ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" />
            <p className="mt-4 text-gray-600">Analyzing your interview...</p>
          </div>
        ) : feedback && (
          <div className="mt-8">
            <InterviewFeedback feedback={feedback} />
          </div>
        )}
      </div>
    </div>
  );
}
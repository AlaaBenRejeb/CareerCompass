import React from 'react';
import { MessageCircle, CheckCircle, AlertTriangle, XCircle } from 'lucide-react';

interface FeedbackDisplayProps {
  feedback: string | null;
}

export function FeedbackDisplay({ feedback }: FeedbackDisplayProps) {
  if (!feedback) return null;

  // Parse feedback into sections
  const sections = parseFeedback(feedback);

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm">
      <div className="border-b border-gray-200 bg-gray-50 px-4 py-3">
        <h3 className="flex items-center gap-2 text-lg font-medium text-gray-900">
          <MessageCircle className="h-5 w-5 text-blue-500" />
          Response Analysis
        </h3>
      </div>

      <div className="divide-y divide-gray-200">
        {/* Technical Understanding */}
        <FeedbackSection
          title="Technical Understanding"
          content={sections.technical}
          type={sections.technicalScore}
        />

        {/* Key Points */}
        <FeedbackSection
          title="Key Points Covered"
          content={sections.keyPoints}
          type={sections.keyPointsScore}
        />

        {/* Clarity */}
        <FeedbackSection
          title="Communication Clarity"
          content={sections.clarity}
          type={sections.clarityScore}
        />

        {/* Improvements */}
        {sections.improvements && (
          <div className="px-4 py-3">
            <h4 className="flex items-center gap-2 text-sm font-medium text-yellow-800 mb-2">
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
              Areas for Improvement
            </h4>
            <ul className="space-y-1">
              {sections.improvements.map((improvement, index) => (
                <li 
                  key={index}
                  className="text-sm text-yellow-700 flex items-start gap-2"
                >
                  <span className="text-yellow-500">•</span>
                  {improvement}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}

interface FeedbackSection {
  title: string;
  content: string;
  type: 'success' | 'warning' | 'error';
}

function FeedbackSection({ title, content, type }: FeedbackSection) {
  const colors = {
    success: {
      bg: 'bg-green-50',
      text: 'text-green-800',
      icon: <CheckCircle className="h-4 w-4 text-green-500" />
    },
    warning: {
      bg: 'bg-yellow-50',
      text: 'text-yellow-800',
      icon: <AlertTriangle className="h-4 w-4 text-yellow-500" />
    },
    error: {
      bg: 'bg-red-50',
      text: 'text-red-800',
      icon: <XCircle className="h-4 w-4 text-red-500" />
    }
  };

  return (
    <div className={`px-4 py-3 ${colors[type].bg}`}>
      <h4 className={`flex items-center gap-2 text-sm font-medium ${colors[type].text} mb-2`}>
        {colors[type].icon}
        {title}
      </h4>
      <p className={`text-sm ${colors[type].text}`}>{content}</p>
    </div>
  );
}

interface ParsedFeedback {
  technical: string;
  technicalScore: 'success' | 'warning' | 'error';
  keyPoints: string;
  keyPointsScore: 'success' | 'warning' | 'error';
  clarity: string;
  clarityScore: 'success' | 'warning' | 'error';
  improvements: string[];
}

function parseFeedback(feedback: string): ParsedFeedback {
  // Split feedback into sections based on common patterns
  const sections = feedback.split(/\.|!|\?/).filter(Boolean).map(s => s.trim());
  
  const result: ParsedFeedback = {
    technical: '',
    technicalScore: 'success',
    keyPoints: '',
    keyPointsScore: 'success',
    clarity: '',
    clarityScore: 'success',
    improvements: []
  };

  sections.forEach(section => {
    if (section.toLowerCase().includes('technical') || section.toLowerCase().includes('understanding')) {
      result.technical = section;
      result.technicalScore = getSectionScore(section);
    } else if (section.toLowerCase().includes('key point') || section.toLowerCase().includes('covered')) {
      result.keyPoints = section;
      result.keyPointsScore = getSectionScore(section);
    } else if (section.toLowerCase().includes('clarity') || section.toLowerCase().includes('communication')) {
      result.clarity = section;
      result.clarityScore = getSectionScore(section);
    } else if (section.toLowerCase().includes('could') || section.toLowerCase().includes('should') || section.toLowerCase().includes('improve')) {
      result.improvements.push(section);
    }
  });

  return result;
}

function getSectionScore(text: string): 'success' | 'warning' | 'error' {
  const lowerText = text.toLowerCase();
  if (lowerText.includes('excellent') || lowerText.includes('great') || lowerText.includes('strong')) {
    return 'success';
  } else if (lowerText.includes('good') || lowerText.includes('adequate') || lowerText.includes('fair')) {
    return 'warning';
  }
  return 'error';
}
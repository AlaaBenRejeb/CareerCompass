import React from 'react';
import { Camera, StopCircle } from 'lucide-react';

interface ControlButtonsProps {
  isRecording: boolean;
  onStart: () => void;
  onStop: () => void;
}

export function ControlButtons({ isRecording, onStart, onStop }: ControlButtonsProps) {
  return (
    <div className="mt-6 flex justify-center gap-4">
      {!isRecording ? (
        <button
          onClick={onStart}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <Camera className="h-5 w-5 mr-2" />
          Start Interview
        </button>
      ) : (
        <button
          onClick={onStop}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
        >
          <StopCircle className="h-5 w-5 mr-2" />
          Stop Recording
        </button>
      )}
    </div>
  );
}
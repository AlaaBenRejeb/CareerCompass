import React from 'react';
import { Mic, StopCircle } from 'lucide-react';

interface ResponseSectionProps {
  isListening: boolean;
  isProcessing: boolean;
  isSpeaking: boolean;
  response: string;
  onStartListening: () => void;
  onStopListening: () => void;
}

export function ResponseSection({ 
  isListening, 
  isProcessing, 
  isSpeaking,
  response, 
  onStartListening, 
  onStopListening 
}: ResponseSectionProps) {
  return (
    <div className="bg-gray-50 p-4 rounded-lg min-h-[100px]">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-gray-700">Your Response</h3>
        <div className="flex items-center gap-2">
          {isListening && (
            <span className="text-sm text-green-600 flex items-center gap-1">
              <Mic className="h-4 w-4 animate-pulse" />
              Recording...
            </span>
          )}
          <button
            onClick={isListening ? onStopListening : onStartListening}
            disabled={isProcessing || isSpeaking}
            className={`inline-flex items-center px-3 py-1.5 rounded-md text-sm font-medium ${
              isListening
                ? 'bg-red-100 text-red-700 hover:bg-red-200'
                : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
            } disabled:opacity-50`}
          >
            {isListening ? (
              <>
                <StopCircle className="h-4 w-4 mr-1" />
                Stop
              </>
            ) : (
              <>
                <Mic className="h-4 w-4 mr-1" />
                Start Speaking
              </>
            )}
          </button>
        </div>
      </div>
      <p className="text-gray-700 whitespace-pre-wrap">{response || 'Your response will appear here...'}</p>
    </div>
  );
}
import React from 'react';
import { Mic } from 'lucide-react';

interface AudioLevelIndicatorProps {
  audioLevel: number;
}

export function AudioLevelIndicator({ audioLevel }: AudioLevelIndicatorProps) {
  return (
    <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-black/50 px-3 py-1 rounded-full">
      <Mic className="h-4 w-4 text-white" />
      <div className="w-20 h-2 bg-gray-700 rounded-full overflow-hidden">
        <div 
          className="h-full bg-green-500 transition-all duration-100"
          style={{ width: `${audioLevel * 100}%` }}
        />
      </div>
    </div>
  );
}
import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { useSpeechInitialization } from '../../hooks/useSpeechInitialization';

export function SpeechSupportCheck({ children }: { children: React.ReactNode }) {
  const { synthesis, recognition, error } = useSpeechInitialization();

  if (error) {
    return (
      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
        <div className="flex">
          <AlertTriangle className="h-5 w-5 text-yellow-400" />
          <div className="ml-3">
            <p className="text-sm text-yellow-700">{error}</p>
            <p className="mt-2 text-sm text-yellow-600">
              For the best experience, please use a modern browser like Chrome, Edge, or Safari.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (!synthesis || !recognition) {
    return null;
  }

  return <>{children}</>;
}
import React, { useState, useEffect } from 'react';
import { useSpeechRecognition } from '../../hooks/useSpeechRecognition';
import { useTextToSpeech } from '../../hooks/useTextToSpeech';
import { getNextQuestion, evaluateResponse } from '../../services/interview';
import { QuestionDisplay } from './QuestionDisplay';
import { ResponseSection } from './ResponseSection';
import { FeedbackDisplay } from './FeedbackDisplay';
import { SpeechSupportCheck } from './SpeechSupportCheck';
import { ErrorMessage } from '../Common/ErrorMessage';
import type { InterviewState } from '../../services/interview/types';

interface InterviewConversationProps {
  position: string;
  cvText: string;
  jobDescription: string;
}

export function InterviewConversation({ 
  position, 
  cvText, 
  jobDescription
}: InterviewConversationProps) {
  const [currentQuestion, setCurrentQuestion] = useState('');
  const [questionNumber, setQuestionNumber] = useState(1);
  const [userResponse, setUserResponse] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showNextButton, setShowNextButton] = useState(false);
  const [conversationContext, setConversationContext] = useState<string[]>([]);

  const { 
    transcript, 
    isListening, 
    startListening, 
    stopListening, 
    clearTranscript,
    hasSupport 
  } = useSpeechRecognition();
  
  const { speak, isSpeaking } = useTextToSpeech();

  // Update transcript when speech recognition is active
  useEffect(() => {
    if (isListening && transcript) {
      setUserResponse(transcript);
    }
  }, [transcript, isListening]);

  // Initialize interview with first question
  useEffect(() => {
    const getInitialQuestion = async () => {
      try {
        const state: InterviewState = {
          currentQuestion: '',
          questionNumber: 1,
          cvText,
          jobDetails: {
            title: position,
            description: jobDescription
          },
          context: [
            `Position: ${position}`,
            `Job Description: ${jobDescription}`,
            `CV: ${cvText}`
          ]
        };

        const question = await getNextQuestion(state);
        setCurrentQuestion(question);
        speak(question);
      } catch (error) {
        setError('Failed to start interview. Please try again.');
      }
    };

    if (position && cvText && jobDescription) {
      getInitialQuestion();
    }
  }, [position, cvText, jobDescription, speak]);

  const handleStartRecording = () => {
    if (!hasSupport) {
      setError('Speech recognition is not supported in your browser');
      return;
    }
    setError(null);
    clearTranscript();
    setUserResponse('');
    startListening();
  };

  const handleStopRecording = async () => {
    stopListening();
    
    if (!userResponse.trim()) {
      setError('No response detected. Please try again.');
      return;
    }
    
    setIsProcessing(true);
    try {
      const responseFeedback = await evaluateResponse(
        userResponse, 
        currentQuestion,
        {
          title: position,
          description: jobDescription
        }
      );
      
      setFeedback(responseFeedback);
      setShowNextButton(true);
      
      // Add to conversation context
      setConversationContext(prev => [
        ...prev,
        `Q${questionNumber}: ${currentQuestion}`,
        `A: ${userResponse}`,
        `Feedback: ${responseFeedback}`
      ]);
    } catch (error) {
      setError('Failed to analyze response. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleNextQuestion = async () => {
    setIsProcessing(true);
    setShowNextButton(false);
    setFeedback(null);
    clearTranscript();
    setUserResponse('');
    
    try {
      const state: InterviewState = {
        currentQuestion,
        questionNumber: questionNumber + 1,
        cvText,
        jobDetails: {
          title: position,
          description: jobDescription
        },
        context: conversationContext
      };

      const nextQuestion = await getNextQuestion(state);
      setCurrentQuestion(nextQuestion);
      setQuestionNumber(prev => prev + 1);
      speak(nextQuestion);
    } catch (error) {
      setError('Failed to get next question. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (!position || !cvText || !jobDescription) {
    return (
      <ErrorMessage message="Please ensure all required information is provided before starting the interview." />
    );
  }

  return (
    <SpeechSupportCheck>
      <div className="space-y-6">
        <QuestionDisplay 
          questionNumber={questionNumber}
          question={currentQuestion}
        />

        <ResponseSection
          isListening={isListening}
          isProcessing={isProcessing}
          isSpeaking={isSpeaking}
          response={userResponse}
          onStartListening={handleStartRecording}
          onStopListening={handleStopRecording}
        />

        {feedback && <FeedbackDisplay feedback={feedback} />}

        {error && (
          <ErrorMessage message={error} />
        )}

        {showNextButton && (
          <button
            onClick={handleNextQuestion}
            disabled={isProcessing}
            className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {isProcessing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                Loading next question...
              </>
            ) : (
              'Next Question'
            )}
          </button>
        )}
      </div>
    </SpeechSupportCheck>
  );
}
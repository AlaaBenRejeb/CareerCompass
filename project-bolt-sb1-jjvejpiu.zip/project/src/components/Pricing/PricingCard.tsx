import React from 'react';
import { CheckCircle, Loader } from 'lucide-react';
import type { PricingPlan } from '../../types/payment';

interface PricingCardProps {
  plan: PricingPlan;
  isProcessing: boolean;
  onSubscribe: (plan: PricingPlan) => void;
}

export function PricingCard({ plan, isProcessing, onSubscribe }: PricingCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="px-6 py-8">
        <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
        <p className="mt-4 text-gray-500">{plan.description}</p>
        <p className="mt-8">
          <span className="text-4xl font-bold text-gray-900">
            ${(plan.price / 100).toFixed(2)}
          </span>
          <span className="text-gray-500">/{plan.interval}</span>
        </p>

        <ul className="mt-8 space-y-4">
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
              <span className="ml-3 text-gray-600">{feature}</span>
            </li>
          ))}
        </ul>

        <button
          onClick={() => onSubscribe(plan)}
          disabled={isProcessing}
          className="mt-8 w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
        >
          {isProcessing ? (
            <span className="flex items-center justify-center">
              <Loader className="animate-spin h-5 w-5 mr-2" />
              Processing...
            </span>
          ) : (
            'Subscribe Now'
          )}
        </button>
      </div>
    </div>
  );
}
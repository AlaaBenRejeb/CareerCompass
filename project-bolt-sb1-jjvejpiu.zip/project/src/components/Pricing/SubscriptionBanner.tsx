import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle } from 'lucide-react';

interface SubscriptionBannerProps {
  daysLeft?: number;
}

export function SubscriptionBanner({ daysLeft }: SubscriptionBannerProps) {
  return (
    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
      <div className="flex">
        <div className="flex-shrink-0">
          <AlertTriangle className="h-5 w-5 text-yellow-400" />
        </div>
        <div className="ml-3">
          <p className="text-sm text-yellow-700">
            {daysLeft ? (
              <>Your free trial ends in {daysLeft} days. </>
            ) : (
              <>You don't have an active subscription. </>
            )}
            <Link
              to="/pricing"
              className="font-medium underline text-yellow-700 hover:text-yellow-600"
            >
              Upgrade now
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
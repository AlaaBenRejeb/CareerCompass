import React from 'react';
import { Eye, EyeOff, Download, Sparkles } from 'lucide-react';
import type { CV } from '../../types/cv';
import { generatePDF } from '../../utils/pdfGenerator';

interface CVControlsProps {
  cv: CV;
  onPreviewToggle: () => void;
  onOptimize: () => void;
  previewMode: boolean;
  isOptimizing: boolean;
}

export function CVControls({ cv, onPreviewToggle, onOptimize, previewMode, isOptimizing }: CVControlsProps) {
  const handleDownload = () => {
    const filename = `${cv.personalInfo.fullName.toLowerCase().replace(/\s+/g, '')}.pdf`;
    generatePDF(cv, { filename });
  };

  return (
    <div className="bg-gray-50 px-6 py-4 border-b flex justify-between items-center">
      <h1 className="text-xl font-semibold text-gray-900">CV Builder</h1>
      <div className="flex gap-2">
        <button
          onClick={onPreviewToggle}
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          {previewMode ? (
            <>
              <EyeOff className="h-4 w-4 mr-2" />
              Edit Mode
            </>
          ) : (
            <>
              <Eye className="h-4 w-4 mr-2" />
              Preview
            </>
          )}
        </button>
        <button
          onClick={onOptimize}
          disabled={isOptimizing}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
        >
          {isOptimizing ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
              Optimizing...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4 mr-2" />
              Optimize with AI
            </>
          )}
        </button>
        <button
          onClick={handleDownload}
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          <Download className="h-4 w-4 mr-2" />
          Download PDF
        </button>
      </div>
    </div>
  );
}
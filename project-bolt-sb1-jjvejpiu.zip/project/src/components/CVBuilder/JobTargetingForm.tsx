import React from 'react';
import { Briefcase } from 'lucide-react';
import type { JobTarget } from '../../services/cv-optimization/types';

interface JobTargetingFormProps {
  jobTarget: JobTarget;
  onChange: (field: keyof JobTarget, value: string | string[]) => void;
}

export function JobTargetingForm({ jobTarget, onChange }: JobTargetingFormProps) {
  const handleRequirementsChange = (value: string) => {
    onChange('requirements', value.split('\n').filter(Boolean));
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md space-y-6">
      <div className="flex items-center gap-2">
        <Briefcase className="h-5 w-5 text-blue-600" />
        <h3 className="text-lg font-medium text-gray-900">Target Job Details</h3>
      </div>

      <div>
        <label htmlFor="jobTitle" className="block text-sm font-medium text-gray-700">
          Job Title
        </label>
        <input
          type="text"
          id="jobTitle"
          value={jobTarget.title}
          onChange={(e) => onChange('title', e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          placeholder="e.g. Senior Software Engineer"
        />
      </div>

      <div>
        <label htmlFor="jobDescription" className="block text-sm font-medium text-gray-700">
          Job Description
        </label>
        <textarea
          id="jobDescription"
          value={jobTarget.description}
          onChange={(e) => onChange('description', e.target.value)}
          rows={4}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          placeholder="Paste the full job description here..."
        />
      </div>

      <div>
        <label htmlFor="requirements" className="block text-sm font-medium text-gray-700">
          Key Requirements (one per line)
        </label>
        <textarea
          id="requirements"
          value={jobTarget.requirements.join('\n')}
          onChange={(e) => handleRequirementsChange(e.target.value)}
          rows={4}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          placeholder="Enter key requirements, one per line..."
        />
      </div>
    </div>
  );
}
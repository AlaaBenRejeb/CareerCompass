import React, { useState } from 'react';
import { Search, Plus, X } from 'lucide-react';
import { SKILLS_LIST } from '../../data/skillsList';

interface SkillsInputProps {
  skills: string[];
  onChange: (skills: string[]) => void;
}

export function SkillsInput({ skills, onChange }: SkillsInputProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [customSkill, setCustomSkill] = useState('');

  const handleAddSkill = (skill: string) => {
    if (!skills.includes(skill)) {
      onChange([...skills, skill]);
      setSearchTerm('');
      setCustomSkill('');
      setShowCustomInput(false);
    }
  };

  const handleAddCustomSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (customSkill.trim() && !skills.includes(customSkill.trim())) {
      handleAddSkill(customSkill.trim());
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    onChange(skills.filter(skill => skill !== skillToRemove));
  };

  const getFilteredSkills = () => {
    if (!searchTerm.trim()) return [];

    const searchLower = searchTerm.toLowerCase();
    const results: string[] = [];

    Object.values(SKILLS_LIST).forEach(category => {
      Object.values(category).forEach(subcategory => {
        subcategory.forEach(skill => {
          if (skill.toLowerCase().includes(searchLower)) {
            results.push(skill);
          }
        });
      });
    });

    return results.filter(skill => !skills.includes(skill)).slice(0, 5);
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <div className="flex items-center border border-gray-300 rounded-md">
          <Search className="h-5 w-5 text-gray-400 ml-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Type to search skills or add your own"
            className="w-full p-2 pl-3 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Search Results */}
        {searchTerm && (
          <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg">
            {getFilteredSkills().map(skill => (
              <button
                key={skill}
                onClick={() => handleAddSkill(skill)}
                className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-blue-50"
              >
                {skill}
              </button>
            ))}
            <button
              onClick={() => {
                setShowCustomInput(true);
                setCustomSkill(searchTerm);
              }}
              className="w-full px-4 py-2 text-left text-sm text-blue-600 hover:bg-blue-50 border-t"
            >
              <Plus className="h-4 w-4 inline-block mr-2" />
              Add "{searchTerm}" as custom skill
            </button>
          </div>
        )}

        {/* Custom Skill Input */}
        {showCustomInput && (
          <form onSubmit={handleAddCustomSkill} className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg p-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Add Custom Skill
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={customSkill}
                onChange={(e) => setCustomSkill(e.target.value)}
                className="flex-1 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter skill name"
                autoFocus
              />
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Add
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowCustomInput(false);
                  setCustomSkill('');
                }}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Selected Skills */}
      <div className="flex flex-wrap gap-2">
        {skills.map(skill => (
          <div
            key={skill}
            className="group flex items-center gap-2 px-3 py-1.5 bg-gray-100 text-gray-800 rounded-md text-sm hover:bg-gray-200 transition-colors"
          >
            {skill}
            <button
              onClick={() => handleRemoveSkill(skill)}
              className="opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="h-3.5 w-3.5 text-gray-500 hover:text-gray-700" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { AIEnhanceButton } from './AIEnhanceButton';
import { enhanceText } from '../../services/aiEnhancement';
import type { CV } from '../../types/cv';

interface ExperienceSectionProps {
  experience: CV['experience'];
  onChange: (experience: CV['experience']) => void;
}

export function ExperienceSection({ experience, onChange }: ExperienceSectionProps) {
  const [enhancingId, setEnhancingId] = useState<string | null>(null);

  const handleAdd = () => {
    onChange([
      ...experience,
      {
        id: Date.now().toString(),
        company: '',
        position: '',
        startDate: '',
        endDate: '',
        description: '',
        keywords: []
      }
    ]);
  };

  const handleRemove = (id: string) => {
    onChange(experience.filter(exp => exp.id !== id));
  };

  const handleChange = (id: string, field: keyof CV['experience'][0], value: string) => {
    onChange(
      experience.map(exp =>
        exp.id === id ? { ...exp, [field]: value } : exp
      )
    );
  };

  const handleEnhanceDescription = async (id: string) => {
    const exp = experience.find(e => e.id === id);
    if (!exp) return;

    setEnhancingId(id);
    try {
      const enhanced = await enhanceText(exp.description, `Position: ${exp.position}, Company: ${exp.company}`);
      handleChange(id, 'description', enhanced);
    } catch (error) {
      console.error('Failed to enhance description:', error);
    } finally {
      setEnhancingId(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Experience</h2>
        <button
          type="button"
          onClick={handleAdd}
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-blue-600 bg-blue-100 hover:bg-blue-200"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Experience
        </button>
      </div>

      {experience.map((exp) => (
        <div key={exp.id} className="bg-gray-50 p-4 rounded-lg space-y-4">
          <div className="flex justify-between">
            <div className="flex-1 grid grid-cols-2 gap-4">
              <input
                type="text"
                value={exp.position}
                onChange={(e) => handleChange(exp.id, 'position', e.target.value)}
                placeholder="Position"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <input
                type="text"
                value={exp.company}
                onChange={(e) => handleChange(exp.id, 'company', e.target.value)}
                placeholder="Company"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <button
              type="button"
              onClick={() => handleRemove(exp.id)}
              className="ml-4 text-red-600 hover:text-red-700"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              value={exp.startDate}
              onChange={(e) => handleChange(exp.id, 'startDate', e.target.value)}
              placeholder="Start Date (MM/YYYY)"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            <input
              type="text"
              value={exp.endDate}
              onChange={(e) => handleChange(exp.id, 'endDate', e.target.value)}
              placeholder="End Date (MM/YYYY or Present)"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-start gap-2">
            <textarea
              value={exp.description}
              onChange={(e) => handleChange(exp.id, 'description', e.target.value)}
              placeholder="Description of your responsibilities and achievements"
              rows={4}
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            <AIEnhanceButton 
              onClick={() => handleEnhanceDescription(exp.id)}
              isLoading={enhancingId === exp.id}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
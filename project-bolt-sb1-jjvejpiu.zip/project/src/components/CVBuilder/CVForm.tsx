import React from 'react';
import { PersonalInfo } from './PersonalInfo';
import { ExperienceSection } from './ExperienceSection';
import { EducationSection } from './EducationSection';
import { SkillsSection } from './SkillsSection';
import { LanguagesSection } from './LanguagesSection';
import { BestPracticesTips } from './BestPracticesTips';
import type { CV } from '../../types/cv';

interface CVFormProps {
  cv: CV;
  onChange: (cv: CV) => void;
}

export function CVForm({ cv, onChange }: CVFormProps) {
  const handlePersonalInfoChange = (field: keyof CV['personalInfo'], value: string) => {
    onChange({
      ...cv,
      personalInfo: {
        ...cv.personalInfo,
        [field]: value
      }
    });
  };

  return (
    <div className="space-y-8">
      <BestPracticesTips />
      <PersonalInfo
        personalInfo={cv.personalInfo}
        onChange={handlePersonalInfoChange}
      />
      <ExperienceSection
        experience={cv.experience}
        onChange={(experience) => onChange({ ...cv, experience })}
      />
      <EducationSection
        education={cv.education}
        onChange={(education) => onChange({ ...cv, education })}
      />
      <SkillsSection
        skills={cv.skills}
        onChange={(skills) => onChange({ ...cv, skills })}
      />
      <LanguagesSection
        languages={cv.languages}
        onChange={(languages) => onChange({ ...cv, languages })}
      />
    </div>
  );
}
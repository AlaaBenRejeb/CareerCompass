import React from 'react';
import { Info, CheckCircle } from 'lucide-react';
import { CV_BEST_PRACTICES } from '../../utils/cvBestPractices';

export function BestPracticesTips() {
  return (
    <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-md mb-6">
      <div className="flex items-start">
        <Info className="h-5 w-5 text-blue-500 mt-0.5 mr-3" />
        <div>
          <h3 className="text-lg font-medium text-blue-800 mb-2">CV Best Practices</h3>
          <div className="grid gap-4 md:grid-cols-2">
            {Object.entries(CV_BEST_PRACTICES).map(([category, practices]) => (
              <div key={category}>
                <h4 className="text-sm font-semibold text-blue-700 mb-2 capitalize">
                  {category}
                </h4>
                <ul className="space-y-1">
                  {practices.map((practice, index) => (
                    <li key={index} className="flex items-start text-sm text-blue-600">
                      <CheckCircle className="h-4 w-4 text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
                      <span>{practice}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { User, Mail, Phone, MapPin, Briefcase } from 'lucide-react';
import { AIEnhanceButton } from './AIEnhanceButton';
import { enhanceJobTitle } from '../../services/aiEnhancement';

interface PersonalInfoProps {
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    location: string;
    title: string;
  };
  onChange: (field: string, value: string) => void;
}

export function PersonalInfo({ personalInfo, onChange }: PersonalInfoProps) {
  const handleEnhanceTitle = async () => {
    try {
      const enhanced = await enhanceJobTitle(personalInfo.title);
      onChange('title', enhanced);
    } catch (error) {
      console.error('Failed to enhance title:', error);
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-800">Personal Information</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Full Name"
            value={personalInfo.fullName}
            onChange={(e) => onChange('fullName', e.target.value)}
            className="pl-10 w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <div className="relative">
          <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="email"
            placeholder="Email"
            value={personalInfo.email}
            onChange={(e) => onChange('email', e.target.value)}
            className="pl-10 w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <div className="relative">
          <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="tel"
            placeholder="Phone"
            value={personalInfo.phone}
            onChange={(e) => onChange('phone', e.target.value)}
            className="pl-10 w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <div className="relative">
          <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Location"
            value={personalInfo.location}
            onChange={(e) => onChange('location', e.target.value)}
            className="pl-10 w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <div className="relative md:col-span-2 flex gap-2">
          <div className="flex-1 relative">
            <Briefcase className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Professional Title"
              value={personalInfo.title}
              onChange={(e) => onChange('title', e.target.value)}
              className="pl-10 w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <AIEnhanceButton onClick={handleEnhanceTitle} />
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import type { CV } from '../../types/cv';

interface CVPreviewProps {
  cv: CV;
}

export function CVPreview({ cv }: CVPreviewProps) {
  const renderBulletPoints = (description: string) => {
    return description.split('\n• ').map((bullet, index) => (
      bullet.trim() && (
        <li key={index} className="ml-6 text-gray-700">
          {bullet.replace(/^• /, '')}
        </li>
      )
    ));
  };

  return (
    <div className="w-full max-w-4xl mx-auto bg-white shadow-md rounded-lg p-8 overflow-y-auto">
      {/* Personal Info */}
      <div className="text-center mb-8 pb-6 border-b border-gray-200">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{cv.personalInfo.fullName}</h1>
        <p className="text-xl text-gray-600 mb-4">{cv.personalInfo.title}</p>
        <div className="text-gray-600 space-y-1">
          <p>{cv.personalInfo.email}</p>
          <p>{cv.personalInfo.phone}</p>
          <p>{cv.personalInfo.location}</p>
        </div>
      </div>

      {/* Experience */}
      {cv.experience.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Professional Experience</h2>
          <div className="space-y-6">
            {cv.experience.map((exp) => (
              <div key={exp.id} className="pb-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-semibold text-gray-900">{exp.position}</h3>
                  <span className="text-gray-600 text-sm">{exp.startDate} - {exp.endDate}</span>
                </div>
                <p className="text-gray-600 mb-2">{exp.company}</p>
                <ul className="list-disc space-y-1">
                  {renderBulletPoints(exp.description)}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {cv.education.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Education</h2>
          <div className="space-y-4">
            {cv.education.map((edu) => (
              <div key={edu.id} className="pb-4">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="text-xl font-semibold text-gray-900">{edu.degree}</h3>
                  <span className="text-gray-600 text-sm">{edu.startDate} - {edu.endDate}</span>
                </div>
                <p className="text-gray-600">{edu.institution}</p>
                {edu.field && <p className="text-gray-700 mt-1">{edu.field}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Languages */}
      {cv.languages.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Languages</h2>
          <div className="grid grid-cols-2 gap-4">
            {cv.languages.map((lang) => (
              <div key={lang.id} className="flex justify-between items-center bg-gray-50 p-3 rounded-lg">
                <span className="font-medium text-gray-900">{lang.name}</span>
                <span className="text-gray-600 text-sm">{lang.proficiency}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {cv.skills.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Skills</h2>
          <div className="flex flex-wrap gap-2">
            {cv.skills.map((skill, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
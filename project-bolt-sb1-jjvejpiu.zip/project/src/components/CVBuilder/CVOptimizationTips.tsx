import React from 'react';
import { AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import type { OptimizationTips } from '../../types/cv';

interface CVOptimizationTipsProps {
  tips: OptimizationTips;
}

export function CVOptimizationTips({ tips }: CVOptimizationTipsProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-gray-900">ATS Optimization Tips</h3>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-600">Match Score:</span>
          <span className={`text-xl font-bold ${
            tips.matchScore >= 80 ? 'text-green-600' :
            tips.matchScore >= 60 ? 'text-yellow-600' :
            'text-red-600'
          }`}>
            {tips.matchScore}%
          </span>
        </div>
      </div>

      {/* Missing Keywords */}
      {tips.missingKeywords.length > 0 && (
        <div className="mb-6">
          <h4 className="flex items-center gap-2 text-red-600 font-medium mb-3">
            <XCircle className="h-5 w-5" />
            Missing Keywords
          </h4>
          <div className="grid grid-cols-2 gap-2">
            {tips.missingKeywords.map((keyword, index) => (
              <div key={index} className="bg-red-50 text-red-700 px-3 py-2 rounded-md text-sm">
                {keyword}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Matched Keywords */}
      {tips.foundKeywords.length > 0 && (
        <div className="mb-6">
          <h4 className="flex items-center gap-2 text-green-600 font-medium mb-3">
            <CheckCircle className="h-5 w-5" />
            Matched Keywords
          </h4>
          <div className="grid grid-cols-2 gap-2">
            {tips.foundKeywords.map((keyword, index) => (
              <div key={index} className="bg-green-50 text-green-700 px-3 py-2 rounded-md text-sm">
                {keyword}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Improvement Suggestions */}
      {tips.suggestions.length > 0 && (
        <div>
          <h4 className="flex items-center gap-2 text-blue-600 font-medium mb-3">
            <AlertCircle className="h-5 w-5" />
            Suggested Improvements
          </h4>
          <div className="space-y-2">
            {tips.suggestions.map((suggestion, index) => (
              <div key={index} className="bg-blue-50 text-blue-700 px-4 py-3 rounded-md text-sm">
                {suggestion}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
import React from 'react';
import { Briefcase } from 'lucide-react';

interface JobTargetingProps {
  jobDescription: string;
  onChange: (value: string) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
}

export function JobTargetingSection({ jobDescription, onChange, onAnalyze, isAnalyzing }: JobTargetingProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Briefcase className="h-5 w-5 text-blue-600" />
        <h2 className="text-xl font-semibold text-gray-900">Target Job Description</h2>
      </div>
      
      <textarea
        value={jobDescription}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Paste the job description here to optimize your CV..."
        rows={6}
        className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
      />

      <button
        onClick={onAnalyze}
        disabled={!jobDescription.trim() || isAnalyzing}
        className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isAnalyzing ? (
          <>
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
            Analyzing...
          </>
        ) : (
          'Analyze & Optimize CV'
        )}
      </button>
    </div>
  );
}
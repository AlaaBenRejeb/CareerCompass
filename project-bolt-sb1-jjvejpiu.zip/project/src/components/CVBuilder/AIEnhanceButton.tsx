import React from 'react';
import { Sparkles } from 'lucide-react';

interface AIEnhanceButtonProps {
  onClick: () => void;
  isLoading?: boolean;
}

export function AIEnhanceButton({ onClick, isLoading = false }: AIEnhanceButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={isLoading}
      className="inline-flex items-center px-2 py-1 text-sm font-medium text-blue-600 bg-blue-50 rounded-md hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
    >
      {isLoading ? (
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600" />
      ) : (
        <>
          <Sparkles className="h-4 w-4 mr-1" />
          Enhance
        </>
      )}
    </button>
  );
}
import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import type { CV } from '../../types/cv';

interface EducationSectionProps {
  education: CV['education'];
  onChange: (education: CV['education']) => void;
}

export function EducationSection({ education, onChange }: EducationSectionProps) {
  const handleAdd = () => {
    onChange([
      ...education,
      {
        id: Date.now().toString(),
        institution: '',
        degree: '',
        field: '',
        startDate: '',
        endDate: ''
      }
    ]);
  };

  const handleRemove = (id: string) => {
    onChange(education.filter(edu => edu.id !== id));
  };

  const handleChange = (id: string, field: keyof CV['education'][0], value: string) => {
    onChange(
      education.map(edu =>
        edu.id === id ? { ...edu, [field]: value } : edu
      )
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Education</h2>
        <button
          type="button"
          onClick={handleAdd}
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-blue-600 bg-blue-100 hover:bg-blue-200"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Education
        </button>
      </div>

      {education.map((edu) => (
        <div key={edu.id} className="bg-gray-50 p-4 rounded-lg space-y-4">
          <div className="flex justify-between">
            <div className="flex-1 grid grid-cols-2 gap-4">
              <input
                type="text"
                value={edu.degree}
                onChange={(e) => handleChange(edu.id, 'degree', e.target.value)}
                placeholder="Degree"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <input
                type="text"
                value={edu.institution}
                onChange={(e) => handleChange(edu.id, 'institution', e.target.value)}
                placeholder="Institution"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <button
              type="button"
              onClick={() => handleRemove(edu.id)}
              className="ml-4 text-red-600 hover:text-red-700"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          </div>

          <input
            type="text"
            value={edu.field}
            onChange={(e) => handleChange(edu.id, 'field', e.target.value)}
            placeholder="Field of Study"
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />

          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              value={edu.startDate}
              onChange={(e) => handleChange(edu.id, 'startDate', e.target.value)}
              placeholder="Start Date (MM/YYYY)"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            <input
              type="text"
              value={edu.endDate}
              onChange={(e) => handleChange(edu.id, 'endDate', e.target.value)}
              placeholder="End Date (MM/YYYY or Present)"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>
      ))}
    </div>
  );
}
import React from 'react';
import { AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import type { ATSScore } from '../../types/cv';

interface ATSScoreProps {
  score: ATSScore;
}

export function ATSScore({ score }: ATSScoreProps) {
  const getScoreColor = (value: number) => {
    if (value >= 80) return 'text-green-500';
    if (value >= 60) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getScoreIcon = (value: number) => {
    if (value >= 80) return <CheckCircle className="h-5 w-5" />;
    if (value >= 60) return <AlertCircle className="h-5 w-5" />;
    return <XCircle className="h-5 w-5" />;
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">ATS Score Analysis</h2>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Overall Score</span>
          <div className={`flex items-center gap-2 ${getScoreColor(score.overall)}`}>
            {getScoreIcon(score.overall)}
            <span className="font-semibold">{score.overall}%</span>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Keyword Match</span>
            <span className={getScoreColor(score.keywordMatch)}>{score.keywordMatch}%</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Format Score</span>
            <span className={getScoreColor(score.formatScore)}>{score.formatScore}%</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Readability</span>
            <span className={getScoreColor(score.readabilityScore)}>{score.readabilityScore}%</span>
          </div>
        </div>

        {score.suggestions.length > 0 && (
          <div className="mt-4">
            <h3 className="text-sm font-semibold text-gray-700 mb-2">Suggestions for Improvement</h3>
            <ul className="list-disc list-inside space-y-1">
              {score.suggestions.map((suggestion, index) => (
                <li key={index} className="text-sm text-gray-600">{suggestion}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
import React from 'react';
import { Sparkles } from 'lucide-react';

interface AIOptimizeButtonProps {
  onClick: () => void;
  isOptimizing: boolean;
}

export function AIOptimizeButton({ onClick, isOptimizing }: AIOptimizeButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={isOptimizing}
      className="fixed bottom-6 right-6 flex items-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
    >
      {isOptimizing ? (
        <>
          <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
          Optimizing...
        </>
      ) : (
        <>
          <Sparkles className="h-5 w-5" />
          Optimize with AI
        </>
      )}
    </button>
  );
}
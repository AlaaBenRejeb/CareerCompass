import React, { useState } from 'react';
import { FileText } from 'lucide-react';
import { FeatureDescription } from '../Common/FeatureDescription';
import { featureDescriptions } from '../../data/featureDescriptions';
import { CVForm } from './CVForm';
import { CVPreview } from './CVPreview';
import { CVControls } from './CVControls';
import { CVOptimizationTips } from './CVOptimizationTips';
import { optimizeCVForJob } from '../../services/cv-optimization/service';
import { ErrorMessage } from '../Common/ErrorMessage';
import type { CV } from '../../types/cv';
import type { OptimizationResult } from '../../services/cv-optimization/types';

const DEFAULT_CV: CV = {
  personalInfo: {
    fullName: '',
    email: '',
    phone: '',
    location: '',
    title: ''
  },
  experience: [],
  education: [],
  skills: [],
  languages: []
};

export function CVBuilder() {
  const [cv, setCV] = useState<CV>(DEFAULT_CV);
  const [previewMode, setPreviewMode] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [optimizationResult, setOptimizationResult] = useState<OptimizationResult | null>(null);

  const handleOptimize = async () => {
    if (!cv.personalInfo.fullName || !cv.personalInfo.email) {
      setError('Please fill in your personal information before optimizing');
      return;
    }

    setIsOptimizing(true);
    setError(null);
    
    try {
      const result = await optimizeCVForJob(cv);
      
      if (result.cv) {
        setCV(result.cv);
        setOptimizationResult(result);
        setError('CV successfully optimized!');
      } else {
        throw new Error('Failed to optimize CV');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to optimize CV');
    } finally {
      setIsOptimizing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <FeatureDescription
        title={featureDescriptions.cvBuilder.title}
        description={featureDescriptions.cvBuilder.description}
        icon={FileText}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <CVControls 
              cv={cv}
              onPreviewToggle={() => setPreviewMode(!previewMode)}
              onOptimize={handleOptimize}
              previewMode={previewMode}
              isOptimizing={isOptimizing}
            />
            
            <div className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  {previewMode ? (
                    <CVPreview cv={cv} />
                  ) : (
                    <CVForm cv={cv} onChange={setCV} />
                  )}
                </div>
                
                <div className="space-y-8">
                  {error && (
                    <ErrorMessage 
                      message={error} 
                      type={error.includes('success') ? 'success' : 'error'} 
                    />
                  )}
                  
                  {optimizationResult && (
                    <CVOptimizationTips tips={{
                      matchScore: optimizationResult.matchScore,
                      foundKeywords: optimizationResult.keywordMatches.found,
                      missingKeywords: optimizationResult.keywordMatches.missing,
                      suggestions: optimizationResult.suggestions
                    }} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
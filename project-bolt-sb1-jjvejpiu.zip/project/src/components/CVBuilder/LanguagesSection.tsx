import React from 'react';
import { Plus, Trash2, Globe2 } from 'lucide-react';
import type { Language } from '../../types/cv';

interface LanguagesSectionProps {
  languages: Language[];
  onChange: (languages: Language[]) => void;
}

const PROFICIENCY_LEVELS = ['Native', 'Fluent', 'Advanced', 'Intermediate', 'Basic'] as const;

export function LanguagesSection({ languages, onChange }: LanguagesSectionProps) {
  const handleAdd = () => {
    onChange([
      ...languages,
      {
        id: Date.now().toString(),
        name: '',
        proficiency: 'Intermediate'
      }
    ]);
  };

  const handleRemove = (id: string) => {
    onChange(languages.filter(lang => lang.id !== id));
  };

  const handleChange = (id: string, field: keyof Language, value: string) => {
    onChange(
      languages.map(lang =>
        lang.id === id ? { ...lang, [field]: value } : lang
      )
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
          <Globe2 className="h-5 w-5 text-blue-600" />
          Languages
        </h2>
        <button
          type="button"
          onClick={handleAdd}
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-blue-600 bg-blue-100 hover:bg-blue-200"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Language
        </button>
      </div>

      {languages.map((lang) => (
        <div key={lang.id} className="bg-gray-50 p-4 rounded-lg flex items-center gap-4">
          <div className="flex-1 grid grid-cols-2 gap-4">
            <input
              type="text"
              value={lang.name}
              onChange={(e) => handleChange(lang.id, 'name', e.target.value)}
              placeholder="Language"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            <select
              value={lang.proficiency}
              onChange={(e) => handleChange(lang.id, 'proficiency', e.target.value)}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              {PROFICIENCY_LEVELS.map(level => (
                <option key={level} value={level}>{level}</option>
              ))}
            </select>
          </div>
          <button
            type="button"
            onClick={() => handleRemove(lang.id)}
            className="text-red-600 hover:text-red-700"
          >
            <Trash2 className="h-5 w-5" />
          </button>
        </div>
      ))}
    </div>
  );
}
// Export the CVBuilder component
export { CVBuilder } from './CVBuilder';
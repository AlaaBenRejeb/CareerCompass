import React from 'react';
import { SkillsInput } from './SkillsInput';

interface SkillsSectionProps {
  skills: string[];
  onChange: (skills: string[]) => void;
}

export function SkillsSection({ skills, onChange }: SkillsSectionProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-800">Skills</h2>
      <SkillsInput skills={skills} onChange={onChange} />
    </div>
  );
}
import React from 'react';
import { Briefcase } from 'lucide-react';
import type { JobDescription } from '../../types/analysis';

interface JobDescriptionInputProps {
  jobDescription: JobDescription;
  onChange: (field: keyof JobDescription, value: string) => void;
}

export function JobDescriptionInput({ jobDescription, onChange }: JobDescriptionInputProps) {
  return (
    <div className="space-y-4 bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center gap-2">
        <Briefcase className="h-5 w-5 text-blue-600" />
        <h2 className="text-lg font-medium text-gray-900">Job Details</h2>
      </div>
      
      <div className="space-y-4">
        <div>
          <label htmlFor="jobTitle" className="block text-sm font-medium text-gray-700">
            Job Title
          </label>
          <input
            id="jobTitle"
            type="text"
            value={jobDescription.title}
            onChange={(e) => onChange('title', e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            placeholder="e.g. Senior Software Engineer"
          />
        </div>

        <div>
          <label htmlFor="jobDescription" className="block text-sm font-medium text-gray-700">
            Job Description
          </label>
          <textarea
            id="jobDescription"
            value={jobDescription.description}
            onChange={(e) => onChange('description', e.target.value)}
            rows={4}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            placeholder="Paste the full job description here..."
          />
        </div>
      </div>
    </div>
  );
}
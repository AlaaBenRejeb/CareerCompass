import React from 'react';
import { XCircle } from 'lucide-react';

export function ProblemSection() {
  const problems = [
    "You spend hours tweaking your CV, unsure if it's even making it past ATS filters.",
    "You're not sure what skills employers actually want.",
    "Writing a compelling cover letter feels impossible.",
    "Interviews leave you feeling anxious and unprepared.",
    "You're tired of rejection emails or, worse, no response at all."
  ];

  return (
    <div className="bg-gray-900 py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-4">
          The Job Market Is Tougher Than Ever—Are You Ready to Compete?
        </h2>
        <p className="text-xl text-gray-300 text-center mb-16 max-w-3xl mx-auto">
          You submit application after application, yet hear nothing back. Employers use Applicant Tracking Systems (ATS) to filter out resumes that don't meet specific criteria.
        </p>

        <h3 className="text-2xl font-bold text-white text-center mb-12">
          Does this sound familiar?
        </h3>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {problems.map((problem, index) => (
            <div key={index} className="bg-gray-800 p-6 rounded-xl border border-gray-700 hover:border-blue-500 transition-colors">
              <div className="flex items-start">
                <XCircle className="h-6 w-6 text-red-500 mt-1 flex-shrink-0" />
                <p className="ml-4 text-gray-300">{problem}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
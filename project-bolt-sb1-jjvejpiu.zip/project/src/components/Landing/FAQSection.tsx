import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "Is $19.99/month all I'll pay?",
      answer: "Yes! Your subscription includes unlimited access to all features, with no hidden fees."
    },
    {
      question: "How does the annual discount work?",
      answer: "When you choose annual billing, you save 20%—just $191.99/year for full access."
    },
    {
      question: "Can I cancel anytime?",
      answer: "Absolutely. You can cancel your subscription hassle-free at any time."
    },
    {
      question: "Do your CVs really pass ATS filters?",
      answer: "Yes! Our CV Builder and Analyzer are specifically designed to optimize resumes for ATS, giving you a better chance of being noticed by hiring managers."
    }
  ];

  return (
    <div className="relative bg-gray-900 py-24">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-96 h-96 top-1/4 left-1/4 bg-blue-500/10 rounded-full mix-blend-overlay filter blur-3xl animate-blob"></div>
        <div className="absolute w-96 h-96 bottom-1/4 right-1/4 bg-purple-500/10 rounded-full mix-blend-overlay filter blur-3xl animate-blob animation-delay-2000"></div>
      </div>

      <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <HelpCircle className="h-6 w-6 text-blue-400" />
            <h2 className="text-3xl font-bold text-white">Got Questions?</h2>
          </div>
          <p className="text-gray-300">We've got answers.</p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white/5 backdrop-blur-lg rounded-lg border border-white/10 overflow-hidden transition-all duration-200 hover:border-blue-500/50"
            >
              <button
                className="w-full px-6 py-4 text-left flex justify-between items-center focus:outline-none"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <span className="text-lg font-medium text-white">
                  {faq.question}
                </span>
                {openIndex === index ? (
                  <ChevronUp className="h-5 w-5 text-blue-400" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-blue-400" />
                )}
              </button>
              {openIndex === index && (
                <div className="px-6 pb-4">
                  <p className="text-gray-300">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { ArrowRight, Sparkles, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export function CTASection() {
  const features = [
    'Unlimited CVs, cover letters, and interview simulations',
    'Full access to all tools and personalized features',
    'AI-powered insights and recommendations',
    'Cancel anytime'
  ];

  return (
    <div className="relative bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900 py-24">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-96 h-96 -top-48 -left-48 bg-blue-500/20 rounded-full mix-blend-overlay filter blur-3xl animate-blob"></div>
        <div className="absolute w-96 h-96 -bottom-48 -right-48 bg-purple-500/20 rounded-full mix-blend-overlay filter blur-3xl animation-delay-2000"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Sparkles className="h-6 w-6 text-blue-400" />
          <h2 className="text-3xl font-bold text-white">Stop Guessing—Start Winning</h2>
        </div>
        
        <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
          Your dream job is waiting. Don't let an outdated resume or missed opportunities hold you back.
        </p>

        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-8 max-w-2xl mx-auto mb-8 border border-white/20">
          <div className="flex items-center justify-center gap-2 mb-6">
            <h3 className="text-2xl font-bold text-white">$19.99</h3>
            <span className="text-blue-200">/month</span>
          </div>

          <ul className="space-y-3 mb-8">
            {features.map((feature, index) => (
              <li key={index} className="flex items-center justify-center gap-2 text-blue-100">
                <CheckCircle className="h-5 w-5 text-blue-400 flex-shrink-0" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>

          <Link
            to="/auth"
            className="inline-flex items-center px-8 py-4 border-2 border-transparent text-lg font-medium rounded-full text-gray-900 bg-white hover:bg-blue-50 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            Get Started Now
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>

          <p className="mt-4 text-sm text-blue-200">
            Or save 20% with annual billing - just $191.99/year
          </p>
        </div>
      </div>
    </div>
  );
}
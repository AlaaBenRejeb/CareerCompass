import React from 'react';
import { FileSearch, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';

export function HeroSection() {
  return (
    <div className="relative min-h-screen bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900 overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-96 h-96 -top-48 -left-48 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
        <div className="absolute w-96 h-96 -bottom-48 -right-48 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute w-96 h-96 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-indigo-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-16">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Land Your Dream Job Faster with Our
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"> All-in-One Career Toolkit</span>
          </h1>
          
          <p className="text-xl text-blue-100 mb-4 max-w-3xl mx-auto">
            Craft ATS-friendly CVs, close skill gaps, ace interviews, and stand out with tailored cover letters—all for just $19.99/month.
          </p>
          
          <p className="text-lg text-blue-200 mb-12 max-w-2xl mx-auto">
            Stop struggling with outdated resumes and missed opportunities. Let our AI-powered tools guide you every step of the way.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/auth"
              className="inline-flex items-center px-8 py-4 border-2 border-transparent text-lg font-medium rounded-full text-blue-900 bg-white hover:bg-blue-50 transform hover:scale-105 transition-all shadow-lg hover:shadow-xl"
            >
              <TrendingUp className="h-5 w-5 mr-2" />
              Get Started Now
            </Link>
            <Link
              to="/auth"
              className="inline-flex items-center px-8 py-4 border-2 border-white text-lg font-medium rounded-full text-white hover:bg-white/10 transform hover:scale-105 transition-all"
            >
              <FileSearch className="h-5 w-5 mr-2" />
              Learn More
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
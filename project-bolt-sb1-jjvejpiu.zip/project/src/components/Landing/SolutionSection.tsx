import React from 'react';
import { FileText, TrendingUp, PenLine, Video, Sparkles } from 'lucide-react';

export function SolutionSection() {
  const solutions = [
    {
      icon: FileText,
      title: "ATS-Friendly CV Builder",
      description: "Create resumes that pass ATS filters effortlessly, increasing your chances of being seen by hiring managers."
    },
    {
      icon: TrendingUp,
      title: "Skill Gap Analysis",
      description: "Identify the skills you're missing and get personalized recommendations to fill the gaps."
    },
    {
      icon: PenLine,
      title: "Cover Letter Writer",
      description: "Generate tailored, professional cover letters that grab attention and land interviews."
    },
    {
      icon: Video,
      title: "AI Interview Simulator",
      description: "Practice with realistic questions and receive instant feedback to boost your confidence."
    }
  ];

  return (
    <div className="relative bg-gray-900 py-24">
      {/* Background glow effect */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-96 h-96 -top-48 -left-48 bg-blue-500/20 rounded-full mix-blend-overlay filter blur-3xl"></div>
        <div className="absolute w-96 h-96 -bottom-48 -right-48 bg-purple-500/20 rounded-full mix-blend-overlay filter blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="h-6 w-6 text-blue-400" />
            <h2 className="text-3xl font-bold text-white">We've Got You Covered</h2>
          </div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Our all-in-one career platform helps you go from frustrated job seeker to confident professional.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {solutions.map((solution, index) => (
            <div
              key={index}
              className="bg-gray-800/50 backdrop-blur-lg p-6 rounded-xl border border-gray-700 hover:border-blue-500 transition-all duration-300 group"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-blue-500/10 text-blue-400 group-hover:scale-110 transition-transform">
                  <solution.icon className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">
                    {solution.title}
                  </h3>
                  <p className="text-gray-300">
                    {solution.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, ArrowRight } from 'lucide-react';

export function WelcomeHero() {
  return (
    <div className="relative px-6 lg:px-8">
      <div className="mx-auto max-w-3xl pt-20 pb-32 sm:pt-48 sm:pb-40">
        <div>
          <div>
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
              Build Your Career Path with Confidence
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              Create professional CVs, get personalized feedback, and track your career progress - all in one place.
            </p>
            <div className="mt-8 flex gap-x-4">
              <Link
                to="/auth"
                className="inline-block rounded-lg bg-blue-600 px-4 py-1.5 text-base font-semibold leading-7 text-white shadow-sm hover:bg-blue-500 transition-colors"
              >
                Get started
                <ArrowRight className="inline-block ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/auth"
                className="inline-block rounded-lg px-4 py-1.5 text-base font-semibold leading-7 text-gray-300 ring-1 ring-gray-400/10 hover:ring-gray-300/20 transition-colors"
              >
                Learn more
                <FileText className="inline-block ml-2 h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
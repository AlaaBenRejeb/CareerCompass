import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { WelcomeHero } from './WelcomeHero';
import { Features } from './Features';

export function HomePage() {
  const { user } = useAuth();

  // Redirect authenticated users to the dashboard
  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-blue-900">
      <WelcomeHero />
      <Features />
    </div>
  );
}
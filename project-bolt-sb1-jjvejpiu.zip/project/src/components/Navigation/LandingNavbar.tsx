import React from 'react';
import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';

export function LandingNavbar() {
  return (
    <nav className="bg-transparent absolute top-0 left-0 right-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-6">
          <Link to="/" className="flex items-center gap-2">
            <Compass className="h-8 w-8 text-white" />
            <span className="text-xl font-bold text-white">Career Compass</span>
          </Link>
          
          <div className="flex items-center gap-4">
            <Link
              to="/auth"
              className="text-white hover:text-blue-100 transition-colors"
            >
              Log in
            </Link>
            <Link
              to="/auth"
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-full text-sm font-medium text-blue-900 bg-white hover:bg-blue-50 transition-colors"
            >
              Get Started
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
import React, { useState } from 'react';
import { PenLine, Send } from 'lucide-react';
import { FeatureDescription } from '../Common/FeatureDescription';
import { featureDescriptions } from '../../data/featureDescriptions';
import { generateCoverLetter } from '../../services/gpt';
import { CopyButton } from './CopyButton';
import type { CoverLetterFormData } from '../../types/coverLetter';

export function CoverLetterForm() {
  const [formData, setFormData] = useState<CoverLetterFormData>({
    jobTitle: '',
    company: '',
    keySkills: '',
    relevantExperience: '',
    whyInterested: '',
    additionalNotes: ''
  });
  const [coverLetter, setCoverLetter] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await generateCoverLetter(formData);
      setCoverLetter(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate cover letter');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <FeatureDescription
        title={featureDescriptions.coverLetter.title}
        description={featureDescriptions.coverLetter.description}
        icon={PenLine}
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div>
                <label htmlFor="jobTitle" className="block text-sm font-medium text-gray-700">
                  Job Title
                </label>
                <input
                  type="text"
                  id="jobTitle"
                  name="jobTitle"
                  required
                  value={formData.jobTitle}
                  onChange={handleChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-gray-700">
                  Company Name
                </label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  required
                  value={formData.company}
                  onChange={handleChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="mt-6">
              <label htmlFor="keySkills" className="block text-sm font-medium text-gray-700">
                Key Skills (comma separated)
              </label>
              <input
                type="text"
                id="keySkills"
                name="keySkills"
                required
                value={formData.keySkills}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div className="mt-6">
              <label htmlFor="relevantExperience" className="block text-sm font-medium text-gray-700">
                Relevant Experience
              </label>
              <textarea
                id="relevantExperience"
                name="relevantExperience"
                required
                rows={4}
                value={formData.relevantExperience}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Describe your relevant experience for this role..."
              />
            </div>

            <div className="mt-6">
              <label htmlFor="whyInterested" className="block text-sm font-medium text-gray-700">
                Why are you interested in this role?
              </label>
              <textarea
                id="whyInterested"
                name="whyInterested"
                required
                rows={3}
                value={formData.whyInterested}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Explain why you're interested in this position..."
              />
            </div>

            <div className="mt-6">
              <label htmlFor="additionalNotes" className="block text-sm font-medium text-gray-700">
                Additional Notes (optional)
              </label>
              <textarea
                id="additionalNotes"
                name="additionalNotes"
                rows={2}
                value={formData.additionalNotes}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Any additional information you'd like to include..."
              />
            </div>

            {error && (
              <div className="mt-4 text-sm text-red-600 bg-red-50 p-3 rounded-md">
                {error}
              </div>
            )}

            <div className="mt-6 flex justify-end">
              <button
                type="submit"
                disabled={isLoading}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Generate Cover Letter
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {coverLetter && (
          <div className="mt-6">
            <div className="bg-white shadow overflow-hidden sm:rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <div className="flex justify-end mb-4">
                  <CopyButton text={coverLetter} />
                </div>
                <div className="whitespace-pre-wrap font-serif text-gray-700">
                  {coverLetter}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
import React from 'react';
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

interface ScoreCardProps {
  label: string;
  score: number;
  className?: string;
}

export function ScoreCard({ label, score, className = '' }: ScoreCardProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'bg-green-50 border-green-200';
    if (score >= 60) return 'bg-yellow-50 border-yellow-200';
    return 'bg-red-50 border-red-200';
  };

  const getTextColor = (score: number) => {
    if (score >= 80) return 'text-green-700';
    if (score >= 60) return 'text-yellow-700';
    return 'text-red-700';
  };

  const getIcon = (score: number) => {
    if (score >= 80) return <CheckCircle className="h-6 w-6 text-green-500" />;
    if (score >= 60) return <AlertTriangle className="h-6 w-6 text-yellow-500" />;
    return <XCircle className="h-6 w-6 text-red-500" />;
  };

  return (
    <div className={`rounded-lg border p-4 ${getScoreColor(score)} ${className}`}>
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-gray-600">{label}</span>
        <div className="flex items-center gap-2">
          {getIcon(score)}
          <span className={`text-2xl font-bold ${getTextColor(score)}`}>
            {score}%
          </span>
        </div>
      </div>
    </div>
  );
}
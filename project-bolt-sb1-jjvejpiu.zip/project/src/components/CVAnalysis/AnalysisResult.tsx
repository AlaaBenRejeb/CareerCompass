import React from 'react';
import { AlertTriangle, Briefcase, CheckCircle2, XCircle } from 'lucide-react';
import type { AnalysisResult } from '../../types/analysis';
import { ScoreCard } from './ScoreCard';
import { KeywordList } from './KeywordList';

interface AnalysisResultProps {
  analysis: AnalysisResult;
}

export function AnalysisResult({ analysis }: AnalysisResultProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ScoreCard label="Overall Match" score={analysis.score} />
        {analysis.jobMatch && (
          <ScoreCard label="Job Fit Score" score={analysis.jobMatch.score} />
        )}
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <KeywordList
            title="Found Keywords"
            keywords={analysis.keywords.found}
            type="success"
          />
          <KeywordList
            title="Missing Keywords"
            keywords={analysis.keywords.missing}
            type="error"
          />
        </div>

        {analysis.jobMatch && (
          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-blue-600" />
              Job Match Analysis
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm font-medium text-green-600 mb-2">
                  Relevant Experience
                </h4>
                <ul className="space-y-2">
                  {analysis.jobMatch.relevantExperience.map((exp, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-2 bg-green-50 p-2 rounded-md"
                    >
                      <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5" />
                      <span className="text-sm text-gray-700">{exp}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="text-sm font-medium text-red-600 mb-2">
                  Missing Qualifications
                </h4>
                <ul className="space-y-2">
                  {analysis.jobMatch.missingQualifications.map((qual, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-2 bg-red-50 p-2 rounded-md"
                    >
                      <XCircle className="h-4 w-4 text-red-500 mt-0.5" />
                      <span className="text-sm text-gray-700">{qual}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        <div className="border-t pt-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-yellow-500" />
            Improvement Suggestions
          </h3>
          <ul className="space-y-2">
            {analysis.suggestions.map((suggestion, index) => (
              <li
                key={index}
                className="flex items-start gap-2 bg-yellow-50 p-3 rounded-md"
              >
                <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5" />
                <span className="text-sm text-gray-700">{suggestion}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
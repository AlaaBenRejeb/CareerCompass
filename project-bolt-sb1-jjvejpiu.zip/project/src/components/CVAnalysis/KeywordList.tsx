import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

interface KeywordListProps {
  title: string;
  keywords: string[];
  type: 'success' | 'error';
}

export function KeywordList({ title, keywords, type }: KeywordListProps) {
  const Icon = type === 'success' ? CheckCircle : XCircle;
  const textColor = type === 'success' ? 'text-green-600' : 'text-red-600';
  const bgColor = type === 'success' ? 'bg-green-50' : 'bg-red-50';

  return (
    <div>
      <h4 className={`text-sm font-medium ${textColor} mb-2`}>{title}</h4>
      <div className="space-y-1">
        {keywords.map((keyword, index) => (
          <div
            key={index}
            className={`flex items-center gap-2 p-2 rounded-md ${bgColor}`}
          >
            <Icon className={`h-4 w-4 ${textColor}`} />
            <span className="text-sm text-gray-700">{keyword}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
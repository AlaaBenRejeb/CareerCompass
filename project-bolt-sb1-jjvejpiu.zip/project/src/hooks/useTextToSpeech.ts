import { useState, useCallback, useEffect } from 'react';

export function useTextToSpeech() {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const synthesis = window.speechSynthesis;

  // Load and update voices when they become available
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = synthesis?.getVoices() || [];
      setVoices(availableVoices);
    };

    // Try loading voices immediately
    loadVoices();

    // Also handle async voice loading
    if (synthesis?.onvoiceschanged !== undefined) {
      synthesis.onvoiceschanged = loadVoices;
    }

    return () => {
      if (synthesis) {
        synthesis.cancel();
      }
    };
  }, [synthesis]);

  const getBestVoice = useCallback(() => {
    // Priority list for voice selection
    return (
      voices.find(v => v.lang.startsWith('en') && v.name.includes('Neural')) ||
      voices.find(v => v.lang.startsWith('en') && v.name.includes('Premium')) ||
      voices.find(v => v.lang.startsWith('en') && v.name.includes('Google')) ||
      voices.find(v => v.lang.startsWith('en')) ||
      voices[0]
    );
  }, [voices]);

  const speak = useCallback((text: string) => {
    return new Promise<void>((resolve) => {
      if (!synthesis) {
        console.error('Speech synthesis not supported');
        resolve();
        return;
      }

      // Cancel any ongoing speech
      synthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      const voice = getBestVoice();
      
      if (voice) {
        utterance.voice = voice;
      }
      
      utterance.rate = 0.9; // Slightly slower for clarity
      utterance.pitch = 1.0;
      utterance.volume = 1.0;
      utterance.lang = 'en-US'; // Ensure English is used

      utterance.onstart = () => {
        setIsSpeaking(true);
      };

      utterance.onend = () => {
        setIsSpeaking(false);
        resolve();
      };

      utterance.onerror = (event) => {
        console.error('Speech synthesis error:', event);
        setIsSpeaking(false);
        resolve();
      };

      // Chrome bug workaround
      if (synthesis.speaking) {
        synthesis.pause();
        synthesis.resume();
      }

      synthesis.speak(utterance);

      // Additional Chrome workaround
      const preventTimeout = setInterval(() => {
        if (!synthesis.speaking) {
          clearInterval(preventTimeout);
        } else {
          synthesis.pause();
          synthesis.resume();
        }
      }, 5000);
    });
  }, [synthesis, getBestVoice]);

  const stop = useCallback(() => {
    if (synthesis) {
      synthesis.cancel();
      setIsSpeaking(false);
    }
  }, [synthesis]);

  const hasSupport = Boolean(
    synthesis && 
    voices.length > 0 && 
    getBestVoice()
  );

  return {
    speak,
    stop,
    isSpeaking,
    hasSupport
  };
}
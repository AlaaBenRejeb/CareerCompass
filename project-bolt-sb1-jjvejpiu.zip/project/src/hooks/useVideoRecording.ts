import { useState, useEffect } from 'react';

export function useVideoRecording() {
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null);
  const [audioLevel, setAudioLevel] = useState(0);
  const [hasPermissions, setHasPermissions] = useState(false);
  const [recordingChunks, setRecordingChunks] = useState<Blob[]>([]);

  const requestPermissions = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
      setVideoStream(stream);
      setHasPermissions(true);
      setupAudioAnalyzer(stream);
      return true;
    } catch (error) {
      console.error('Permission error:', error);
      return false;
    }
  };

  const setupAudioAnalyzer = (stream: MediaStream) => {
    const audioContext = new AudioContext();
    const analyzer = audioContext.createAnalyser();
    const microphone = audioContext.createMediaStreamSource(stream);
    microphone.connect(analyzer);
    analyzer.fftSize = 256;
    
    const dataArray = new Uint8Array(analyzer.frequencyBinCount);
    
    const updateAudioLevel = () => {
      analyzer.getByteFrequencyData(dataArray);
      const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
      setAudioLevel(average / 255); // Normalize to 0-1
      requestAnimationFrame(updateAudioLevel);
    };
    
    updateAudioLevel();
  };

  const startRecording = async () => {
    if (!videoStream) return;

    const recorder = new MediaRecorder(videoStream);
    setMediaRecorder(recorder);
    setRecordingChunks([]);

    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        setRecordingChunks(prev => [...prev, event.data]);
      }
    };

    recorder.start();
  };

  const stopRecording = async (): Promise<Blob | null> => {
    return new Promise((resolve) => {
      if (!mediaRecorder) {
        resolve(null);
        return;
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordingChunks, { type: 'video/webm' });
        resolve(blob);
      };

      mediaRecorder.stop();
    });
  };

  useEffect(() => {
    return () => {
      if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [videoStream]);

  return {
    startRecording,
    stopRecording,
    videoStream,
    audioLevel,
    hasPermissions,
    requestPermissions
  };
}
import { useState, useEffect } from 'react';

interface SpeechSupport {
  synthesis: boolean;
  recognition: boolean;
  error: string | null;
}

export function useSpeechInitialization(): SpeechSupport {
  const [support, setSupport] = useState<SpeechSupport>({
    synthesis: false,
    recognition: false,
    error: null
  });

  useEffect(() => {
    // Check speech synthesis
    const synthesis = 'speechSynthesis' in window;
    const recognition = 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;
    
    let error = null;
    if (!synthesis && !recognition) {
      error = 'Speech features are not supported in your browser. Please try Chrome, Edge, or Safari.';
    } else if (!synthesis) {
      error = 'Speech synthesis is not supported in your browser.';
    } else if (!recognition) {
      error = 'Speech recognition is not supported in your browser.';
    }

    setSupport({ synthesis, recognition, error });
  }, []);

  return support;
}
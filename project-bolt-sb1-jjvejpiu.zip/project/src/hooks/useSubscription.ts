import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../utils/supabase';
import type { Subscription, SubscriptionFeatures } from '../types/subscription';

export function useSubscription() {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [features, setFeatures] = useState<SubscriptionFeatures | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setSubscription(null);
      setFeatures(null);
      setLoading(false);
      return;
    }

    const loadSubscriptionData = async () => {
      try {
        // Load subscription
        const { data: subData, error: subError } = await supabase
          .from('subscriptions')
          .select(`
            *,
            pricing (
              feature_limits
            )
          `)
          .eq('user_id', user.id)
          .single();

        if (subError) throw subError;

        // Load feature usage
        const { data: featureData, error: featureError } = await supabase
          .from('subscription_features')
          .select('*')
          .eq('subscription_id', subData.id);

        if (featureError) throw featureError;

        setSubscription(subData);
        setFeatures(featureData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load subscription');
      } finally {
        setLoading(false);
      }
    };

    loadSubscriptionData();
  }, [user]);

  const checkFeatureAccess = async (featureName: string): Promise<boolean> => {
    if (!subscription || !features) return false;

    const limits = subscription.pricing.feature_limits;
    const usage = features.find(f => f.feature_name === featureName);

    if (!limits[featureName]) return false;
    if (!usage) return true;

    return usage.usage_count < limits[featureName];
  };

  const incrementFeatureUsage = async (featureName: string) => {
    if (!subscription) return;

    const { error } = await supabase.rpc('increment_feature_usage', {
      p_subscription_id: subscription.id,
      p_feature_name: featureName
    });

    if (error) throw error;
  };

  return {
    subscription,
    features,
    loading,
    error,
    checkFeatureAccess,
    incrementFeatureUsage
  };
}
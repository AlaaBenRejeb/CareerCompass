```typescript
export interface InterviewFeedbackType {
  overallScore: number;
  strengths: string[];
  improvements: string[];
  communication: {
    clarity: number;
    confidence: number;
    engagement: number;
    pacing: number;
    pronunciation: number;
  };
  recommendations: string[];
}
```
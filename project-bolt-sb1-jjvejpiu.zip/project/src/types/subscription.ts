export interface PricingPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  stripe_price_id: string;
  features: string[];
  active: boolean;
}

export interface Subscription {
  id: string;
  user_id: string;
  stripe_subscription_id: string | null;
  stripe_customer_id: string | null;
  status: 'active' | 'trialing' | 'canceled' | 'incomplete' | 'past_due';
  plan_id: string;
  current_period_end: string | null;
  cancel_at_period_end: boolean;
}
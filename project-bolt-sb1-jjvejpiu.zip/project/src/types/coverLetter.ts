export interface CoverLetterFormData {
  jobTitle: string;
  company: string;
  keySkills: string;
  relevantExperience: string;
  whyInterested: string;
  additionalNotes: string;
}
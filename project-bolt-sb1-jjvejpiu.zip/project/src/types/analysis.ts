export interface JobDescription {
  title: string;
  description: string;
}

export interface AnalysisResult {
  score: number;
  keywords: {
    found: string[];
    missing: string[];
  };
  suggestions: string[];
  jobMatch?: {
    score: number;
    relevantExperience: string[];
    missingQualifications: string[];
  };
}
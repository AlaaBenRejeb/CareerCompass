export interface PricingPlan {
  id: string;
  name: string;
  price: number;
  interval: 'month' | 'year';
  features: string[];
  stripeProductId: string;
  stripePriceId: string;
}

export interface PaymentSession {
  id: string;
  url: string;
}

export interface SubscriptionStatus {
  isActive: boolean;
  plan: PricingPlan | null;
  currentPeriodEnd: string | null;
  cancelAtPeriodEnd: boolean;
}
/*
  # Payment System Tables

  1. New Tables
    - `pricing_plans`
      - Stores available subscription plans
      - Contains plan details and Stripe IDs
    - `subscriptions`
      - Tracks user subscriptions
      - Links to Stripe subscription data
  
  2. Security
    - Enable RLS on all tables
    - Add policies for secure access
*/

-- Create pricing plans table
CREATE TABLE pricing_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price integer NOT NULL,
  interval text NOT NULL CHECK (interval IN ('month', 'year')),
  features text[] NOT NULL DEFAULT '{}',
  stripe_product_id text NOT NULL,
  stripe_price_id text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create subscriptions table
CREATE TABLE subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  plan_id uuid REFERENCES pricing_plans NOT NULL,
  status text NOT NULL CHECK (status IN ('trialing', 'active', 'canceled', 'incomplete', 'past_due')),
  stripe_subscription_id text,
  stripe_customer_id text,
  current_period_start timestamptz,
  current_period_end timestamptz,
  cancel_at_period_end boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE pricing_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read active pricing plans"
  ON pricing_plans
  FOR SELECT
  USING (active = true);

CREATE POLICY "Users can read own subscription"
  ON subscriptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes
CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_plan_id ON subscriptions(plan_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);

-- Insert initial pricing plans
INSERT INTO pricing_plans (name, description, price, interval, features, stripe_product_id, stripe_price_id) 
VALUES 
  (
    'Basic',
    'Perfect for getting started',
    1999,
    'month',
    ARRAY[
      'Create and download CVs',
      'Basic CV analysis',
      'Cover letter generation',
      'Email support'
    ],
    'prod_basic',
    'price_basic_monthly'
  ),
  (
    'Pro',
    'For serious job seekers',
    3999,
    'month',
    ARRAY[
      'Everything in Basic',
      'Advanced CV optimization',
      'Unlimited CV versions',
      'Interview preparation',
      'Priority support'
    ],
    'prod_pro',
    'price_pro_monthly'
  ),
  (
    'Enterprise',
    'Complete career solution',
    7999,
    'month',
    ARRAY[
      'Everything in Pro',
      'Personal career coach',
      'Custom CV templates',
      'LinkedIn profile optimization',
      '24/7 support'
    ],
    'prod_enterprise',
    'price_enterprise_monthly'
  );
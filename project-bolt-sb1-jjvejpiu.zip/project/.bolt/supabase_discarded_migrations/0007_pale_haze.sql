/*
  # Fix Auth System and Add Indexes
  
  1. Updates
    - Add missing indexes for better performance
    - Update user initialization function with better error handling
  2. Security
    - Add missing RLS policies (skipping existing ones)
*/

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_profiles_user_id ON profiles(id);

-- Update user initialization function with better error handling
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  -- Create profile if it doesn't exist
  INSERT INTO public.profiles (id, full_name)
  VALUES (new.id, COALESCE(new.raw_user_meta_data->>'full_name', ''))
  ON CONFLICT (id) DO NOTHING;

  RETURN new;
EXCEPTION WHEN OTHERS THEN
  -- Log error and continue
  RAISE WARNING 'Error in handle_new_user: %', SQLERRM;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to ensure user data exists
CREATE OR REPLACE FUNCTION ensure_user_data(user_id uuid)
RETURNS void AS $$
BEGIN
  -- Ensure profile exists
  INSERT INTO public.profiles (id)
  VALUES (user_id)
  ON CONFLICT (id) DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
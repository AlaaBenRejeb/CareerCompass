/*
  # Create subscriptions and pricing tables

  1. New Tables
    - `subscriptions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `stripe_subscription_id` (text)
      - `stripe_customer_id` (text)
      - `status` (text)
      - `plan_id` (uuid, references pricing)
      - `current_period_end` (timestamptz)
      - `cancel_at_period_end` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `pricing`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `price` (integer)
      - `stripe_price_id` (text)
      - `features` (text[])
      - `active` (boolean)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create pricing table
CREATE TABLE pricing (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  price integer NOT NULL,
  stripe_price_id text NOT NULL,
  features text[] NOT NULL,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create subscriptions table
CREATE TABLE subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  stripe_subscription_id text,
  stripe_customer_id text,
  status text NOT NULL,
  plan_id uuid REFERENCES pricing NOT NULL,
  current_period_end timestamptz,
  cancel_at_period_end boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE pricing ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Policies for pricing table
CREATE POLICY "Anyone can read active pricing"
  ON pricing
  FOR SELECT
  USING (active = true);

-- Policies for subscriptions table
CREATE POLICY "Users can read own subscription"
  ON subscriptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own subscription"
  ON subscriptions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Insert initial pricing plans
INSERT INTO pricing (name, description, price, stripe_price_id, features) VALUES
  ('Free', 'Basic features to get you started', 0, 'price_free', ARRAY[
    'Basic CV builder',
    'Limited CV analysis',
    'Basic cover letter templates'
  ]),
  ('Pro', 'Advanced features for job seekers', 2999, 'price_pro_monthly', ARRAY[
    'Advanced CV builder',
    'Unlimited CV analysis',
    'AI-powered cover letter generation',
    'Skill gap analysis',
    'Interview preparation'
  ]),
  ('Enterprise', 'Full access to all features', 4999, 'price_enterprise_monthly', ARRAY[
    'Everything in Pro',
    'Priority support',
    'Custom branding',
    'Team collaboration',
    'API access'
  ]);
/*
  # API Key Storage Setup
  
  1. Tables
    - api_keys: Store encrypted API keys
  
  2. Security
    - Enable RLS
    - Add policies for secure access
*/

-- Create API keys table if it doesn't exist
CREATE TABLE IF NOT EXISTS api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name text NOT NULL,
  encrypted_key text NOT NULL,
  created_at timestamptz DEFAULT now(),
  last_used timestamptz,
  UNIQUE(key_name)
);

-- Enable Row Level Security
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;

-- Create policies for API keys
CREATE POLICY "Anyone can read API keys"
  ON api_keys
  FOR SELECT
  TO authenticated
  USING (true);

-- Insert the GPT API key
INSERT INTO api_keys (key_name, encrypted_key)
VALUES ('gpt', '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')
ON CONFLICT (key_name) DO UPDATE
SET encrypted_key = EXCLUDED.encrypted_key;
/*
  # Initial Database Setup

  1. New Tables
    - profiles: User profile information
    - api_keys: Secure storage for API keys
    - user_settings: User preferences and settings
    - subscriptions: User subscription information
    - pricing: Available pricing plans

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Set up secure data access controls

  3. Functions
    - Handle new user creation
    - Update timestamps automatically
*/

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create API keys table
CREATE TABLE api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name text NOT NULL UNIQUE,
  encrypted_key text NOT NULL,
  created_at timestamptz DEFAULT now(),
  last_used timestamptz
);

-- Create user settings table
CREATE TABLE user_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users ON DELETE CASCADE NOT NULL UNIQUE,
  email_notifications boolean DEFAULT true,
  job_alerts boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create pricing table
CREATE TABLE pricing (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  price integer NOT NULL,
  stripe_price_id text NOT NULL,
  features text[] NOT NULL,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create subscriptions table
CREATE TABLE subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  stripe_subscription_id text,
  stripe_customer_id text,
  status text NOT NULL,
  plan_id uuid REFERENCES pricing NOT NULL,
  current_period_end timestamptz,
  cancel_at_period_end boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create policies for API keys
CREATE POLICY "Anyone can read API keys"
  ON api_keys FOR SELECT
  TO authenticated
  USING (true);

-- Create policies for user settings
CREATE POLICY "Users can view own settings"
  ON user_settings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own settings"
  ON user_settings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for pricing
CREATE POLICY "Anyone can read active pricing"
  ON pricing FOR SELECT
  USING (active = true);

-- Create policies for subscriptions
CREATE POLICY "Users can read own subscription"
  ON subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create function to handle new user creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  -- Create profile
  INSERT INTO public.profiles (id, full_name)
  VALUES (new.id, COALESCE(new.raw_user_meta_data->>'full_name', ''))
  ON CONFLICT (id) DO NOTHING;

  -- Create user settings
  INSERT INTO public.user_settings (user_id)
  VALUES (new.id)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updating timestamps
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_settings_updated_at
  BEFORE UPDATE ON user_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_subscriptions_updated_at
  BEFORE UPDATE ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert initial pricing plans
INSERT INTO pricing (name, description, price, stripe_price_id, features) VALUES
  ('Free', 'Basic features to get you started', 0, 'price_free', ARRAY[
    'Basic CV builder',
    'Limited CV analysis',
    'Basic cover letter templates'
  ]),
  ('Pro', 'Advanced features for job seekers', 1999, 'price_pro_monthly', ARRAY[
    'Advanced CV builder',
    'Unlimited CV analysis',
    'AI-powered cover letter generation',
    'Skill gap analysis',
    'Interview preparation'
  ]);

-- Insert the GPT API key
INSERT INTO api_keys (key_name, encrypted_key)
VALUES ('gpt', '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')
ON CONFLICT (key_name) DO UPDATE
SET encrypted_key = EXCLUDED.encrypted_key;
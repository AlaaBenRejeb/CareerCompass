/*
  # Add subscription features and usage tracking

  1. New Tables
    - `subscription_features` - Track feature limits and usage
    - `api_usage` - Track API calls per user
  
  2. Changes
    - Add feature limits to pricing table
    - Add usage tracking to subscriptions
    
  3. Security
    - Enable RLS on new tables
    - Add policies for user access
*/

-- Add feature limits to pricing
ALTER TABLE pricing
ADD COLUMN feature_limits jsonb DEFAULT '{
  "cv_exports": 5,
  "cover_letters": 3,
  "interview_practice": 1,
  "skill_analysis": 2
}'::jsonb;

-- Create subscription features table
CREATE TABLE subscription_features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id uuid REFERENCES subscriptions NOT NULL,
  feature_name text NOT NULL,
  usage_count integer DEFAULT 0,
  last_used timestamptz,
  reset_date timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create API usage table
CREATE TABLE api_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  api_name text NOT NULL,
  calls_count integer DEFAULT 0,
  last_called timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE subscription_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_usage ENABLE ROW LEVEL SECURITY;

-- Policies for subscription features
CREATE POLICY "Users can read own subscription features"
  ON subscription_features
  FOR SELECT
  TO authenticated
  USING (
    subscription_id IN (
      SELECT id FROM subscriptions WHERE user_id = auth.uid()
    )
  );

-- Policies for API usage
CREATE POLICY "Users can read own API usage"
  ON api_usage
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Update pricing data with new limits
UPDATE pricing
SET feature_limits = '{
  "cv_exports": 999999,
  "cover_letters": 999999,
  "interview_practice": 999999,
  "skill_analysis": 999999,
  "api_calls": 999999
}'::jsonb
WHERE name = 'Enterprise';

UPDATE pricing
SET feature_limits = '{
  "cv_exports": 100,
  "cover_letters": 50,
  "interview_practice": 20,
  "skill_analysis": 30,
  "api_calls": 1000
}'::jsonb
WHERE name = 'Pro';

UPDATE pricing
SET feature_limits = '{
  "cv_exports": 3,
  "cover_letters": 1,
  "interview_practice": 1,
  "skill_analysis": 1,
  "api_calls": 10
}'::jsonb
WHERE name = 'Free';
/*
  # Auth System Fixes
  
  1. Updates
    - Fix user initialization
    - Add better error handling
    - Add missing indexes
  2. Security
    - Add additional RLS policies
*/

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_auth_status_user_id ON auth_status(id);
CREATE INDEX IF NOT EXISTS idx_profiles_user_id ON profiles(id);
CREATE INDEX IF NOT EXISTS idx_user_settings_user_id ON user_settings(user_id);

-- Update user initialization function with better error handling
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  -- Create profile if it doesn't exist
  INSERT INTO public.profiles (id, full_name)
  VALUES (new.id, COALESCE(new.raw_user_meta_data->>'full_name', ''))
  ON CONFLICT (id) DO NOTHING;

  -- Create user settings if they don't exist
  INSERT INTO public.user_settings (user_id)
  VALUES (new.id)
  ON CONFLICT (user_id) DO NOTHING;

  -- Initialize auth status if it doesn't exist
  INSERT INTO public.auth_status (id)
  VALUES (new.id)
  ON CONFLICT (id) DO NOTHING;

  RETURN new;
EXCEPTION WHEN OTHERS THEN
  -- Log error and continue
  RAISE WARNING 'Error in handle_new_user: %', SQLERRM;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add missing RLS policies
CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own settings"
  ON user_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own auth status"
  ON auth_status
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Function to ensure user data exists
CREATE OR REPLACE FUNCTION ensure_user_data(user_id uuid)
RETURNS void AS $$
BEGIN
  -- Ensure profile exists
  INSERT INTO public.profiles (id)
  VALUES (user_id)
  ON CONFLICT (id) DO NOTHING;

  -- Ensure user settings exist
  INSERT INTO public.user_settings (user_id)
  VALUES (user_id)
  ON CONFLICT (user_id) DO NOTHING;

  -- Ensure auth status exists
  INSERT INTO public.auth_status (id)
  VALUES (user_id)
  ON CONFLICT (id) DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
/*
  # API Keys Management

  1. New Tables
    - `api_keys`
      - `id` (uuid, primary key)
      - `key_name` (text)
      - `encrypted_key` (text)
      - `created_at` (timestamp)
      - `last_used` (timestamp)
      
  2. Security
    - Enable RLS on `api_keys` table
    - Add policy for authenticated users to read keys
*/

CREATE TABLE IF NOT EXISTS api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name text NOT NULL,
  encrypted_key text NOT NULL,
  created_at timestamptz DEFAULT now(),
  last_used timestamptz
);

ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read api keys"
  ON api_keys
  FOR SELECT
  TO authenticated
  USING (true);
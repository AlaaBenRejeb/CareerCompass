/*
  # Auth System Improvements
  
  1. New Tables
    - auth_status: Track user authentication status
  2. Functions
    - Updated user initialization
  3. Triggers
    - Enhanced auth state management
*/

-- Create auth status tracking
CREATE TABLE IF NOT EXISTS auth_status (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email_verified boolean DEFAULT false,
  last_sign_in timestamptz,
  sign_in_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE auth_status ENABLE ROW LEVEL SECURITY;

-- Auth status policies
CREATE POLICY "Users can view own auth status"
  ON auth_status
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Update user initialization function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  -- Create profile
  INSERT INTO public.profiles (id, full_name)
  VALUES (new.id, new.raw_user_meta_data->>'full_name');

  -- Create user settings with defaults
  INSERT INTO public.user_settings (user_id)
  VALUES (new.id);

  -- Initialize auth status
  INSERT INTO public.auth_status (id)
  VALUES (new.id);

  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update auth status on sign in
CREATE OR REPLACE FUNCTION handle_auth_sign_in()
RETURNS trigger AS $$
BEGIN
  UPDATE auth_status
  SET 
    last_sign_in = now(),
    sign_in_count = sign_in_count + 1
  WHERE id = new.id;
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for sign in tracking
CREATE TRIGGER on_auth_sign_in
  AFTER UPDATE OF last_sign_in_at ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_auth_sign_in();
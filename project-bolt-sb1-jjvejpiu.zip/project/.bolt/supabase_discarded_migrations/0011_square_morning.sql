/*
  # Initial Database Setup

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key, references auth.users)
      - `full_name` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `api_keys`
      - `id` (uuid, primary key)
      - `key_name` (text, unique)
      - `encrypted_key` (text)
      - `created_at` (timestamptz)
      - `last_used` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create API keys table
CREATE TABLE IF NOT EXISTS api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name text NOT NULL UNIQUE,
  encrypted_key text NOT NULL,
  created_at timestamptz DEFAULT now(),
  last_used timestamptz
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Anyone can read API keys"
  ON api_keys
  FOR SELECT
  TO authenticated
  USING (true);

-- Create trigger for profile creation on user signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (new.id, COALESCE(new.raw_user_meta_data->>'full_name', ''))
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Insert initial API key
INSERT INTO api_keys (key_name, encrypted_key)
VALUES ('gpt', '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')
ON CONFLICT (key_name) DO UPDATE
SET encrypted_key = EXCLUDED.encrypted_key;
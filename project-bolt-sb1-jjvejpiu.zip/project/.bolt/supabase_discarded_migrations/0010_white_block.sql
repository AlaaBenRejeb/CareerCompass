/*
  # Fix Authentication Setup

  1. Changes
    - Ensures profiles table exists with correct structure
    - Adds necessary RLS policies
    - Updates user creation trigger
    - Ensures API keys table exists

  2. Security
    - Maintains RLS policies for user data protection
    - Ensures proper access control
*/

-- Drop existing triggers to avoid conflicts
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Ensure profiles table exists
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Ensure API keys table exists
CREATE TABLE IF NOT EXISTS api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name text NOT NULL UNIQUE,
  encrypted_key text NOT NULL,
  created_at timestamptz DEFAULT now(),
  last_used timestamptz
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid duplicates
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Anyone can read API keys" ON api_keys;

-- Create fresh policies
CREATE POLICY "Users can view own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Anyone can read API keys"
  ON api_keys
  FOR SELECT
  TO authenticated
  USING (true);

-- Update user creation trigger function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (new.id, COALESCE(new.raw_user_meta_data->>'full_name', ''))
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Insert the GPT API key if it doesn't exist
INSERT INTO api_keys (key_name, encrypted_key)
VALUES ('gpt', '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')
ON CONFLICT (key_name) DO UPDATE
SET encrypted_key = EXCLUDED.encrypted_key;